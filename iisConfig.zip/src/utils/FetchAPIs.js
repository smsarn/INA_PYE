import { readMCCData } from "../data/dataExchangeMCC";
import {PROVINCE,
  ASSET_API_OUTPUT_Year,
  ASSET_API_OUTPUT_Age,
  ASSET_API_OUTPUT_FMV,
  ASSET_API_OUTPUT_EOYBalance,
  ASSET_API_OUTPUT_ACB,
  ASSET_API_OUTPUT_UCC,
  ASSET_API_OUTPUT_CCA,
  ASSET_API_OUTPUT_CapitalGain,
  ASSET_API_OUTPUT_TaxabaleGain,
  ASSET_API_OUTPUT_Recapture,
  ASSET_API_OUTPUT_TaxPayable,
  ASSET_API_OUTPUT_CapGainsExemption,
  ASSET_API_OUTPUT_Deposits,
  ASSET_API_OUTPUT_Withdrawals,
  ASSET_API_OUTPUT_RRIF,
  ASSET_API_OUTPUT_TaxPayableonIncome,
  ASSET_API_OUTPUT_DispositionAmount,
  appSiteAPI,
  ASSETS,
  ASSET_TAX,
} from "../definitions/generalDefinitions";


export function fetchTimerAPICheck() {
  let fails = parseInt(localStorage.getItem("INAAPIFails"));
  fetch(appSiteAPI + "/api/MCC_Carriers?id=1")
    .then(response => {console.log(response); response.json()})
    .then(data => console.log("timer API check"))
    .catch(error => {
      if (!fails) fails = 0;
      fails++;
      localStorage.setItem("INAAPIFails", parseInt(fails));
      console.log(error)
    });

  return fails;
}

/* export function fetchInsuranceNeedsData(dataNA) {
  return Promise.all([fetchINA(dataNA)]);
}

function fetchINA( dataNA) {
  let url = appSiteAPI + "/api/NA_OutputAll/";
  return fetch(url, {
    method: "POST",
    //			redirect: 'follow',
    //			credentials: 'same-origin',
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(dataNA)
  })
    .then(response => {
      if (response.ok === false) {
        throw Error(response.statusText);
      }
      return response;
    })
    .then(response => response.json())
    .then(data => {
      return data;
    })
    .catch(error => {
      console.log("handleFetchInsuranceNeedsData failed: " + error);
      // setState({failedAPI: true});
    });
}
 */
export function fetchAssetProjection( dataNA, assetID) {
  return Promise.all([fetchAP( dataNA, assetID)]);
}

function fetchAP( dataNA, assetID) {
  let url = appSiteAPI + "/api/NA_AssetProjection/";
  let dataAsset = {};

  if (assetID === undefined) assetID = 0;
  dataAsset.lives = dataNA.lives;
  dataAsset.asset = dataNA.assets[assetID - 1];
  dataAsset.projectionSettings = dataNA.projectionSettings;
  dataAsset.ratesPack = dataNA.ratesPack;
  /* 
 dataAsset.asset.incomeRate= 0.0;
            dataAsset.asset.contributionAmt= 1000;
            dataAsset.asset.contributionStartYr= 1;
            dataAsset.asset.contributionDur= 20;  */

  console.log(dataNA, dataAsset);

  // console.log(JSON.stringify(dataAsset),JSON.stringify(dataNA))
  return fetch(url, {
    method: "POST",
    //			redirect: 'follow',
    //			credentials: 'same-origin',
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(dataAsset)
  })
    .then(response => {
      if (response.ok === false) {
        throw Error(response.statusText);
      }
      return response;
    })
    .then(response => response.json())
    .then(data => {
      // console.log(data);
      return data;
    })
    .catch(error => {
      console.log("handleAssetProjection failed: " + error);
      // this.setState({failedAPI: true});
    });
}

export function fetchMCCData( dataNA, insNeed) {
  return Promise.all([fetchMCC( dataNA, insNeed)]);
}

function fetchMCC( dataNA, insNeed) {
  // let dataMCC=readMCCData(dataNA, 48,insNeed);

  let url = appSiteAPI + "/api/MCC_OutputArrays/";
  // console.log(url, dataNA);

  return fetch(url, {
    method: "POST",
    //			redirect: 'follow',
    //			credentials: 'same-origin',
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(dataNA)
  })
    .then(response => {
      if (response.ok === false) {
        throw Error(response.statusText);
      }
      return response;
    })
    .then(response => response.json())
    .then(data => {
      // console.log(data);
      return data;
    })
    .catch(error => {
      console.log("handleFetchMCCData failed: " + error);
      // this.setState({failedAPI: true});
    });
}












/* export function convertProvince(province,lang) {

 PROVINCE = {				
	en: {			
		header: 'Province',		
		Values: [		
		"Alberta",
		"British Columbia",
		"Manitoba",
		"Newfoundland and Labrador",
		"New Brunswick",
		"Nova Scotia",
		"Ontario",
		"Prince Edward Island",
		"Quebec",
		"Saskatchewan"
 
      return province.
  if (province === PROVINCE[lang].Values[0]) return "AB";
  else if (province === PROVINCE[lang].Values[1]) return "BC";
  else if (province === PROVINCE[lang].Values[2]) return "MB";
  else if (province === PROVINCE[lang].Values[4]) return "NB";
  else if (province === PROVINCE[lang].Values[3]) return "NF";
  else if (province === PROVINCE[lang].Values[5]) return "NS";
  else if (province === PROVINCE[lang].Values[6]) return "ON";
  else if (province === PROVINCE[lang].Values[7]) return "PE";
  else if (province === PROVINCE[lang].Values[8]) return "QC";
  else if (province === PROVINCE[lang].Values[9]) return "SK";
  else if (province === "NorthwestTerritories") return "NT";
  else if (province === "Nunavut") return "NV";
  else if (province === "Yukon") return "YU";
  else return "ON";
}
 */

/* export async function getTaxRate(appSiteAPI, type, province) {
  let taxRate = await fetchTaxRate1(appSiteAPI, type, province);
  console.log(taxRate);
  return taxRate;
}
 */

//async function fetchTaxRate1(appSiteAPI, type, province) {
export async function getTaxRate( type, province) {
  try
  {
    let taxRate= await fetch(
    appSiteAPI +
      "/api/RATES?type=" +
      type +
      "&province=" +
      province
    );
    let data= await  taxRate.json();
      // console.log(data)
        
    return (Math.round(parseFloat(data) * 10000)/10000).toFixed(4);
  }
  catch(error) {
      console.log("error, rates API failed", error);
    };
}



export async function fetchGovBenefits(dataNA, provincekey) {
  try
  {
    if(provincekey!== undefined)
    {
    dataNA.projectionSettings.province=provincekey
    dataNA.lives[1].isQC=provincekey==="QC"?true:false;
    }
    let url = appSiteAPI + "/api/NA_GovBenefits/";
    let govBenefits= await fetch(
    url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
    },
      body: JSON.stringify(dataNA)
    })
    let data= await  govBenefits.json();
    // console.log(data)
        
    return { 
       cpp : data[0].Values[0],
       cppDB : Math.round(data[1].Values[0]),
       orphan : Math.round(data[2].Values[0]),
      
    }
  }
  catch(error) {
      console.log("error, InsuranceNeedsData API failed", error);
    };
}




export async function fetchInsuranceNeedsData(dataNA, provincekey) {
  try
  {
    if(provincekey!== undefined)
    {
    dataNA.projectionSettings.province=provincekey
    dataNA.lives[1].isQC=provincekey==="QC"?true:false;
    }
    let url = appSiteAPI + "/api/NA_OutputAll/";
    let insuranceNeedsData= await fetch(
    url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
    },
      body: JSON.stringify(dataNA)
    })
    let data= await  insuranceNeedsData.json();
    // console.log(data)
        
    return { ages: data[1],
        govCF:data[3],
       personalCF:data[4],
       needs: data[5],
       shortfall: data[6],
       cpp : data[7].Values[0],
       cppDB : Math.round(data[8].Values[0]),
        orphan : Math.round(data[9].Values[0]),
        lifeExp : Math.round(data[12].Values[0]),
        lifeExpClient : Math.round(data[13].Values[0]),
        lifeExpJLTD : Math.round(data[14].Values[0]),
        provinceMargTax : data[15].Values[0],
        dataTaxLiability : data[16]
      
      
    }
  }
  catch(error) {
      console.log("error, InsuranceNeedsData API failed", error);
    };
}


export async function handleFetchInsuranceNeeds(dataNA, dataP) {
  try
  {
  console.log("Data sent to POST:");
  // console.log(dataNA);

  let url = appSiteAPI + "/api/NA_InsuranceNeeds/";
  let insuranceNeeds= await fetch(
  url, {
    method: "POST",
    //			redirect: 'follow',
    //			credentials: 'same-origin',
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(dataNA)
  })

  let data= await  insuranceNeeds.json();
  // console.log(data)
    
return data
}
catch(error) {
  console.log("handleFetchInsuranceNeeds failed: ", error);
};
}




/* export async function fetchTaxRate(appSiteAPI, type, province) {
  await fetch(
    appSiteAPI +
      "/api/RATES?type=" +
      type +
      "&province=" +
      province
  )
    .then(response => response.json())
    .then(data => {
      console.log(data);
      return data;
    })
    .catch(error => {
      console.log("error, rates API failed", error);
    });
}

 */


// BEGIN TEMPALTE
// THIS IS THE WAY TO MAKE SURE DATA HAS COME BACK FROM API
// IN THE CALLING MODULE
/* updateClientTaxLiability = async () => {
    let dataNA = this.props.getAssetProjection();
    let appSiteAPI = "http://localhost:8082";
    let data = await fetchAssetProjection2(appSiteAPI, dataNA, this.props.id);
    console.log(data);
    if (data !== undefined) {
      console.log(data[ASSET_API_OUTPUT_TaxPayable].numericValues[0]);

      return data[ASSET_API_OUTPUT_TaxPayable].numericValues;
    }
  }; */

// USE componentDidUpdate IF NEED TO UPDATE SOMETHING BASED ON THE LATEST VALUE OF ANOTHER AFTER setState or changed props
// componentDidUpdate= async (prevProps, prevState) => {

// FETCH 
export async function fetchAssetProjection2( dataNA, assetID) {
  try
  {
    let url = appSiteAPI + "/api/NA_AssetProjection/";
    let dataAsset = {};

    if (assetID === undefined) assetID = 0;
    dataAsset.lives = dataNA.lives;
    dataAsset.asset = dataNA.assets[assetID - 1];
    dataAsset.projectionSettings = dataNA.projectionSettings;
    dataAsset.ratesPack = dataNA.ratesPack;
 //   console.log(dataAsset);

    let dataProj= await fetch(url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(dataAsset)
    })
  
    let data= await dataProj.json();
//      console.log(data);
      return data;
  }
  catch(error) {
      console.log("error, Asset proj API failed", error);
  };
}
// END TEMPALTE


async function asyncAPICall( dataNA, assetID) {
  let data = await fetchAssetProjection2( dataNA, assetID);
 // console.log(data);
  if (data !== undefined) {
 //   console.log(data);

    return data;//[ASSET_API_OUTPUT_TaxPayable].numericValues;
  }
};

/* async function fetchAssetProjectionAPI2 (appSiteAPI,dataNA, assetID){
  let data = await asyncAPICall(appSiteAPI, dataNA, assetID);

  return data
}
 */
export async function fetchAssetProjectionAPI (dataNA, assetID)  {
  //alert ("fetch")
    let dataProjection=
    {
      dataColTitles: [],
      dataValues:[]
    }
    // console.log(appSiteAPI,dataNA, assetID);

    //let data =await fetchAssetProjectionAPI2(appSiteAPI, dataNA, assetID);
    let data = await asyncAPICall( dataNA, assetID);

    return data
    //fetchAssetProjection(appSiteAPI, dataNA, assetID.order).then(data => {
    /* if (data[0] !== undefined) {
      console.log("POST: NA_AssetProj success",data,assetID,dataNA);

   
      if (
        //this.props.assetCurr.Tax ===
        //ASSET_TAX.REGISTERED.VALUE[this.props.language]
        assetID ===
        ASSET_TAX.REGISTERED.Key//VALUE[this.props.language]
      ) {
        //		'Registered')
        dataProjection.dataColTitles = [
          "Year",
          "Age",
          "Annual Contribution",
          "RRIF Income",
          "Withdrawal",
          "Tax on income",
          "EOY Balance",
          "Tax Liability at Death"
        ];
        // F^
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Year].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Age].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_Deposits].numericValues);
        dataProjection.dataValues.push( data[ASSET_API_OUTPUT_RRIF].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_Withdrawals].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_TaxPayableonIncome].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_EOYBalance].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_TaxPayable].numericValues);
        console.log(dataProjection.dataValues);
      } else if (
        assetID ===
        ASSETS.PERSONAL_RESIDENCE.Key//value[this.props.language]
        
      ) {
        alert("k")
        dataProjection.dataColTitles = [
          "Year",
          "Age",
          "FMV",
          "Sale Proceeds",
          "Tax Liability"
        ];
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Year].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Age].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_EOYBalance].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_Withdrawals].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_TaxPayable].numericValues);
        console.log(dataProjection.dataValues);
      } else if (
        assetID ===
        ASSETS.REAL_ESTATE.Key//value[this.props.language]
      ) {
        dataProjection.dataColTitles = [
          "Year",
          "Age",
          "FMV",
          "ACB",
          "Rental Income",
          "Sale Proceeds",
          "Capital Gain",
          "Tax Liability"
        ];
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Year].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Age].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_EOYBalance].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_ACB].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_Withdrawals].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_DispositionAmount].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_CapitalGain].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_TaxPayable].numericValues);
        console.log(dataProjection.dataValues);
      } else if (
        assetID ===
        ASSETS.SMALL_BUSINESS_SHARES.Key//value[this.props.language]
      ) {
        dataProjection.dataColTitles = [
          "Year",
          "Age",
          "FMV",
          "ACB",
          "Capital Gains Exemption",
          "Capital Gain",
          "Tax Liability"
        ];
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Year].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Age].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_EOYBalance].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_ACB].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_CapGainsExemption].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_CapitalGain].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_TaxPayable].numericValues);
        console.log(dataProjection.dataValues);
      } else {
        dataProjection.dataColTitles = [
          "Year",
          "Age",
          "EOY Balance",
          "Withdrawal",
          "Tax Liability"
        ];
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Year].numericValues);
        dataProjection.dataValues.push(data[ASSET_API_OUTPUT_Age].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_EOYBalance].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_Withdrawals].numericValues);
        dataProjection.dataValues.push(
          data[ASSET_API_OUTPUT_TaxPayable].numericValues);
        console.log(data[ASSET_API_OUTPUT_Year].numericValues,dataProjection.dataValues);
      }
      return dataProjection;
     
    }*/  

};

export async function fetchAssetFMVandTaxLiab (dataNA, assetID)  {
   
  let dataProjection=
  {
    FMV: [],
    TaxLiab:[]
  }
    let data = await asyncAPICall( dataNA, assetID);
    if (data[0] !== undefined) {
        dataProjection.FMV=data[ASSET_API_OUTPUT_FMV].numericValues;
        dataProjection.TaxLiab=data[ASSET_API_OUTPUT_TaxPayable].numericValues;
        
      }
      console.log(dataProjection);
      return dataProjection;
      
}

export async function fetchAssetAllGridColumns (dataNA, assetID)  {
    let data = await asyncAPICall( dataNA, assetID);
    console.log(data);
    return data;
      
}




export  async function handleFetchInsuranceNeedsNew(dataNA,dataInput) {
  try
  {
    let url = appSiteAPI + "/api/NA_InsuranceNeeds/";

    
    let data= await 
      fetch(url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(dataNA)
    })
  
    let dataINA= await  data.json();
    // console.log(data)
    
    let dataDetails = await fetchInsuranceNeedsData(dataNA,dataInput.Presentations[0].provincekey)

  if (dataINA !== undefined && dataDetails !== undefined) {
    // console.log(data[0]);
    console.log("POST: NA_OutputAll success");
   return(
     {
     dataInsuranceNeeds :dataINA,
    dataNAAges : dataDetails.ages,
    dataCashFlowGov : dataDetails.govCF,
    dataCashFlowPersonal : dataDetails.personalCF,
    dataCashFlowNeeds : dataDetails.needs,
    dataShortfall : dataDetails.shortfall,
    cpp : dataDetails.cpp,
    cppDB : dataDetails.cppDB,
    orphan : dataDetails.orphan,
    lifeExp : dataDetails.lifeExp,
    lifeExpClient : dataDetails.lifeExpClient,
    lifeExpJLTD : dataDetails.lifeExpJLTD,
    provinceMargTax : dataDetails.provinceMargTax,
    dataTaxLiability : dataDetails.dataTaxLiability
     })
    };
  }
  catch(error) {
      console.log("error, rates API failed", error);
    };
}

