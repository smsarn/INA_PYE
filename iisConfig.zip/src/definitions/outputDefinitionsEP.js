export const OUTPUTTEXT = {
    en: {
      pg1T: "Protecting Your Estate",
      pg1P1: "Designed for: ",
      pg1P2: "Designed by: ",
      pg1P3: "Date: ",
      pg1P4: "Province: ",
      
      pg2T: "Introduction",
      pg2Paragraphs: ["Throughout your lifetime, your success has allowed you to accumulate assets beyond those that you will need to provide for an enjoyable retirement. The ownership of some of these assets will result in a tax liability upon your death (or the death of your spouse). These assets can be broadly divided into three groups. ",
      "First, assets of capital nature. The current Canadian tax law provides for the deemed disposition of your capital assets on your death, and any increase in value over the Cost (the tax term is Adjusted Cost Basis) is taxed as a Capital Gain. The most common assets in this category are:",
      "Shares in private or public companies",
      "Second homes or vacation properties",
      "Second, assets that generally produces income on your death. The most common assets in this category are:",
      "Registered Assets, RRSP’s or RRIF’s",
      "Assets that are taxed as Income like Interest bearing Assets, GICs or mainly market funds",
      "Third, are assets that are either fully tax paid or do not attract tax on death. The most common of these are:",
      "Non-taxable asset such as cash and TFSA",
      "The tax free proceeds from a life insurance policy"],
      
      pg3T: "Your Financial Situation",
      pg3P1:
        "Your current financial situation is summarized below. The balance sheet provides you with an estimate of your current net worth. In order to allow us to calculate your future tax liability it is necessary for us to project the growth in the value of assets going forward.  We will look at this in detail shortly.",
      pg3TabT: "Assets",
      pg3TabRTot: "Total Assets Available",
      pg3Tab2T: "Liabilities",
      pg3Tab2RTot: "Total",
      pg3Tab2NW: "Net Worth",
      
      pg3T2: "Your Growing Tax Liability",
      pg3P2:
        "As the value of your assets grow so does the tax liability that your estate will incur upon death.",
      pg3P3:
        "In order to project this liability we need to make assumption about the growth rate of your various assets.  In this projection we have assumed these growth rates:",
      pg3Tab3R1C1: "Assets",
      pg3Tab3R1C2: "Growth Rate",
      pg3Tab3R1C3: "Tax Liability Today",
      pg3Tab3R1C4: "Tax Liability Life Exp. + 3",
      
      pg3Tab3R2C1: "Real Estate (Non-Principal)",
      pg3Tab3R2C2: "",
      pg3Tab3R2C3: "",
      pg3Tab3R2C4: "",
      
      pg3Tab3R3C1: "Stocks & Bonds",
      pg3Tab3R3C2: "",
      pg3Tab3R3C3: "",
      pg3Tab3R3C4: "",
      
      pg3Tab3R4C1: "Small Business Shares",
      pg3Tab3R4C2: "",
      pg3Tab3R4C3: "",
      pg3Tab3R4C4: "",
      
      pg3Tab3R5C1: "RRSP/RRIP*",
      pg3Tab3R5C2: "",
      pg3Tab3R5C3: "",
      pg3Tab3R5C4: "",
      
      pg3Tab3R6C1: "Interest Bearing",
      pg3Tab3R6C2: "",
      pg3Tab3R6C3: "",
      pg3Tab3R6C4: "",
      
      pg3Tab3R7C1: "Total",
      pg3Tab3R7C2: "",
      pg3Tab3R7C3: "",
      pg3Tab3R7C4: "",
      pg3P4:
      " * please see assumptions for withdrawals of amounts from RRIF as they factor into this calculation",

      pg4T: "Future Value of Your Estate",
      pg4P1: "Using these assumptions, this chart shows the total value of your estate in the future and the tax liability that would be insured for each year going forward.",
      pg4P2:
      " * Life Expectancy + 3 is slightly shaded in the bar graph",

      pg5T: "Estate Protection Alternatives",
      pg5Paragraphs: [
        "Many people want to keep their estate intact to pass on to their heirs.  But what is the best method to use to fund this tax liability upon your death so that your assets can be passed to your heirs unencumbered?",
        "There are traditionally four choices to provide the liquidity to pay the taxes that come due upon death:",
        "Liquidating assets ",
        "Borrowing funds, which usually means using assets as security",
        "Creating a cash reserve by systematically saving during your lifetime",
        "Transferring the risk by purchasing life insurance",
        "Some of the advantages and disadvantages to each of these methods are:",
        "Liquidating assets -  Business cycles and the state of the markets are critical in the value of an asset. You have no way of knowing what this will be at your death. Further, the sale of assets by an estate often signal to a purchaser that there is a degree of urgency, which does not help the seller realize full value.",
        "wing Funds -  In estate situations, the main objective is usually to distribute the assets to the beneficiaries.  Borrowing against the assets, which will likely require pledging them as security, makes this more difficult. Further, it is not possible to predict the market conditions at the time of death. Financial institutions go through cycles, as do loan rates. ",
        "Creating a cash reserve -  in the context of an estate situation a cash reserve is not a practical option as you don’t know when death will occur. ",
        "Transferring the risk by purchasing life insurance -  Life insurance removes many of the risks associated with funding a liability upon death. It provides the liquidity exactly at the time it is needed. In Canada, a life insurance death benefit is paid tax free to the named beneficiary. ",
        ],
        pg5Plast: "Transferring the risk by purchasing life insurance is the most practical alternative for an estate.",
        
        pg6T: "Using Life Insurance to Preserve Your Estate",
        pg6Paragraphs1: [
        "A permanent life insurance policy can be a good way to provide for this future tax liability. Life insurance removes many of the financial risks associated with a premature death. It provides the financial assistance when it is needed, upon the death of the life insured. ",
        "The only type of life insurance that is appropriate for this need is permanent insurance. There are three types of permanent cash value life insurance coverage:",
        "Universal Life",
        "Whole Life",
        "Hybrid Life",
        "For all permanent plans, coverage stays in place until death, no matter the age.",
        "Cash values include accumulated capital within the tax exempt fund and any guaranteed cash surrender values that are offered to the policyowner by the insurance company upon cancellation of the contract.",
        "Depending on the type of policy established the total cash values, including the guaranteed portion, may be accessed by the policyowner through a number of different methods.",
        "One of the challenges facing the purchase of insurance is that the liability changes over time.",
        "The chart below shows the death benefit from a policy custom designed to meet your unique situation.  We have matched the death benefit as closely as possible to the need for cash to pay capital gains taxes on death. ",
        ],
        pg6Paragraphs2: [
        "This is a hybrid product that is customized to address your growing estate liability insurance needs. A hybrid life insurance policy offers a unique combination of the best elements of traditional whole life and universal life insurance:",
        "Cost of insurance is guaranteed not to increase",
        "Death benefit is a combination of the base insurance amount, additional paid up coverage and the value of investments",
        "Policy has contractually guaranteed cash values",
        "Additional funds, above the cost of insurance, may be deposited",
        "The funds are invested at the discretion of the policy owner (not the insurance company) and include these options: fixed income, stock market index accounts, mutual fund mirrored accounts and smoothed return investment account",
        ],
          
        pg7T: "Summary",
        pg7P1: "Transferring the risk by purchasing life insurance is the best alternative for covering a future tax liability. It gives you peace of mind and also outperforms the alternatives in terms of financial cost.",
        
    },
    fr: {
      pg1T: "Analyse des besoins en matière d'assurance - successorale",
      pg1P1: "Conçu pour : ",
      pg1P2: "Par: ",
      pg1P3: "Date: ",
      pg1P4: "Province: ",
      pg2TabT1: "Profil familial",
      pg2TabT2: "Àge",
      pg2TabT3: "Revenu annuel",
      pg2TabT4: "Àge de la retraite",
      pg3T: "Besoin de liquidités pour la famille au décès",
      pg3P1:
        "À votre décès, votre famille fera face à deux importants besoins financiers, soient d’obtenir des liquidités ainsi que des revenus. Bien que certains besoins de liquidités soient temporaires, d’autres sont nécessaires lors de toutes les étapes de la vie, ils sont donc identifiés comme «Besoins de liquidités permanents»..",
      pg3TabT: "Besoins de liquidités",
      pg3TabRTot: "Total",
      pg4T: "Besoin de revenus pour la famille au décès",
      pg4P1:
        "À votre décès, votre famille fera face à deux importants besoins financiers, soient d’obtenir des liquidités ainsi que des revenus.",
      pg4TabT: "Besoins de revenus",
      pg4TabRow1: "Montant actuel du revenu familial annuel",
      pg4TabRow2:
        "Pourcentage du revenu souhaité pour maintenir le niveau de vie actuel de votre famille pendant la période :",
      pg4TabRow3: "Avec enfants à charge",
      pg4TabRow4: "Pour le survivant par la suite",
      pg4TabRow5: "Le revenu souhaité s’élève donc à :",
      pg4TabRow6: "Avec enfants à charge",
      pg4TabRow7: "Pour le survivant par la suite",
      pg5T: "Sources de liquidité pour la famille au décès",
      pg5TabT: "Sources de liquidité",
      pg5TabRow1:
        "Pension de survivant du Régime des rentes du Québec / de pensions du Canada",
      pg5TabRow3: "Total des liquidités disponibles",
      pg5TabRow4: "Moins les liquidités nécessaires au décès de l’assuré",
      pg5TabRow5:
        "Excédent sur les liquidités disponibles pouvant assurer un revenu à la famille",
      pg6T: "",
      pg6TabT: "Revenus du survivant",
      pg6TabRow1:
        "Le revenu annuel total disponible pour cette période s’élève donc à :",
      pg6TabRow2: "Avec enfants à charge",
      pg6TabRow3: "Pour le survivant par la suite",
      pg6TabRow4:
        "Pour cette période, le manque à gagner (revenu souhaité moins revenu disponible) s’élève à :",
      pg6TabRow5: "Avec enfants à charge",
      pg6TabRow6: "Pour le survivant par la suite",
      pg7T: "Besoins d’assurance",
      pg7TabT: "État des revenus de la famille au décès",
      pg7TabRow1:
        "Pour cette période, le manque à gagner (revenu souhaité moins revenu disponible) s’élève à :",
      pg7TabRow2: "Avec enfants à charge",
      pg7TabRow3: "Pour le survivant par la suite",
      pg7TabRow4: "Taux d’inflation prévu",
      pg7TabRow5: "Taux d’intérêt potentiel des placements futurs du survivant",
      pg7TabRow6:
        "Basé sur ces facteurs financiers, le capital total requis pour générer des revenus indexés à l’inflation et qui sera épuisé à la fin de la période est :",
      pg7TabRow7: "A. Pour la durée de vie présumée du survivant (âge ",
      pg7TabRow8: "B. Jusqu'à la retraite du survivant",
      pg7TabRow9: "C. Jusqu’au 25e anniv. du benjamin",
      pg7TabRow10: "D. Jusqu’au 18e anniv. du benjamin",
      pg8T: "Besoins d’assurance",
      pg8TabT: "État des revenus de la famille au décès",
      pg8TabRow1:
        "Capitaux excédentaires actuellement disponibles pour investissement après couverture des besoins financiers :",
      pg8TabRow2:
        "Manque à gagner en capitaux productifs de revenu(ex. assurance) pour les périodes ci-dessous :",
      pg8TabRow3: "A. Pour la durée de vie présumée du survivant (âge ",
      pg8TabRow4: "B. Jusqu'à la retraite du survivant",
      pg8TabRow5: "C. Jusqu’au 25e anniv. du benjamin",
      pg8TabRow6: "D. Jusqu’au 18e anniv. du benjamin",
      pg9T: "Notes importantes",
      pg9P1:
        "Le présent exposé ne comporte que des renseignements généraux. L’information qui s’y trouve ne doit pas être considérée par le lecteur comme des conseils juridiques, comptables, fiscaux ou actuariels. Pour ces questions, le lecteur devrait consulter un professionnel indépendant. Veuillez-vous reporter aux illustrations d’assurance, aux libellés des contrats et aux documents d’information des sociétés d’assurance pour obtenir des précisions sur les questions d’assurance mentionnées dans le présent exposé, puisque dans tous les cas, ce sont ces documents qui prévalent.",
      pgFooter: "Voir les Notes importantes à la fin du présent exposé.",
      pg10T: "Accusé de réception",
      pg10P1:
        "Je soussigné, _______________________ accuse réception du présent document et des soumissions connexes, et considère toute l’information sur les prestations et les valeurs comme un résumé seulement. Je comprends que les prestations et les valeurs susmentionnées ne sont ni estimatives ni garantes du rendement futur. Je comprends aussi que les résultats réels peuvent fluctuer en fonction du temps et du rendement du marché, ainsi que de l’état de santé et de l’assurabilité de la personne. Ces résultats peuvent faire l’objet de modifications et différer des valeurs présentées dans l’exposé.",
      pg10TabRow1: "Signature du client: ____________________",
      pg10TabRow11: "jour, mois, année: ___________",
      pg10TabRow2: "Signature du client: ____________________",
      pg10TabRow3: "Signature du conseiller en assurance: ____________________"
    }
  };
  
