import React, { Component }  from 'react';
import { INCOMENEEDS } from './generalDefinitions';

const DEFAULT_MARGIN_LEFT=-67;
const DEFAULT_MARGIN_TOP=0;
const DEFAULT_WIDTH=140;
const DEFAULT_HEIGHT=100;

const POPUP_BORDER_INFO="#7399C6"
const POPUP_BORDER_ALERT="red"
const POPUP_BORDER_MESSAGE="#7399C6"

export 	const SHOW_AUTOMATIC_RED = 0;
export 	const SHOW_STANDARD = 1;
export 	const SHOW_STANDARD_RED = 2;
export 	const SHOW_NONE = 3;
export const SHOW_STANDARD_LIGHT_BLUE=4;

const infoHighlightStyle={color: "#6f2852", fontWeight: "bold"}

const MESSAGES = {
    en: {
      infoYr0: "Year 0 stands for “at death”",
      infoRetDur: "Duration to retirement is … years",
      infoAvgTax: <div> {/* style={{color:"#54585a"}}> */}
      Survivor's <span style={infoHighlightStyle} >Avg. Tax Rate</span> is applied to annual income, interest and annual asset disposition. <br/><span style={infoHighlightStyle} >Marginal Tax Rate </span>(under Presentation Details) is applied to planned or potential full disposition of an asset</div>,
      infoAdjust:
        "Adjust Income Needs and Income Source durations to end age (99) or Life Expectancy of",
      clientOnly: "Needs Analysis is always done for family member ‘Client’",
      infoElig:
      <div> Survivor's and orphan's benefits are based on Client's eligibility<br/>
       Set <span style={infoHighlightStyle} >Province</span>  under "Presentation Details" for CPP or QPP
      </div> ,
      infoSpouseElig:"The Survivor is assumed to be fully eligible for government benefits by the age of 65",
      ever: " ... for ever",
      taxMsg: "Tax methods need to be discussed with your financial advisor",
      fetch: "Failed to connect to the server",
      ie: "Please use Edge or Chrome browsers for graphs and full functionality",
      govB:
        <div>Do not delete government benefits. <br/>To adjust them, change <span style={infoHighlightStyle} >Client's "CPP Eligibility"</span></div>,
      assetTax:
        "Please use after tax asset values until Tax Method becomes available",
      internet:
        "You need to login to the PPI site again." +
        "You can save your data before clicking on this message or use " +
        "'Recover' in INA to reload your input data." +
        "Please click to refresh.",

        RRIF: "RRIF is reflected in survivor's income based on their own or rolled-over RRSP. Maximum withdrawal age is 71",        
        rollOver: "Client's assets can usually be rolled-over to their spouse to avoid liquidation",
        rental: "This is rental income for Real Estate and Dividend income for Stocks. Both as a % of Current Value",
        note :"Pull down on lower bottom to enlarge. A few samll paragraphs can be saved (up to 5000 characters)",
        save:   <div>
        To save files to your desired location:<br/><span style={infoHighlightStyle} >Microsoft Edge:</span>
      
        <li>Go to menu ..., Downloads, Download Settings</li>
       <span style={infoHighlightStyle} >Google Chrome:</span>
       <li>Go to menu ..., Settings, Advanced, Downloads</li>
       <span style={infoHighlightStyle} >then in either browser:</span>
        <li>Turn on "Ask where to save each file before downloading"
        </li>
            
      </div>,
      gridCapFund: "Capital Fund consists of Additianal Capital required (Insurance Needs) less Additional Income Required, accruing at afer-tax 'Investment Rate'" ,      
      salary: "Gross income, government benefits and other annual income types are assumed to grow at inflation rate",
      salaryPercent: "The After-tax value is shown in today's dollars. It will grow at inflation rate",
      afterTax: "All amounts are after tax",
      taxExempt: <div>Small Business <span style={infoHighlightStyle} >Capital Gains Tax Exemption</span> is assumed to grow at inflation rate</div>,
      infoINA: "This amount is based on the present value of shortfalls, discounted at the after tax investment rate. It is adjusted, if necessary to make sure early shortfalls are provided for"
    
    },
    fr: {
      infoYr0: "L’année 0 est l’année d                                                                                     u décès",
      infoRetDur: "Le nombre d’années avant la retraite est de .... ans",
      infoAvgTax: <div>Le taux d’imposition marginal (sous la rubrique « Précisions sur la présentation ») s’applique à la disposition planifiée ou potentielle complète d’un actif.     <span style={infoHighlightStyle} >Le taux d’imposition moyen</span> du survivant s’applique au revenu annuel, aux intérêts et à la disposition annuelle des actifs.<br/><span style={infoHighlightStyle} >Le taux d’imposition marginal </span> (sous la rubrique « Précisions sur la présentation ») s’applique à la disposition planifiée ou potentielle complète d’un actif.</div>,
      infoAdjust:
        "Ajuster les besoins de revenu et les durées de la source de revenu à ^F end age (99) or l'espérance de vie de",
      clientOnly:
        "L’analyse des besoins est toujours effectuée pour le «client» membre de la famille",
      infoElig:
      <div>Les prestations du survivant et de l’orphelin sont basées sur l’admissibilité du client<br/>
       Set <span style={infoHighlightStyle} >Province</span>  under "Presentation Details" for CPP or QPP ^F
       Définir <span style={infoHighlightStyle} >la province</span> (RPC ou RRQ) à la rubrique « Précisions sur la présentation ».”
      </div> ,
      infoSpouseElig:"Le survivant est supposé être pleinement admissible aux prestations gouvernementales avant l’âge de 65 ans",
      ever: " ... pour toujours",
      taxMsg:
        "Les méthodes fiscales doivent être discutées avec votre conseiller financier",
      fetch: "Défaut de connexion au serveur",
      ie:
        "s'il vous plaît utiliser les navigateurs Edge ou Chrome pour les graphiques et les fonctionnalités complètes",
      govB:
        <div>Ne supprimez pas les prestations gouvernementales. <br/>Pour les ajuster, modifier  <span style={infoHighlightStyle} >l'admissibilité du client</span></div>,
      assetTax:
        "Veuillez utiliser les valeurs des actifs après impôt jusqu'à ce que la méthode d'imposition devienne disponibl",
      internet:
        "  Vous devez vous connecter à nouveau au site PPI." +
          "Vous pouvez enregistrer vos données avant de cliquer sur ce message" +
        "pour recharger vos données d'entrée." +
          "S'il vous plaît cliquez pour rafraîchir.",
    RRIF: "Le FERR est pris en compte dans le revenu du survivant sur la base de son propre REER ou d’un REER transféré. L’âge maximal pour retirer des fonds est de 71 ans.",
    rollOver: "Les actifs du client peuvent habituellement être transférés au conjoint pour éviter une liquidation.",
    rental: "Il s’agit du revenu de location lié aux biens immobiliers et du revenu de dividende lié aux actions. Il s’agit dans les deux cas d’un pourcentage de la valeur actuelle.",
    note :"Abaissez le bord inférieur pour agrandir. Quelques petits paragraphes peuvent être enregistrés (jusqu’à 5 000 caractères).",
    save:   <div>
    Pour enregistrer les fichiers à l’emplacement voulu :<br/><span style={infoHighlightStyle} >Microsoft Edge:</span>
  
    <li>Aller au menu..., Téléchargements, Paramètres de téléchargement</li>
   <span style={infoHighlightStyle} >Google Chrome:</span>
   <li>Aller au menu..., Paramètres, Paramètres avancés, Téléchargements</li>
   <span style={infoHighlightStyle} >puis dans l’un ou l’autre des navigateurs :</span>
    <li>Activer la fonction « Me demander quoi faire avec chaque téléchargement » ou « Toujours demander où enregistrer les fichiers ».
    </li>
        
    </div>,
    gridCapFund: "Le fonds de capitaux est constitué du capital additionnel requis (besoins d’assurance), diminué du revenu additionnel requis et accru du taux de rendement après impôt." ,      
    salary: "Le revenu brut, les prestations de l’État et les autres types de revenus annuels sont présumés croître au taux d’inflation",
    salaryPercent: "La valeur après impôt est indiquée en dollars d’aujourd’hui. Il augmentera au taux d’inflation",
    afterTax: "Tous les montants sont après impôt",
    taxExempt: <div> <span style={infoHighlightStyle} >Exonération des gains en capital</span> pour les petites entreprises est présumée croître au taux d’inflation</div>,
    infoINA: "Ce montant est basé sur la valeur actualisée des manques à gagner en matière de revenus, actualisée au taux de rendement après impôt. Il est ajusté, si nécessaire, pour s'assurer que des manque à gagner précoces sont prévus"
    }
  };
  
  

export function getGenericMessage(lang)
{
     return {  
        infoID: "infoGenericMsg",
        infoText: "",
        iconMode:SHOW_NONE,
        popupOpenByProps:true,
        popupBorderColor:POPUP_BORDER_ALERT,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT, 
            marginTop: DEFAULT_MARGIN_TOP+5,
            width:DEFAULT_WIDTH+30,
            height:DEFAULT_HEIGHT 
        }
      }
  }

  export function   getInfoIconTaxExempt(lang)
  {
      return {  
          infoID: "infoExempt",
          infoText: MESSAGES[lang].taxExempt,
          iconMode:SHOW_STANDARD,
          popupOpenByProps:false,
          popupBorderColor:POPUP_BORDER_INFO,
          position: {
              marginLeft: DEFAULT_MARGIN_LEFT, 
              marginTop: DEFAULT_MARGIN_TOP,
              width:DEFAULT_WIDTH+20,
              height:DEFAULT_HEIGHT 
          }
      }
  }  

export function getInfoIconSourcesGov(lang)
{
    return {  
        infoID: "infogov",
        infoText: MESSAGES[lang].govB,
        iconMode:SHOW_STANDARD_RED,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_ALERT,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+12, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
    }
}

export function getInfoNoInternetAccess(lang)
{
    return {  
        infoID: "infoNoInternetAccess",
        infoText: MESSAGES[lang].internet,
        iconMode:SHOW_NONE,
        popupOpenByProps:true,
        popupBorderColor:POPUP_BORDER_ALERT,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT, 
            marginTop: DEFAULT_MARGIN_TOP+5,
            width:DEFAULT_WIDTH+80,
            height:DEFAULT_HEIGHT 
        }
    }
}


export function getInfoIconSourcesRRIF(lang)
{
    return {  
        infoID: "RRIF",
        infoText: MESSAGES[lang].RRIF,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
    }
}


export function getInfoIconClientsMember(lang)
{
    return {  
        infoID: "infoMember",
        infoText: MESSAGES[lang].clientOnly,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
                marginLeft: DEFAULT_MARGIN_LEFT+12, 
                marginTop: DEFAULT_MARGIN_TOP,
                width:DEFAULT_WIDTH,
                height:DEFAULT_HEIGHT 
            }
    }
}

export function getInfoIncome(lang)
{
    return {  
        infoID: "infosalary",
        infoText: MESSAGES[lang].salary,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+12, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
}
}


export function getInfoSalaryPercent(lang)
{
    return {  
        infoID: "infoSalaryPercent",
        infoText: MESSAGES[lang].salaryPercent,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
}
}



export function getInfoIconAssetsIncomeRate(lang)
{
    return {  
        infoID: "infoIconIncomeRate",
        infoText: MESSAGES[lang].rental,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
}
}

export function getInfoINA(lang)
{
    return {  
        infoID: "infoINA",
        infoText: MESSAGES[lang].infoINA,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+50,
            height:DEFAULT_HEIGHT 
        }
}
}



export function getInfoIconAssetsOwner(lang)
{
    return {  
        infoID: "infoIconOwner",
        infoText: MESSAGES[lang].rollOver,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+12, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
}
}

export function getInfoIconAssetsYr0(lang)
{
    return {  
        infoID: "infoIconYr0",
        infoText: MESSAGES[lang].infoYr0,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+12, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH,
            height:DEFAULT_HEIGHT 
        }
    }
}

export function getInfoIconClientsElig(lang)
{
    return {  
        infoID: "infoIconElig",
        infoText: MESSAGES[lang].infoElig,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+6, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+25,
            height:DEFAULT_HEIGHT 
        }
    }
}


export function getInfoIconSpouseElig(lang)
{
    return {  
        infoID: "infoIconSpouseElig",
        infoText: MESSAGES[lang].infoSpouseElig,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+6, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+25,
            height:DEFAULT_HEIGHT 
        }
    }
}


export function getInfoIconClientsTax(lang)
{
    return {  
        infoID: "infoIconAvgTax",
        infoText: MESSAGES[lang].infoAvgTax,
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT-20, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+70,
            height:DEFAULT_HEIGHT 
        }
    }
}

export function getInfoTaxLiability(lang)
{
    return {  
        infoID: "infoIconAvgTax",
        infoText: MESSAGES[lang].infoAvgTax,
        iconMode:SHOW_STANDARD_LIGHT_BLUE,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT-88, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+70,
            height:DEFAULT_HEIGHT 
        }
    }
}


export function getInfoIconNotes(lang)
{
    return {  
        infoID: "InfoIconNotes",
        infoText: MESSAGES[lang].note, 
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+20, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+70,
            height:DEFAULT_HEIGHT 
        }
    }
}

export function getInfoSave(lang)
{
    return {  
        infoID: "InfoSave",
        infoText:  MESSAGES[lang].save, 
        iconMode:SHOW_STANDARD,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+68, 
            marginTop: DEFAULT_MARGIN_TOP-172,
            width:DEFAULT_WIDTH+238,
            height:DEFAULT_HEIGHT -250
        }
    }
}

export function getInfoExcelcapFund(lang)
{
    return {  
        infoID: "InfoSave",
        infoText:  MESSAGES[lang].gridCapFund,
        iconMode:SHOW_STANDARD_LIGHT_BLUE,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT-88, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+70,
            height:DEFAULT_HEIGHT
        }
    }
}

export function getInfoExcelAllAfterTax(lang)
{
    return {  
        infoID: "InfoATax",
        infoText:  MESSAGES[lang].afterTax,
        iconMode:SHOW_STANDARD_LIGHT_BLUE,
        popupOpenByProps:false,
        popupBorderColor:POPUP_BORDER_INFO,
        position: {
            marginLeft: DEFAULT_MARGIN_LEFT+8, 
            marginTop: DEFAULT_MARGIN_TOP,
            width:DEFAULT_WIDTH+70,
            height:DEFAULT_HEIGHT
        }
    }
}
