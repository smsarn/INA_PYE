import {
    formatMoney,
    cleanFormat
} from "../utils/helper";
import { getAssetGridValues } from "./assetGridProjections";
import { setUIDataToAPI } from "./dataExchange";
import _ from 'lodash';

  import {
    COLUMN_TITLES,
    TITLES,
    INCOMESOURCES
  } from "../definitions/generalDefinitions";
  import {
    getInfoExcelcapFund,
    getInfoExcelAllAfterTax
  } from "../definitions/infoIconsDefinitions";
  
  const COLUMN_YEAR=0
  const COLUMN_AGE=1
  const COLUMN_INCOME_NEED=2
  const COLUMN_CPP=3
  const COLUMN_SURVIVOR_INCOME=4
  const COLUMN_OTHER_INCOME=5
  const COLUMN_TOTAL_INCOME=6
  const COLUMN_TOTAL_ASSET_LIAB=7
  const COLUMN_SHORTFALL=8
  const COLUMN_INSURANCE_NEED=9
  const COLUMN_FUND=10
  

  
  // INA

  function  INAFullSpreadsheetData(
    cols,
    insNeed,
    dataInput,
    dataPCV,
    Spouse,
    dataNeed,
    dataGov,
    dataShort,
    inflation,
    invRate,
    afterTaxCPP_DB,
    language
  ) {
    let dataColumns = [];
    let dataColumn = [];
    let noYrs = dataNeed.length;
    const tempDate = new Date();
    const year = tempDate.getFullYear();
  
     let dataColumnCapFund = [];
    
    let colNo;
    let yr;
    let spouseIncome = 0;
    let surivorIncomeProjection=getSourcesSurvivorIncomeProjections(dataInput,noYrs,Spouse.avgTaxRate, inflation)
    let surivorTotalPersIncomeProjection=getSourcesSurvivorTotalPersonalIncomeProjections (dataInput,noYrs,Spouse.avgTaxRate, inflation)
    const formatFr=language==="fr"? true:false
    const decimalChar=language==="en"?".":","
    const thousands=language==="en"?",":" "
    const capFundBase=parseFloat(cleanFormat(insNeed,formatFr))//+parseFloat(CPP_DB)
    
    console.log(Spouse)
    
    // console.log(surivorIncomeProjection,surivorTotalPersIncomeProjection)
    //alert(parseFloat(cleanFormat(dataShort[0] > 0 ? dataShort[0] : 0,formatFr)))
    for (colNo = 0; colNo < cols; colNo++) {
      dataColumn = [];
      for (yr = 0; yr < noYrs; yr++) {
        if(yr===0)
          dataColumnCapFund[yr]= Math.max(0,(capFundBase-parseFloat(cleanFormat(dataShort[yr] > 0 ? dataShort[yr] : 0,formatFr)))*Math.pow(1+invRate/100*(1-Spouse.avgTaxRate/100),1))
        else
          dataColumnCapFund[yr]= Math.max(0,(dataColumnCapFund[yr-1]-parseFloat(cleanFormat(dataShort[yr] > 0 ? dataShort[yr] : 0,formatFr)))*Math.pow(1+invRate/100*(1-Spouse.avgTaxRate/100),1))
        
        if (colNo === COLUMN_YEAR) dataColumn.push(year + yr);
        else if (colNo === COLUMN_AGE) dataColumn.push(Spouse.Age + yr);
        else if (colNo === COLUMN_INCOME_NEED) dataColumn.push(formatMoney(cleanFormat(-dataNeed[yr],formatFr),0,decimalChar,thousands));//numFormat(dataNeed[yr],  language==="en"?false:true, 2, language==="en"?",":" "));
        else if (colNo === COLUMN_CPP) dataColumn.push(formatMoney(cleanFormat(dataGov[yr],formatFr),0,decimalChar,thousands));//numFormat(dataGov[yr],   language==="en"?false:true, 2,  language==="en"?",":" "));
        else if (colNo === COLUMN_SURVIVOR_INCOME) {
          spouseIncome = surivorIncomeProjection[yr]
          dataColumn.push(formatMoney(cleanFormat(spouseIncome,formatFr),0,decimalChar,thousands));//numFormat(spouseIncome,   language==="en"?false:true, 2, language==="en"?",":" "));
        } else if (colNo === COLUMN_OTHER_INCOME) {
          let otherIncome = (
            //Math.round((dataPCV[yr] - surivorIncomeProjection[yr]) * 100) / 100
            Math.round((surivorTotalPersIncomeProjection[yr] - surivorIncomeProjection[yr]) * 100) / 100
          ).toFixed(0);
          if (Math.abs(otherIncome) <= 1) otherIncome = 0;
          dataColumn.push(formatMoney(cleanFormat(otherIncome,formatFr),0,decimalChar,thousands));//numFormat(otherIncome,   language==="en"?false:true, 2, language==="en"?",":" "));
        } else if (colNo === COLUMN_TOTAL_INCOME)
          dataColumn.push(formatMoney(parseFloat(surivorTotalPersIncomeProjection[yr])+dataGov[yr],0,decimalChar,thousands));//numFormat(dataPCV[yr] + dataGov[yr],   language==="en"?false:true, 2, language==="en"?",":" "));
          else if (colNo === COLUMN_TOTAL_ASSET_LIAB)
          dataColumn.push(formatMoney(Math.abs(dataPCV[yr]-parseFloat(surivorTotalPersIncomeProjection[yr]))>1?dataPCV[yr]-parseFloat(surivorTotalPersIncomeProjection[yr]):0,0,decimalChar,thousands));//numFormat(dataPCV[yr] + dataGov[yr],   language==="en"?false:true, 2, language==="en"?",":" "));
        if (colNo === COLUMN_SHORTFALL)
          dataColumn.push(
            formatMoney(cleanFormat(dataShort[yr] > 0 ? dataShort[yr] : 0,formatFr),0,decimalChar,thousands)// numFormat(dataShort[yr] > 0 ? dataShort[yr] : 0, false,   language==="en"?false:true, 2, language==="en"?",":" ")
          );
        else if (colNo === COLUMN_INSURANCE_NEED)
          dataColumn.push(yr === 0 ? formatMoney(cleanFormat(insNeed,formatFr),0,decimalChar,thousands) : 0);//numFormat(insNeed, false,   language==="en"?false:true, 2, language==="en"?",":" ") : 0);
        else if (colNo === COLUMN_FUND) 
            dataColumn.push(formatMoney(cleanFormat( dataColumnCapFund[yr],formatFr),0,decimalChar,thousands));//numFormat(0, false,   language==="en"?false:true, 2, language==="en"?",":" "));
      }
      // add CPP DB to other from CPP
      
      if(colNo === COLUMN_CPP)
          dataColumn[0] =formatMoney(parseFloat(cleanFormat(dataColumn[0],formatFr))-parseFloat(afterTaxCPP_DB),0,decimalChar,thousands)
      if(colNo === COLUMN_OTHER_INCOME)
          dataColumn[0] =formatMoney(parseFloat(cleanFormat(dataColumn[0],formatFr))+parseFloat(afterTaxCPP_DB),0,decimalChar,thousands)
    
          
      dataColumns.push(dataColumn);
     
      dataColumn = [];
    }
    console.log(dataColumns)
    return dataColumns;
  }

  function getSourcesSurvivorIncomeProjections (sources,noYrs, avgTaxRate,inflation) {
    let totalIncome=Array(noYrs).fill(0)
    let yr;
    // console.log(sources)
   
    sources.forEach((element) => {
       if(element.sourceTypeKey === INCOMESOURCES.SURVIVORS_INCOME.Key) 
       {
        for (yr = 0; yr < noYrs; yr++) {
          
          totalIncome[yr] +=
            (yr >= element.startYear && yr<parseInt(element.startYear)+parseInt(element.duration))
              ? parseFloat(element.amount) * (1-avgTaxRate /100) * Math.pow(1 + inflation / 100, yr)
              : 0;
        }
      } 
    })
    for (yr = 0; yr < noYrs; yr++)
        totalIncome[yr] = (Math.round(totalIncome[yr] * 100) / 100).toFixed(0);
     
     return totalIncome;
  
  }

  function getSourcesSurvivorTotalPersonalIncomeProjections (sources,noYrs, avgTaxRate,inflation) {
    let totalIncome=Array(noYrs).fill(0)
    let yr;
    // console.log(sources)
   
    sources.forEach((element) => {
       if(!(element.sourceTypeKey === INCOMESOURCES.GOV_DEATH_BENEFIT.Key || element.sourceTypeKey === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key  || element.sourceTypeKey === INCOMESOURCES.GOV_SURVIVORS_PENSION.Key) )
     {
      // console.log(element.sourceTypeKey)
   
        for (yr = 0; yr < noYrs; yr++) {
          totalIncome[yr] +=
            (yr >= element.startYear && yr<parseInt(element.startYear)+parseInt(element.duration))
              ? parseFloat(element.amount) * (1-avgTaxRate /100) * Math.pow(1 + inflation / 100, yr)
              : 0;
        }
      } 
    })
    for (yr = 0; yr < noYrs; yr++)
        totalIncome[yr] = (Math.round(totalIncome[yr] * 100) / 100).toFixed(0);
     
     return totalIncome;
  
  }


  // INA spreadsheet
  export function getINAGridData(
    insNeed,
    insNeedRet,
    insNeedLE,
    dataPCV,
    Spouse,
    dataNeed,
    dataGov,
    dataShort,
    inflation,
    language,
    invRate,
    Sources,
    afterTaxCPP_DB
  ){
    let gridColumnAligns;
    let dataTitle;
    let dataColHeaders;
    let dataColumns;
    let excelDataInfoSection;
    let gridIcons;
    
    {
      // spreadsheet
    dataTitle = TITLES[language].appletINA;
    dataColHeaders = INAFullSpreadsheetHeaders(language);
    dataColumns = INAFullSpreadsheetData(
      dataColHeaders.length,
      insNeed,
      Sources,
      dataPCV,
      Spouse,
      dataNeed,
      dataGov,
      dataShort,
      inflation,
      invRate,
      afterTaxCPP_DB,
      language
    );
    gridColumnAligns= new Array( dataColHeaders.length).fill(2);

    gridIcons = new Array( dataColHeaders.length)
    gridIcons[COLUMN_FUND]=getInfoExcelcapFund(language)
    gridIcons[COLUMN_YEAR]=getInfoExcelAllAfterTax(language)

    const decimalChar=language==="en"?".":","
    const thousands=language==="en"?",":" "
      
    excelDataInfoSection = [
      [
        COLUMN_TITLES[language].intRate,
        COLUMN_TITLES[language].infRate,
        COLUMN_TITLES[language].surplusCapital,
        COLUMN_TITLES[language].blank,
        COLUMN_TITLES[language].additionalCapitalReq,
        COLUMN_TITLES[language].survivor65,
        COLUMN_TITLES[language].survivorLE
      ],
      [
        invRate.toString() +
        "%",
        inflation.toString() +
        "%",
        parseFloat(afterTaxCPP_DB),
        "",
        "",
        insNeedRet,
        insNeedLE,
      ]
    ];
    }
    return {
        gridTitle: dataTitle,
        gridColumnsHeaders: dataColHeaders,
        gridColumnsDataMain:dataColumns,
        gridColumnsDataExcelInfoSection:excelDataInfoSection,
        gridColumnAligns:gridColumnAligns     ,
        gridIcons :gridIcons     
    }

  }
  
  function INAFullSpreadsheetHeaders(lang) {
    let headers = [];
    let i;
  
    for (i = 0; i < COLUMN_TITLES.INA_SHEET_HEADERS
  
  [lang].Full.length; ++i) {
      headers.push(COLUMN_TITLES.INA_SHEET_HEADERS
  [lang].Full[i]);
    }
  
    return headers;
  }
  




// ESTATE PROTECTION
async function EPFullSpreadsheetData (cols,
    noProjectYrs,// + 1,
    input){
    let noYrs = noProjectYrs;

    const formatFr = input.lang === "fr" ? true : false
    const decimalChar = input.lang === "en" ? "." : ","
    const thousands = input.lang === "en" ? "," : " "

    let count = 0;
    let dataColumns = new Array(cols).fill(0).map(() => new Array(noYrs).fill(0));

    const dataNA = await setUIDataToAPI(input);

    const assetsLength = input.dataInput.Assets.length;

    for (let i = 0; i < assetsLength; i++) {
        const element = input.dataInput.Assets[i];
        const data = await getAssetGridValues(dataNA, element, input.lang, true);
        count += 1;
        // console.log(data, data.dataProjection[0][0], data.dataProjection[0][1])

        for (let col = 0; col < 2; col++) {
            for (let yr = 0; yr < noYrs; yr++) {
                dataColumns[col][yr] = parseInt(data.dataProjection[col][yr])

            }
        }
        // dont add up year and age
        for (let col = 2; col < Math.min(cols, data.dataProjection.length); col++) {
            for (let yr = 0; yr < noYrs; yr++) {
                //console.log(yr,col,parseInt(data.dataProjection[col]))
                // console.log(col, yr, parseInt(data.dataProjection[col][yr]))
                dataColumns[col][yr] = parseInt(cleanFormat(dataColumns[col][yr], formatFr)) + parseInt(cleanFormat(data.dataProjection[col][yr], formatFr))

            }

        }

    };

    for (let col = 0; col < cols; col++) {
        for (let yr = 0; yr < noYrs; yr++) {
            if (yr === 0)
                dataColumns[2][yr] = parseInt(dataColumns[10][yr]) - parseInt(dataColumns[4][yr]) - parseInt(dataColumns[5][yr]) + parseInt(dataColumns[6][yr]) + parseInt(dataColumns[7][yr])
            else
                dataColumns[2][yr] = dataColumns[10][yr - 1]

            console.log(parseInt(dataColumns[10][yr]), parseInt(dataColumns[6][yr]), parseInt(dataColumns[2][yr]), 100 * (-1 + (parseInt(dataColumns[10][yr]) + parseInt(dataColumns[6][yr])) / parseInt(dataColumns[2][yr])))
            dataColumns[11][yr] = Math.round(10000 * (-1 + (parseInt(dataColumns[10][yr]) + parseInt(dataColumns[6][yr])) / parseInt(dataColumns[2][yr]))).toFixed(2) / 100 + " %"

        }

    }
    for (let col = 0; col < cols; col++) {
        if (col !== 11) {
            for (let yr = 0; yr < noYrs; yr++) {
                dataColumns[col][yr] = formatMoney(dataColumns[col][yr], 0, decimalChar, thousands)
            }
        }

    }

    return dataColumns;
}




// EP spreadsheet
export async function getEPGridData(
    noProjectYrs,
    input
) {
    let gridColumnAligns;
    let dataTitle;
    let dataColHeaders;
    let dataColumns;
    let excelDataInfoSection;
    let gridIcons;


    // spreadsheet
    const language = input.lang;
    dataTitle = TITLES[input.lang].appletEP;
    dataColHeaders = EPFullSpreadsheetHeaders(input.lang);

    dataColumns = await EPFullSpreadsheetData(
        dataColHeaders.length,
        noProjectYrs,// + 1,
        input
    );
    gridColumnAligns = new Array(dataColHeaders.length).fill(2);
    gridIcons = new Array(dataColHeaders.length)


    const decimalChar = language === "en" ? "." : ","
    const thousands = language === "en" ? "," : " "


    return {
        gridTitle: dataTitle,
        gridColumnsHeaders: dataColHeaders,
        gridColumnsDataMain: dataColumns,
        gridIcons: gridIcons
    }

}

function EPFullSpreadsheetHeaders(lang) {
    let headers = [];
    let i;

    for (i = 0; i < COLUMN_TITLES.EP_SHEET_HEADERS[lang].Full.length; ++i) {
        headers.push(COLUMN_TITLES.EP_SHEET_HEADERS[lang].Full[i]);
    }

    return headers;
}

