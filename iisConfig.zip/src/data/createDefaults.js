import { appletMode } from "../../package.json";
import {
  ASSETS,
  ASSET_TAX,
  ASSET_OWNERSHIP_ACTION,
  INCOMESOURCES,
  LIABILITIES,
  OWNERSHIP,
  GROWTHDIR,
  INCOMENEEDS,
  PROVINCE,
} from "../definitions/generalDefinitions";

import {
  SEX,
  SMOKING,
  MEMBER,

  DEFAULT_DIVIDEND_TAX_RATE,
  DEFAULT_AVG_TAX_RATE,
  DEFAULT_CLIENT_AGE,
  DEFAULT_SPOUSE_AGE,
  DEFAULT_SPOUSE_SALARY,
  DEFAULT_CLIENT_SALARY,
  DEFAULT_SPOUSE_CPP,
  DEFAULT_CLIENT_CPP,
  DEFAULT_SPOUSE_RETIREMENT,
  DEFAULT_CLIENT_RETIREMENT,
  DEFAULT_PROVINCE,
  DEFAULT_INFLATION,
  DEFAULT_INVESTMENT,
  DEFAULT_NEED_PERCENT1,
  DEFAULT_NEED_PERCENT2,
  QUOTE_CLIENT,
  QUOTE_SPOUSE,
  DEFAULT_RRIF_AGE,

  appSiteAPI,
  DISPLAY_RETIREMENT,
  DISPLAY_LIFEEXP,
  DISPLAY_ENDAGE,
  DISPLAY_LIFEEXP_PLUS_3,
  ORPHAN_AGE_QC,
  ORPHAN_AGE_NON_QC,
  MAX_ORPHAN_DUR_QC,
  MAX_ORPHAN_DUR_NON_QC,
  UNIVERSITY_START_AGE,
  UNIVERSITY_END_AGE,
  DISPLAY_PRESENTATION

} from "../definitions/generalDefinitions";
import {
  versionDetails,
} from "../utils/helper";



export function createDefaultAsset(id) {
  let asset = {
    id: id,
    assetTypeKey: ASSETS.PERSONAL_RESIDENCE.Key,
    ownerKey: ASSET_OWNERSHIP_ACTION.JOINT.Key,
    currValue: 0,
    assetTaxTypeKey: ASSET_TAX.NON_TAXABLE.Key,
    growth: 0,
    DisposeYr: 99,
    DisposeDur: 1,
    ACB: 0,
    smallBusinessCapGainExemption: 0,
    contributionAmt: 0,
    contributionStartYr: 0,
    contributionDur: 0,
    incomeRate: 0,
    RRIFStartAge: DEFAULT_RRIF_AGE,
    projection: null
  }
  return asset;
};

export function copyFromAnotherAsset(anotherAsset) {

  return JSON.parse(JSON.stringify(anotherAsset))

};



export function createDefaultClient(id) {
  const defaultClient1 =
  {
    id: 1,
    Age: DEFAULT_CLIENT_AGE,
    sexKey: SEX.MALE.Key,//["en"].Values[0],
    smokerKey: SMOKING.NON_SMOKER.Key,
    Income: DEFAULT_CLIENT_SALARY,
    avgTaxRate: DEFAULT_AVG_TAX_RATE,
    //  member: MEMBER.CLIENT.value["en"],
    memberKey: MEMBER.CLIENT.Key,
    retirementAge: DEFAULT_CLIENT_RETIREMENT,
    Eligibility: DEFAULT_CLIENT_CPP,
  }
  const defaultClient2 = {
    id: 2,
    Age: DEFAULT_SPOUSE_AGE,
    //Sex: SEX["en"].Values[1],
    sexKey: SEX.FEMALE.Key,//["en"].Values[0],
    smokerKey: SMOKING.NON_SMOKER.Key,
    Income: DEFAULT_SPOUSE_SALARY,
    avgTaxRate: DEFAULT_AVG_TAX_RATE,
    //member: MEMBER.SPOUSE.value["en"],
    memberKey: MEMBER.SPOUSE.Key,
    retirementAge: DEFAULT_SPOUSE_RETIREMENT,
    Eligibility: DEFAULT_SPOUSE_CPP
  }
  const child={
    id: id,//this.state.dataInput.clientsNo,
    Age:1,
    sexKey:
    SEX.MALE.Key,
    smokerKey: SMOKING.NON_SMOKER.Key,
    Income: 0,
    avgTaxRate: 0.0,
    memberKey: MEMBER.CHILD.Key,
    retirementAge: 65,
    Eligibility: 0
  }
  if (id === 1)
    return defaultClient1
  else if (id === 2)
    return defaultClient2
  else
    return child
  
}

export function createDefaultSource(id) {
  const defaultSource =
  {
    id: id,
    //Type: INCOMESOURCES.SURVIVORS_INCOME.value["en"],
    sourceTypeKey: INCOMESOURCES.SURVIVORS_INCOME.Key,
    amount: DEFAULT_SPOUSE_SALARY,
    startYear: 0,
    duration: DEFAULT_SPOUSE_RETIREMENT - DEFAULT_SPOUSE_AGE,
    ownerID: 2,
    taxRate: DEFAULT_AVG_TAX_RATE,
    growthRate: DEFAULT_INFLATION
  }
  return defaultSource
}

export function createDefaultLiab(id) {
  const defaultLiab =
  {
    id: id,
    //Type: LIABILITIES.LAST_EXPENSES.value["en"],
    liabTypeKey: LIABILITIES.LAST_EXPENSES.Key,
    ownerKey: OWNERSHIP.CLIENT.Key,
    currValue: 0,
    growthDir: GROWTHDIR["en"].Values[0], //increases
    growth: 0,
    repay: 0,
    exposureDur: 99,
    assetTaxLiabID: 0,
    assetTaxLiabProj: []
  }
  return defaultLiab
}


export function createDefaultNeed(id) {
  const defaultNeed1 =
  {
    id: 1,
    needTypeKey: INCOMENEEDS.PERCET_OF_INCOME.Key,
    Percent: DEFAULT_NEED_PERCENT1,
    amount: DEFAULT_NEED_PERCENT1 * (DEFAULT_SPOUSE_SALARY + DEFAULT_CLIENT_SALARY) * (1 - DEFAULT_AVG_TAX_RATE / 100) / 100,
    startYear: 0,
    duration: DEFAULT_SPOUSE_RETIREMENT - DEFAULT_SPOUSE_AGE,
  }
  const defaultNeed2 =
  {

    id: id,
    needTypeKey: INCOMENEEDS.PERCET_OF_INCOME.Key,
    Percent: DEFAULT_NEED_PERCENT2,
    amount: DEFAULT_NEED_PERCENT2 * (DEFAULT_SPOUSE_SALARY + DEFAULT_CLIENT_SALARY) * (1 - DEFAULT_AVG_TAX_RATE / 100) / 100,
    startYear: DEFAULT_SPOUSE_RETIREMENT - DEFAULT_SPOUSE_AGE,
    duration: 100
  }
  if (id === 1)
    return defaultNeed1
  else
    return defaultNeed2

}

export function createDefaultPres(id, tax) {
  const defaultPres =
  {
    id: id,
    provinceKey: PROVINCE.BC.Key,
    invRate: DEFAULT_INVESTMENT,
    inflation: DEFAULT_INFLATION,
    taxRate: tax,
    designedFor: "",
    designedBy: "",
    valuationDate: "",
    notes: "",
    version: versionDetails().version,
    periodOption: appletMode === "INA" ? DISPLAY_RETIREMENT : DISPLAY_ENDAGE,
    language: "en",
    resultsOption: DISPLAY_PRESENTATION
  }
  return defaultPres
}
