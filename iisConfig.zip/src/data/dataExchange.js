import { name, version } from '../../package.json';
import {GROWTHDIR, MONTHS, ASSETS, ASSET_OWNERSHIP_ACTION, ASSET_TAX, INCOMESOURCES, OWNERSHIP, SEX, SMOKING, MEMBER, LIABILITIES, TITLES, INCOMENEEDS, PROVINCE, QUOTE_SPOUSE,QUOTE_CLIENT,
} from '../definitions/generalDefinitions';
import { cleanFormat, formatMoney,getListItemNameFromKey } from "../utils/helper";

import { versionDetails,getAfterTaxTotalIncome} from "../utils/helper";
import { appletMode } from "../../package.json";

export function setUIDataToAPI (dataInput) {
		let age=dataInput.Clients[0].Age;
		const taxRate=dataInput.length>1?dataInput.Clients[QUOTE_SPOUSE].avgTaxRate / 100:dataInput.Clients[QUOTE_CLIENT].avgTaxRate / 100
		if(dataInput.length>1 && dataInput.Clients[QUOTE_SPOUSE].Age<age)age=dataInput.Clients[QUOTE_SPOUSE].Age;
       	let dataLives = setLives(dataInput);
		let dataAssets = setAssets(dataInput);
		let dataLiabs = setLiabs(dataInput);
		let dataSources = setSources(dataInput,taxRate);
		let dataEstateContings = setEstateContings();
		let dataIncomeNeeds = setIncomeNeeds(dataInput);
		let dataRates = setRates(dataInput);
		let dataProjSettings = setProjSettings(age,dataInput);
		let dataNA = {
			lives: dataLives,
			assets: dataAssets,
			liabilities: dataLiabs,
			personalIncomeSources: dataSources,
			estateContingiencies: dataEstateContings,
			incomeNeeds: dataIncomeNeeds,
			ratesPack: dataRates,
			projectionSettings: dataProjSettings
			//liabilities: null,
			//personalIncomeSources: null,
			//estateContingiencies:  null,
			//incomeNeeds:  null
			//ratesPack:  null,
			//projectionSettings:  null
		};
		console.log(dataNA)
		return dataNA;
	}




function setLives (dataInput) {
		let dataE = [];
		let i;
		// for calc purposes
		// console.log(dataInput.Clients[0].sexKey)
		// console.log(SEX.FEMALE.Key)
		for (i = 0; i < dataInput.Clients.length; i++) {
			// console.log(dataInput.Clients[i].memberKey)
			dataE.push({
					Age: dataInput.Clients[i].Age,
					Sex: dataInput.Clients[i].sexKey,// === SEX.FEMALE.Key ? SEX.FEMALE : SEX.MALE,
					Smk: dataInput.Clients[i].smokerKey === SMOKING.SMOKER.Key ? "S_STD" : "NS_STD", // 2 and 5 : this MCC stuff with 5 leveles elite ...
					Rating: 100,
			//		member: (i===1 && dataInput.Clients[i].memberKey===MEMBER.DEPENDENT_ADULT.Key)? MEMBER.SPOUSE.Key: //MEMBER["en"].Values[MEMBER[lang].Values.indexOf(dataInput.Clients[i].member)],
			//					dataInput.Clients[i].memberKey,//Object.values(MEMBER).filter(obj => obj.Key=== dataInput.Clients[i].memberKey)[0],//.value.en,
					member: dataInput.Clients[i].memberKey,
					salary: dataInput.Clients[i].Income,
					CPPeligibility: dataInput.Clients[i].Eligibility/100,
					retirementAge: dataInput.Clients[i].retirementAge,
					avgTaxRate: dataInput.Clients[i].avgTaxRate / 100,
					isQC : dataInput.Presentations[0].provinceKey === "QC"? true:false
				
				});
			
		}
		console.log(dataE,dataInput)
		return dataE;
	}

	function setTaxAPIMethod(TaxKey,assetKey){
		// based on API enum
		/* public enum taxTreatments
        {
            NonTaxable=0,
            CapitalGainIncome, 1
            CapitalGainAnnual, 2
            Registered, 3
            FullyTaxable, 4
            CapitalGainDividend,  5
            Dividend, 6
            RRIF, 7
            LifeInsurance, 8
            Cash, 9
            InterestIncome, 10
            CapitalGainQSmallBusiness, 11
        } */
		// from 
		/* 'Non-taxable',	
			"Capital Gains Deferred",
			"Capital Gains Annual",
			'Registered',	
			'Fully Taxable',	
			'Dividend'	 */
		//console.log(Tax,Type,)

		let taxMethodIndex=0;

		if (TaxKey===ASSET_TAX.NON_TAXABLE.Key)
			taxMethodIndex =0 //NonTaxable
		else if (TaxKey===ASSET_TAX.CAPITAL_GAINS_DEFERRED.Key)
		{
			if (assetKey=== ASSETS.SMALL_BUSINESS_SHARES.Key)//value[lang])
				taxMethodIndex =11 // CapitalGainQSmallBusiness, 11
			else
				taxMethodIndex =1 // CapitalGainIncome, 1

		}
	
		else if (TaxKey===ASSET_TAX.CAPITAL_GAINS_ANNUAL.Key)
			taxMethodIndex = 2 //  CapitalGainAnnual
		else if (TaxKey===ASSET_TAX.FULLY_TAXABLE.Key)
		{ 
			if(assetKey=== ASSETS.INTEREST_BEARING.Key)//value[lang])
				taxMethodIndex =10 //InterestIncome, 10
			else 
				taxMethodIndex =4 // FullyTaxable, 4

		}
		else if (TaxKey===ASSET_TAX.REGISTERED.Key)
			taxMethodIndex = 3 //Registered, 3
		else if (TaxKey===ASSET_TAX.DIVIDEND.Key)
			taxMethodIndex = 6 //  Dividend, 6

		// console.log(taxMethodIndex)	
		return taxMethodIndex
		
	}

	function setAssets (dataInput) {
		let dataE = [];
		let i;
		for (i = 0; i < dataInput.Assets.length; i++) {
			const assetName=dataInput.Assets[i].Type
			const assetTypeKey = dataInput.Assets[i].assetTypeKey
			console.log(dataInput,dataInput.Assets[i].assetTypeKey,dataInput.Assets[i].assetTaxTypeKey)
			
			dataE.push({
				name: Object.values(ASSETS).filter(obj => obj.Key=== assetTypeKey)[0].value.en,
				
				ID: Object.values(ASSETS).filter(obj => obj.Key=== assetTypeKey)[0].ID,
				//taxMethod: setTaxAPIMethod( dataInput.Assets[i].assetTaxTypeKey,dataInput.Assets[i].assetTypeKey),
				taxMethod: dataInput.Assets[i].assetTaxTypeKey,
				//Object.values(ASSET_TAX).filter(obj => obj.Key=== dataInput.Assets[i].assetTaxTypeKey)[0].value.en,
				owner: Object.values(ASSET_OWNERSHIP_ACTION).filter(obj => obj.Key=== dataInput.Assets[i].ownerKey)[0].ID,// enums in API is same 0-4
				ACB: dataInput.Assets[i].ACB, 
				smallBusinessCapGainExemption:dataInput.Assets[i].smallBusinessCapGainExemption,
				dispositionYr: dataInput.Assets[i].assetTaxTypeKey===ASSET_TAX.REGISTERED.Key && dataInput.Assets[i].ownerKey!==ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key ?99: dataInput.Assets[i].DisposeYr,
				dispositionDur: dataInput.Assets[i].DisposeDur===0?1:dataInput.Assets[i].DisposeDur,
				dispositionYrUlt: 100,
				currValue: dataInput.Assets[i].currValue,
				annualGrowth: dataInput.Assets[i].growth / 100,
				incomeRate: dataInput.Assets[i].incomeRate / 100,
				contributionAmt: dataInput.Assets[i].contributionAmt,
				contributionStartYr: dataInput.Assets[i].contributionStartYr,
				contributionDur: dataInput.Assets[i].contributionDur,
				RRIFStartAge: dataInput.Assets[i].RRIFStartAge
			});
		}
		// console.log(dataInput,dataE)
		return dataE;
	}

function setLiabs(dataInput) {
		let dataE = [];
		let i;
		for (i = 0; i < dataInput.Liabilitys.length; i++) {
			const  growth=GROWTHDIR[dataInput.Presentations[0].language].Values.indexOf(dataInput.Liabilitys[i].growthDir)===0?dataInput.Liabilitys[i].growth / 100:-dataInput.Liabilitys[i].growth / 100;
			const liabTypeKey = dataInput.Liabilitys[i].liabTypeKey
			// console.log(dataInput)
			dataE.push({
				name: Object.values(LIABILITIES).filter(obj => obj.Key=== liabTypeKey)[0].value.en,
				ID: Object.values(LIABILITIES).filter(obj => obj.Key=== liabTypeKey)[0].ID,
				owner: dataInput.Liabilitys[i].ownerKey, // OWNERSHIP["en"].Values[OWNERSHIP[lang].Values.indexOf(dataInput.Liabilitys[i].Owner)],
				currValue: dataInput.Liabilitys[i].currValue,
				annualGrowth: growth,
				exposureDur: dataInput.Liabilitys[i].exposureDur,
				annualRepay: dataInput.Liabilitys[i].repay,
			});
		}
		return dataE;
	}

function setSources (dataInput, avgTaxRate) {
		let dataE = [];
		let i;
		//alert(dataInput.length);
		for (i = 0; i < dataInput.Sources.length; i++) {
			// console.log(dataInput.Sources)
			const sourceTypeKey = dataInput.Sources[i].sourceTypeKey
			// gov is taken care of in API only needs elig %
			//if (dataInput.Sources[i].Type !== INCOMESOURCES[lang].Values[1] && dataInput.Sources[i].Type !== INCOMESOURCES[lang].Values[2] && dataInput.Sources[i].Type !== INCOMESOURCES[lang].Values[3]) {
			if (!(dataInput.Sources[i].sourceTypeKey === INCOMESOURCES.GOV_SURVIVORS_PENSION.Key || dataInput.Sources[i].sourceTypeKey === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key || dataInput.Sources[i].sourceTypeKey === INCOMESOURCES.GOV_DEATH_BENEFIT.Key) ) {
					dataE.push({
					ID: Object.values(INCOMESOURCES).filter(obj => obj.Key=== sourceTypeKey)[0].ID,
					name: Object.values(INCOMESOURCES).filter(obj => obj.Key=== sourceTypeKey)[0].value.en,
					amount: dataInput.Sources[i].amount,
					startYear: dataInput.Sources[i].startYear,
					duration: dataInput.Sources[i].duration,
					annualGrowth: dataInput.Presentations[0].inflation / 100,
					taxRate: sourceTypeKey===INCOMESOURCES.DIVIDEND_INCOME.Key? dataInput.Sources[i].taxRate/100:avgTaxRate
				});
			}
		}
		// console.log(dataE)
		return dataE;
	}

function setEstateContings () {
		let dataE = [];
		return dataE;
	}

function setIncomeNeeds (dataInput) {
		let dataItems = [];
		let i;
		// console.log(dataInput, dataItems)
		for (i = 0; i < dataInput.Needs.length; i++) {
			// console.log(dataInput.Needs[i])
			const needTypeKey = dataInput.Needs[i].needTypeKey
			dataItems.push({
				ID: Object.values(INCOMENEEDS).filter(obj => obj.Key=== needTypeKey)[0].ID,
				name: Object.values(INCOMENEEDS).filter(obj => obj.Key=== needTypeKey)[0].value.en,
					
				amount: dataInput.Needs[i].amount,
				incomePercent: dataInput.Needs[i].Percent/100,
				startYear: dataInput.Needs[i].startYear,
				duration: dataInput.Needs[i].duration,
				annualGrowth: dataInput.Presentations[0].inflation / 100
			});
		}
// console.log(dataInput, dataItems)
		let dataE = {
			incomePercentAfterDeath: 0.6,
			incomeNeedItems: dataItems,
			upToChildrenOutYrs: 0,
			childrenOutToRetirementYrs: 0,
			retirementToEndYrs: 0
		};

		return dataE;
	}

function setProjSettings (age,dataInput) {
		var tempDate = new Date();
 		var date = tempDate.getFullYear() + '-' + (tempDate.getMonth()+1) + '-' + tempDate.getDate();
  
		let dataE = {
			deathYear: 0,
			deathOf: 0,
			startYear: 1,
			endYear: 100-age+1,
			province: dataInput.Presentations[0].provinceKey,
			language: dataInput.Presentations[0].language==="en"?0:1,
			returnType: 4,
			projectEndOption: dataInput.Presentations[0].toRetirement ? 0 : 1,
			 clientsName1: dataInput.Presentations[0].designedFor, 
			 agentName:dataInput.Presentations[0].designedBy,
			 valuationDate:date, 
			 notes:dataInput.Presentations[0].notes,
			 version:versionDetails().version,
			 caller: appletMode

		};		
		return dataE;
	}

function setRates (dataInput) {
		// console.log(dataInput.Presentations[0].taxRate / 100)
		let dataE = {
			investmentRate: dataInput.Presentations[0].invRate / 100,
			taxRate: dataInput.Presentations[0].taxRate / 100,
			dividendTaxRate: 0.33,
			capitalGainsInclusion: 0.5,
			inflationRate: dataInput.Presentations[0].inflation / 100
			
		};

		return dataE;
	}

export function writeSavedDataToUI(savedJSon,dataInput)
    {
		// console.log(savedJSon)
        dataInput.Presentations[0].language=savedJSon.projectionSettings.language===0?"en":"fr";
        let i;
        dataInput.Clients=[];
		dataInput.clientsNo=savedJSon.lives.length;
		// console.log(data.dataInput.Clients)

		let smk;
		for (i = 0; i < savedJSon.lives.length; i++) {
			smk=savedJSon.lives[i].Smk<=2 ? "NS_STD":"S_STD";
			dataInput.Clients.push({ 
				id: i+1, 
				Age:savedJSon.lives[i].Age , 
				sexKey: //savedJSon.lives[i].Sex===0? SEX.MALE.Key : SEX.FEMALE.Key, 
				Object.values(SEX).filter(obj => obj.ID=== savedJSon.lives[i].Sex)[0].Key,
				smokerKey: smk==="NS_STD"?SMOKING.NON_SMOKER.Key:SMOKING.SMOKER.Key, 
				Income: savedJSon.lives[i].salary, 
				avgTaxRate: 100*savedJSon.lives[i].avgTaxRate, 
				//member: MEMBER[data.lang].Values[savedJSon.lives[i].member], 
				memberKey: //MEMBER.[savedJSon.lives[i].member].value[data.lang], 
				Object.values(MEMBER).filter(obj => obj.ID=== savedJSon.lives[i].member)[0].Key,
				retirementAge: savedJSon.lives[i].retirementAge, 
				Eligibility: 100*savedJSon.lives[i].CPPeligibility });
		}

		// console.log(data.dataInput.Clients)
	
		dataInput.Assets=[];
		dataInput.assetsNo=savedJSon.assets.length;
		
		for (i = 0; i < savedJSon.assets.length; i++) {
			// console.log(savedJSon.assets[i])
			// console.log((savedJSon.assets[i].owner),Object.values(ASSET_OWNERSHIP_ACTION).filter(obj => obj.ID=== savedJSon.assets[i].owner)[0].Key)
			// console.log(Object.values(ASSET_OWNERSHIP_ACTION).filter(obj => obj.ID=== savedJSon.assets[i].owner)[0].Key, Object.values(ASSET_TAX).filter(obj => obj.ID=== savedJSon.assets[i].taxMethod)[0].Key)
			dataInput.Assets.push({
				id: i+1,
				//assetTypeKey: Object.values(ASSETS).filter(obj => obj.ID=== savedJSon.assets[i].ID)[0].Key,
				assetTypeKey: findMatchingKey(Object.values(ASSETS),savedJSon.assets[i].name),
				ownerKey:Object.values(ASSET_OWNERSHIP_ACTION).filter(obj => obj.ID=== savedJSon.assets[i].owner)[0].Key,
				assetTaxTypeKey: Object.values(ASSET_TAX).filter(obj => obj.ID=== savedJSon.assets[i].taxMethod)[0].Key,
				currValue: savedJSon.assets[i].currValue,
				growth: savedJSon.assets[i].annualGrowth*100,
				DisposeYr: savedJSon.assets[i].dispositionYr,
				DisposeDur: savedJSon.assets[i].dispositionDur,
				ACB: savedJSon.assets[i].ACB,
				smallBusinessCapGainExemption: savedJSon.assets[i].smallBusinessCapGainExemption,
				contributionAmt:savedJSon.assets[i].contributionAmt,
				contributionStartYr: savedJSon.assets[i].contributionStartYr,
				contributionDur: savedJSon.assets[i].contributionDur,
				incomeRate:  savedJSon.assets[i].incomeRate*100,
				RRIFStartAge: savedJSon.assets[i].RRIFStartAge
			});
			// console.log(i)
			
		}

		dataInput.Liabilitys=[];
		dataInput.liabilitysNo=savedJSon.liabilities.length;
		
		for (i = 0; i < savedJSon.liabilities.length; i++) {
			// console.log(savedJSon.liabilities[i])
			// console.log(findMatchingKey(Object.values(LIABILITIES),savedJSon.liabilities[i].name))
			dataInput.Liabilitys.push({
				id: i+1,
				//liabTypeKey: Object.values(LIABILITIES).filter(obj => obj.ID=== savedJSon.liabilities[i].ID)[0].Key,
				liabTypeKey: findMatchingKey(Object.values(LIABILITIES),savedJSon.liabilities[i].name),
				ownerKey: OWNERSHIP.CLIENT.Key,
				currValue: savedJSon.liabilities[i].currValue,
				growthDir: savedJSon.liabilities[i].annualGrowth>=0? GROWTHDIR[dataInput.Presentations[0].language].Values[0]: GROWTHDIR[dataInput.Presentations[0].language].Values[1],
				growth: Math.abs(savedJSon.liabilities[i].annualGrowth*100),
				exposureDur: savedJSon.liabilities[i].exposureDur,
				assetTaxLiabID: 0,
				repay: savedJSon.liabilities[i].annualRepay,
				});
				// console.log(data)

		}
		// console.log(dataInput.Sources)
		// console.log(dataInput.sourcesNo)
		dataInput.Sources=[];
		// console.log(dataInput.sourcesNo)
		
		dataInput.sourcesNo=savedJSon.personalIncomeSources.length;
		// console.log(dataInput.sourcesNo)
		// console.log(Object.values(INCOMESOURCES).filter(obj => obj.value.en=== savedJSon.personalIncomeSources[0].Name))
			
		for (i = 0; i < savedJSon.personalIncomeSources.length; i++) {
			// console.log(savedJSon.personalIncomeSources[i])
				dataInput.Sources.push({
				id: i+1,
				//sourceTypeKey: Object.values(INCOMESOURCES).filter(obj => obj.ID=== savedJSon.personalIncomeSources[i].ID)[0].Key,
				//sourceTypeKey: Object.values(INCOMESOURCES).filter(obj => obj.value.en=== savedJSon.personalIncomeSources[i].Name)[0].Key,
				sourceTypeKey: findMatchingKey(Object.values(INCOMESOURCES),savedJSon.personalIncomeSources[i].Name),
				
				
				amount: savedJSon.personalIncomeSources[i].amount,
				startYear: savedJSon.personalIncomeSources[i].startYear,
				duration: savedJSon.personalIncomeSources[i].duration,
				taxRate: savedJSon.personalIncomeSources[i].taxRate*100
			//	ownerID: 0
				});
		}
		
		dataInput.Needs=[];
	
	//	console.log(savedJSon.incomeNeeds.incomeNeedItems.length)
	
		dataInput.needsNo=savedJSon.incomeNeeds.incomeNeedItems.length;
		
		for (i = 0; i < savedJSon.incomeNeeds.incomeNeedItems.length; i++) {
			//console.log(i,savedJSon.incomeNeeds.incomeNeedItems[i].amount, Object.values(INCOMENEEDS).filter(obj => obj.ID=== savedJSon.incomeNeeds.incomeNeedItems[i].ID)[0].Key)
			const needKey=findMatchingKey(Object.values(INCOMENEEDS), savedJSon.incomeNeeds.incomeNeedItems[i].name)
			let amt=savedJSon.incomeNeeds.incomeNeedItems[i].amount;
			if(needKey===INCOMENEEDS.PERCET_OF_INCOME.Key)
				amt=parseInt((savedJSon.incomeNeeds.incomeNeedItems[i].incomePercent) * getAfterTaxTotalIncome(dataInput.Clients,1))
			dataInput.Needs.push({
				id: i+1,
				//needTypeKey: Object.values(INCOMENEEDS).filter(obj => obj.ID=== savedJSon.incomeNeeds.incomeNeedItems[i].ID)[0].Key,
				//needTypeKey: Object.values(INCOMENEEDS).filter(obj => obj.value.en=== savedJSon.incomeNeeds.incomeNeedItems[i].name)[0].Key,
				needTypeKey: needKey,
				
				Percent: savedJSon.incomeNeeds.incomeNeedItems[i].incomePercent*100,
				amount: amt,
				startYear: savedJSon.incomeNeeds.incomeNeedItems[i].startYear,
				duration: savedJSon.incomeNeeds.incomeNeedItems[i].duration

			});
		}
		
		dataInput.Presentations=[];
		dataInput.presentationsNo=1;
		
		//for (i = 0; i < savedJSon.liabilities.length; i++) {
			console.log(savedJSon.projectionSettings)
			dataInput.Presentations.push({
						id: 1,
						provinceKey: Object.values(PROVINCE).filter(obj => obj.ID=== savedJSon.projectionSettings.province)[0].Key,
						invRate: savedJSon.ratesPack.investmentRate*100,
						inflation: savedJSon.ratesPack.inflationRate*100,
						taxRate:  savedJSon.ratesPack.taxRate*100,
						designedFor: savedJSon.projectionSettings.clientsName1,
						designedBy: savedJSon.projectionSettings.agentName,
						valuationDate: savedJSon.projectionSettings.valuationDate,
						notes: savedJSon.projectionSettings.notes,
						version: savedJSon.projectionSettings.version,
						language: savedJSon.projectionSettings.language===0?"en":"fr"
				  		
			});
		
		
		console.log(dataInput)
		
		return dataInput;
	}


	export function getOutputValues(data)
	{
		let output=
		{
			designedFor:"",
			designedBy:"",
			dateApplet:"",
			province:"",
			clients:[],
			assets:[],
			liabilities:[],
			source:[],
			totalLiab:0,
			Income:0,
			Income2:0,
			percentNeed1:0,
			percentNeed2:0,
			govDB:0,
			totalAsset:0,
			totalLiab:0,
			totalSource:0,
			totalSource2:0,
			percentNeed1:0,
			totalSource:0,
			percentNeed2:0,
			totalSource2:0,
			infRate:0,
			invRate:0,
			insNeedLE:0,
			insNeedRet:0,
			insNeedYgChild25:0,
			insNeedYgChild18 :0,
			ygChild: 100,
			hasChild: false
				
		}
	
		let dateObj = new Date();
		let month = dateObj.getUTCMonth() + 1; //months from 1-12
		let day = dateObj.getUTCDate();
		let year = dateObj.getUTCFullYear();
		const input=data.dataInput

		output.language=input.Presentations[0].language
		output.dateApplet =MONTHS[output.language][month - 1]+ " " + day + ", " + year
		  //output.language === "en"
		//	? months[month - 1] + " " + day + ", " + year
		//	: day + " " + monthsFr[month - 1] + " " + year;
		output.designedFor=input.Presentations[0].designedFor
		output.designedBy=input.Presentations[0].designedBy
		output.province=//input.Presentations[0].Province
			getListItemNameFromKey(PROVINCE,input.Presentations[0].provinceKey,output.language)
		
		//const retAge = input.Clients[0].retirementAge;
		//const retAge2 = input.Clients[1].retirementAge;
		output.Income = input.Clients[QUOTE_CLIENT].Income;
		output.Income2 =input.length>1? input.Clients[QUOTE_SPOUSE].Income:0;
		output.invRate = input.Presentations[0].invRate;
		output.infRate = input.Presentations[0]
		  .inflation;
		  output.insNeedRet = parseFloat(cleanFormat(data.insuranceNeedRet));
		  output.insNeedLE = parseFloat(cleanFormat(data.insuranceNeedLE));
	
		  output.ygChild = 100;
		  output.hasChild = false;
		const childMember = MEMBER.CHILD.Key;
		let Children = input.Clients.filter(function(item) {
		  return item.memberKey === childMember;
		});
		if (Children.length > 0) {
			output.hasChild = true;
		  Children.forEach(element => {
			if (element.Age <= output.ygChild) output.ygChild = element.Age;
		  });
		}
	
		console.log(data)
		output.insNeedYgChild25 = 0;
		output.insNeedYgChild18 = 0;
		for (
		  let i = 0;
		  i < 25 - output.ygChild;
		  output.insNeedYgChild25 +=
			data.dataShortfall[i++] /
			Math.pow(1 + output.invRate / 100, i - 1)
		);
		
		for (
		  let i = 0;
		  i < 18 - output.ygChild;
		  output.insNeedYgChild18 +=
			data.dataShortfall[i++] /
			Math.pow(1 + output.invRate / 100, i - 1)
		);
	
		output.insNeedYgChild25 = output.insNeedYgChild25 < 0 ? 0 : output.insNeedYgChild25;
		output.insNeedYgChild18 = output.insNeedYgChild18 < 0 ? 0 : output.insNeedYgChild18;
	
		/* let insNeedYgChild18=cleanFormat(insNeedRet)*((Math.pow(1+invRate/100,18-ygChild))/(Math.pow(1+invRate/100,retAge2-input.Clients[1].Age)));
			 let insNeedYgChild25=cleanFormat(insNeedRet)*((Math.pow(1+invRate/100,25-ygChild))/(Math.pow(1+invRate/100,retAge2-input.Clients[1].Age)));*/
	
		 output.liabilities = [];
	
		Object.values(LIABILITIES).forEach((element)  => {
		  if(element.order>0) output.liabilities.push({ name: element.value[output.language], value: 0 });
		});
		
		/* LIABILITIES[output.language].Values.forEach(function(element) {
		  liabilities.push({ name: element, value: 0 });
		}); */
/* 		output.incomeNeeds = [];
		INCOMENEEDS[output.language].Values.forEach(function(element) {
		  output.incomeNeeds.push({ name: element, value: 0 });
		});
 */		
		output.incomeNeeds = [];
		Object.values(INCOMENEEDS).forEach((element)  =>  {
		  output.incomeNeeds.push({ name: element.value[output.language], value: 0 });
		});
		
		
		// populate with what was assigned'
		output.totalLiab = 0;
		input.Liabilitys.forEach((element) => {
		  //let pos = liabilities.findIndex(i => i.name === element.Type);
		  /* let pos = liabilities.indexOf(
			liabilities.filter(i => i.name === element.Type)[0]
		  ); */
		  let pos = output.liabilities.indexOf(output.liabilities.filter(i => i.name === getListItemNameFromKey(LIABILITIES,element.liabTypeKey,output.language))[0]);
		  output.totalLiab += element.currValue;
		  if (pos !== undefined) output.liabilities[pos].value += element.currValue;
		});
	
		output.clients = [];
		input.Clients.forEach(function(element) {
		  let income = "$" + formatMoney(element.Income, 0, ",", ",");
		  output.clients.push({
			id: element.id,
			memberKey: element.memberKey,
			age: element.Age,
			income: element.memberKey === childMember ? " - " : income,
			ret: element.memberKey === childMember ? " - " : element.retirementAge
		  });
		});
	
		output.assets = [];
		Object.values(ASSETS).forEach((element)  =>  {
		  output.assets.push({ name: element.value[output.language], value: 0 });
		});
	
	/*     ASSETS[output.language].Values.forEach(function(element) {
		  assets.push({ name: element, value: 0 });
		}); */
	   /*  UNLISTED[output.language].Assets.Values.forEach(function(element) {
		  assets.push({ name: element, value: 0 });
		}); */
		output.totalAsset = 0;
		input.Assets.forEach((element) => {
		  //let pos = assets.findIndex(i => i.name === element.Type);
		  let pos = output.assets.indexOf(output.assets.filter(i => i.name === getListItemNameFromKey(ASSETS,element.assetTypeKey,output.language))[0]);
		  output.totalAsset += element.currValue;
		  if (pos !== undefined) output.assets[pos].value += element.currValue;
		});
	
		/* output.sources = [];
		output.govDB = 0;
		const srcDB =INCOMESOURCES.GOV_DEATH_BENEFIT.value[output.language];
		INCOMESOURCES[output.language].Values.forEach(function(element) {
		  output.sources.push({ name: element, value: 0 });
		}); */
	
		output.sources = [];
		output.govDB = 0;
		const srcDB =INCOMESOURCES.GOV_DEATH_BENEFIT.Key;//value[output.language];
		Object.values(INCOMESOURCES).forEach((element)  =>  {
		  output.sources.push({ name: element.value[output.language], value: 0 });
		});


		// populate with what was assigned'
		output.totalSource = 0;
		output.totalSource2 = 0;
		// NOTE "this" is not available inside inline functions, hence:
		// or just use arrow functions
		let srcOrphan =INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key;//value[output.language];
		input.Sources.forEach(function(element) {
		 /*  let pos = output.sources.indexOf(
			output.sources.filter(i => i.name === element.Type)[0]
		  );
		   */
		  let pos = output.sources.indexOf(output.sources.filter(i => i.name === getListItemNameFromKey(INCOMESOURCES,element.sourceTypeKey,output.language))[0]);
		   // console.log(pos)
		 	



		  if (element.sourceTypeKey === srcDB) {
			// add gov DB
			output.govDB = element.amount;
			output.totalAsset += output.govDB;
		  } else {
			output.totalSource += element.amount;
			// no orphans
			output.totalSource2 += element.sourceTypeKey !== srcOrphan ? element.amount : 0;
		  }
		  if (pos !== undefined) output.sources[pos].value += element.amount;
		  // console.log(output.sources[pos].value)
		});
		// remove gov db from sources
		output.sources = output.sources.filter(i => i.name !== getListItemNameFromKey(INCOMESOURCES, srcDB,output.language));//output.srcDB);
	
		output.percentNeed1 = 0;
		output.percentNeed2 = 0;
		output.percent1 = 0;
		output.percent2 = 0;
		var totalNeed = 0;
		output.needPercent = INCOMENEEDS.PERCET_OF_INCOME.Key;
		/* output.needs = [];
		INCOMENEEDS[output.language].Values.forEach(function(element) {
		  output.needs.push({ name: element, value: 0 });
		});
 */
		output.needs = [];
		Object.values(INCOMENEEDS).forEach((element)  =>  {
		  output.needs.push({ name: element.value[output.language], value: 0 });
		});
	

		output.totalNeed=0
		input.Needs.forEach(function(element) {
		  //let pos = needs.findIndex(i => i.name === element.Type);
		  //let pos = output.needs.indexOf(output.needs.filter(i => i.name === element.Type)[0]);
		  let pos = output.needs.indexOf(output.needs.filter(i => i.name === getListItemNameFromKey(INCOMENEEDS,element.needTypeKey,output.language))[0]);
		   
		  output.totalNeed += element.amount;
		  if (element.needTypeKey === output.needPercent) {
			if (output.percent1 === 0) {
			  output.percent1 = element.Percent;
			  output.percentNeed1 = element.amount;
			} else {
			  output.percent2 = element.Percent;
			  output.percentNeed2 = element.amount;
			}
		  }
		  if (pos !== undefined) output.needs[pos].value += element.amount;
		});
	
		//		if (data.dataCashFlowGov !== undefined)
		//			var maxYScale = 10000 * Math.ceil(1 + Math.max(Math.max(...data.dataCashFlowGov), Math.max(...data.dataCashFlowNeeds), Math.max(...data.dataShortfall), Math.max(...data.dataCashFlowPersonal)) / 10000);

		return output;
	}	
	
	function findMatchingKey(objValues,nameFromFile){
		// console.log(objValues,nameFromFile)
		return objValues.filter(obj => obj.value.en.replace(/ /g, "")
		.replace(
		  /[\u00A0\u1680​\u180e\u2000-\u2009\u200a​\u200b​\u202f\u205f​\u3000]/g,
		  "")== nameFromFile.replace(/ /g, "")
		  .replace(
			/[\u00A0\u1680​\u180e\u2000-\u2009\u200a​\u200b​\u202f\u205f​\u3000]/g,
			"")
			||
			obj.value.fr.replace(/ /g, "")
		.replace(
		  /[\u00A0\u1680​\u180e\u2000-\u2009\u200a​\u200b​\u202f\u205f​\u3000]/g,
		  "")== nameFromFile.replace(/ /g, "")
		  .replace(
			/[\u00A0\u1680​\u180e\u2000-\u2009\u200a​\u200b​\u202f\u205f​\u3000]/g,
			""))[0].Key


	}