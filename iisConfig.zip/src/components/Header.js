import { TITLES} from '../definitions/generalDefinitions';
import React, { Component } from 'react';
import { Info } from './Info';

//import {convertToINA} from '../utils/helper'
import {versionDetails,
	isVersion2019, isMobileDevice} from '../utils/helper';
import { version} from '../../package.json';

export function hideRecover(){
		document.getElementById("last").style.display = 'none';
	}

export class Header extends Component {
	constructor(props) {
		super(props);
		
	}
 hideRecover=()=>{
	 	const last =document.getElementById("last");
		if( last !== undefined) last.style.display = 'none';
	}
	

	render() {
		
		let style1= this.props.language==="en" ? {right: '45px'}:  {right: '55px'};
		let style2= this.props.language==="en" ? {right: '90px'}:  {right: '152px'};
		let style3= this.props.language==="en" ? {right: versionDetails.EmailINA?'135px':'92px'}:  {right: versionDetails.EmailINA?'200px':'151px'};
		//if(isVersion2019())
		//	style3= this.props.language==="en" ? {right: '90px'}:  {right: '152px'};
		var iOS =isMobileDevice();// /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
		const class1=iOS===true?"headerBarIOS":"headerBar";
		let to="msamiei@ppi.ca";
		
		const styleTitle= iOS===true? {color: '#282e31',marginBottom: '8px',marginTop: '-10px'}:{color: '#282e31',marginBottom: '8px'}
		const styleVersion= iOS===true? {fontSize:'10px'}:{display: 'inline-block', fontSize:'10px', paddingLeft: '4px'}
		return (
				<div className={class1}>
							<input className="language" style={{ marginTop: '0px',right:'0px'}} onClick={this.props.changeLang} type="button" value={this.props.language === "en" ? "Français" : "English"} />
						<span><div style={{maxWidth: '70%'}}><div style={{display: 'inline-block'}}><h2 style={styleTitle}>{this.props.title}</h2></div><div style= {styleVersion}>({version})</div></div></span> 
								<span style={{ marginRight: '0px',marginTop: '0px', float: 'right' }}>
									<input className="titleButtons" onClick={this.props.saveToFile} style={style1} type="button" value={this.props.language=== "en"?"Save":"Enregistrer"} />
									<label className="titleButtons"   style={{right:'0px'}}>
										<input type="file" required style={{ display: 'none' }} onChange={this.props.loadFromFile} onClick={(event) => { event.target.value = null }} />
										<span className="titleLoad" >{this.props.language=== "en"?"Load":"Ouvrir"}</span>
									</label>
									{versionDetails.EmailINA && 
									<input className="titleButtons" style={style2} onClick={this.props.EmailINA}  type="button" value={this.props.language=== "en"?"email":""} id="email" />}
									<input className="titleButtons" style={style3} onClick={(event) => { this.props.loadStorage(); hideRecover();}}  type="button" value={this.props.language=== "en"?"Recover":"Récupérer"} id="last" />
									{/*<input className="titleButtons" onClick={this.EmailINA} style={{right: '130px'}} type="button" value={this.props.language=== "en"?"Email":"Email"} />*/}
									
								</span>
					

					
				
				</div>
			);
	}
}
