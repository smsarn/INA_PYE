﻿import React, { Component } from "react";
import { DropDown } from "./DropDown";
import { InputField } from "./inputField";

import {appletMode } from "../../package.json";
import { AddRemove } from "./AddRemove";
import {
  getListToShowByOrder,
  getProjectedLiability,
  cleanFormat,
  getListItemNameFromKey,
  getListItemKeyFromName
} from "../utils/helper";

import {
  LIABILITIES,
  ASSETS,
  OWNERSHIP,
  CONTROLTITLE,
  GROWTHDIR,
  UNLISTED,
  ASSET_TaxCredit
} from "../definitions/generalDefinitions";
import { isMobileDevice } from "../utils/helper";
import DataTable from "./GridExcelComponent/DataTable";
import { fetchAssetProjection } from "../utils/FetchAPIs";
import {
  LIABILITY_API_OUTPUT_Year,
  LIABILITY_API_OUTPUT_Age,
  LIABILITY_API_OUTPUT_ProjectedValue,
  LIABILITY_API_OUTPUT_TaxCredit,
  DROPDOWN_WIDE
} from "../definitions/generalDefinitions";

export class Liability extends Component {
  displayName = Liability.name;

  constructor(props) {
    super(props);
    this.state = {
      displaySreadsheet: false
    };
    var i;
    var typeValues = [];
    const listLiabsToShow = getListToShowByOrder(LIABILITIES);
    for (i = 0; i < listLiabsToShow.length; ++i) {
      typeValues.push({
        label: listLiabsToShow[i].value[this.props.language],
        value: i + 1
      });
    }
    var ownerValues = [
      { label: OWNERSHIP.CLIENT.value[this.props.language] , value: 1 },
      { label: OWNERSHIP.SPOUSE.value[this.props.language] , value: 2 },
      { label: OWNERSHIP.JOINT.value[this.props.language] , value: 3 }
    ];

    var growthDirValues = [
      { label: GROWTHDIR[this.props.language].Values[0], value: 1 },
      { label: GROWTHDIR[this.props.language].Values[1], value: 2 }
    ];

    this.dataValues = {
      DD: [
        {
          id: 1,
          Title: CONTROLTITLE[this.props.language].type,
          defValue:getListItemNameFromKey(LIABILITIES,this.props.liabilityCurr.liabTypeKey,this.props.language),
          Values: typeValues
        },
        {
          id: 2,
          Title: CONTROLTITLE[this.props.language].owner,
          defValue: getListItemNameFromKey(OWNERSHIP, this.props.liabilityCurr.ownerKey,this.props.language),
          Values: ownerValues
        },
        {
          id: 3,
          Title: CONTROLTITLE[this.props.language].growthDir,
          defValue: this.props.liabilityCurr.growthDir,
          Values: growthDirValues
        }
      ]
    };
    this.dataProjection = [];
    this.dataColTitles = [];
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.liabilityCurr  !== this.props.liabilityCurr
        || nextProps.id !== this.props.id
        || nextProps.liabilitysNo !== this.props.liabilitysNo
      ) {
      // console.log(nextProps.liabilityCurr.liabTypeKey)
      this.dataValues.DD[0].defValue = getListItemNameFromKey(LIABILITIES,nextProps.liabilityCurr.liabTypeKey,this.props.language);
      this.dataValues.DD[1].defValue = getListItemNameFromKey(OWNERSHIP,nextProps.liabilityCurr.ownerKey,this.props.language);
      this.dataValues.DD[2].defValue = nextProps.liabilityCurr.growthDir;

      if (this.props.liabilityCurr.liabTypeKey ===    LIABILITIES.CHARITABLE_GIFTS.Key
      ) {
        // console.log(this.props.liabilityCurr.liabTypeKey )
        this.props.handleAddAssetTaxCredit(ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key
          //UNLISTED[this.props.language].Assets.Values[ASSET_TaxCredit]
        );
      }

    }
  }

  componentDidUpdate = async (prevProps, prevState) => {
    if (prevProps.liabTypeKey !== this.props.liabTypeKey) {
      // create a client tax credit asset if charty gift
     // alert(this.props.liabilityCurr.liabTypeKey )
      if (
        this.props.liabilityCurr.liabTypeKey ===    LIABILITIES.CHARITABLE_GIFTS.Key
      ) {
       // alert(this.props.liabilityCurr.liabTypeKey )
        this.props.handleAddAssetTaxCredit(
          UNLISTED[this.props.language].Assets.Values[ASSET_TaxCredit]
        );
      }
    }
  };

  handleDoRemove = id => {
    this.props.handleRemoveLiability(id);
  };

  handleDoAdd = () => {
    var liabNo =
      this.props.liabilitysNo > this.dataValues.DD[0].Values.length - 1
        ? this.dataValues.DD[0].Values.length - 1
        : this.props.liabilitysNo;

    var liabNext = this.dataValues.DD[0].Values[liabNo].label;
    const liabTypeKey = getListItemKeyFromName(LIABILITIES, liabNext);

    let liability = {
      id: this.props.liabilitysNo + 1,
      //Type: liabNext,
      liabTypeKey:liabTypeKey,
      ownerKey: OWNERSHIP.CLIENT.Key,
      currValue: 0,
      growthDir: GROWTHDIR[this.props.language].Values[0],
      growth: 0,
      repay: 0,
      exposureDur: 99,
      assetTaxLiabID: 0,
      assetTaxLiabProj: []
    };

    liability = this.setLiabilityValuesToDefault(liability);

    
    this.props.handleAddLiability(liability); //liabNext);
  };

  updateDDown = (id, selection) => {
    let liability = {
      id: this.props.liabilityCurr.id,
      //Type: this.props.liabilityCurr.Type,
      liabTypeKey:this.props.liabilityCurr.liabTypeKey,
      ownerKey: this.props.liabilityCurr.ownerKey,
      currValue: this.props.liabilityCurr.currValue,
      growth: this.props.liabilityCurr.growth,
      growthDir: this.props.liabilityCurr.growthDir,
      exposureDur: this.props.liabilityCurr.exposureDur,
      repay: this.props.liabilityCurr.repay
    };
    if (id === 1) {
      //liability.Type = selection;
      liability.liabTypeKey= getListItemKeyFromName(LIABILITIES, selection);
    
    } else if (id === 2) {
      liability.ownerKey = getListItemKeyFromName(OWNERSHIP, selection);
    } else if (id === 3) {
      liability.growthDir = selection;
    }

    liability = this.setLiabilityValuesToDefault(liability);

    this.props.handleUpdate(liability);
  };

  handleUpdateInput = (id, value) => {
    let liability = {
      id: this.props.liabilityCurr.id,
      //Type: this.props.liabilityCurr.Type,
      liabTypeKey: this.props.liabilityCurr.liabTypeKey,
      ownerKey: this.props.liabilityCurr.ownerKey,
      currValue: this.props.liabilityCurr.currValue,
      growth: this.props.liabilityCurr.growth,
      exposureDur: this.props.liabilityCurr.exposureDur,
      repay: this.props.liabilityCurr.repay,
      growthDir: this.props.liabilityCurr.growthDir
    };

    let changed = false;
    if (id === 1) {
      changed =
        liability.currValue !== parseInt(cleanFormat(value)) ? true : false;
      liability.currValue = parseInt(cleanFormat(value));
    } else if (id === 2) {
      changed =
        liability.growth !==
        parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
      liability.growth =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    } else if (id === 3) {
      changed = liability.exposureDur !== parseInt(value) ? true : false;
      liability.exposureDur = parseInt(value);
    }
    if (id === 4) {
      changed = liability.repay !== parseInt(cleanFormat(value)) ? true : false;
      liability.repay = parseInt(cleanFormat(value));
    }

    if (changed) this.props.handleUpdate(liability);
  };

  handleClick = () => {
    //let dataNA = this.props.getAssetProjection();
    //let appSiteAPI = "http://localhost:8082";
    //fetchAssetProjection(appSiteAPI, dataNA, this.props.id).then(data => {
    // if (data[0] !== undefined) {
    //  console.log("POST: NA_AssetProj success");

    //		'Registered')
    this.dataColTitles = [
      "Year",
      "Projected Value"
      //   "Tax Credit"
    ];

    let liabs = getProjectedLiability(
      this.props.liabilityCurr,
      this.props.language
    );
    let years = [];
    let i;
    for (i = 0; i < this.props.liabilityCurr.exposureDur; ++i) years.push(i);

    let taxCredits = [];
    this.dataProjection[0] = years;
    //this.dataProjection[1] = ages;
    this.dataProjection[1] = liabs;
    //this.dataProjection[3] = taxCredits;

    // console.log(this.dataProjection);

    this.setState(prevState => {
      let display = prevState.displaySreadsheet;
      return { displaySreadsheet: !display };
    });
  };
  //});
  //}

  setLiabilityValuesToDefault = liability => {
    if (
      liability.liabTypeKey ===
      LIABILITIES.OUTSTANDING_LOANS.Key
    ) {
      liability.exposureDur = 10;
    } else if (
      liability.liabTypeKey ===
      LIABILITIES.MORTGAGE_REDEMPTION.Key
    ) {
      liability.exposureDur = 25;
    }

    return liability;
  };

  render() {
    const growthSel = GROWTHDIR[this.props.language].Values.indexOf(
      this.props.liabilityCurr.growthDir
    );

    const loanOrTax =
      this.props.liabilityCurr.liabTypeKey ===
        LIABILITIES.OUTSTANDING_LOANS.Key ||
      this.props.liabilityCurr.liabTypeKey ===
        LIABILITIES.MORTGAGE_REDEMPTION.Key ||
      this.props.liabilityCurr.liabTypeKey ===
        LIABILITIES.CLIENT_TAX_LIABILITY.Key;
    
    const showGrowth=appletMode!=="INA" && !loanOrTax &&
    this.dataValues.DD.map(
      dd =>
        dd.id === 3)
    const showRepay=appletMode!=="INA" &&(this.props.liabilityCurr.liabTypeKey ===
      LIABILITIES.MORTGAGE_REDEMPTION.Key ||
      this.props.liabilityCurr.liabTypeKey ===
        LIABILITIES.OUTSTANDING_LOANS.Key)

    const showExposure=appletMode!=="INA" && !(
      this.props.liabilityCurr.liabTypeKey ===
      LIABILITIES.CLIENT_TAX_LIABILITY.Key
    )
    
      
// console.log(this.props.liabilityCurr.id,this.props.liabilityCurr.liabTypeKey,this.props.liabilitysNo)

    return (
      <div className="inputRow">
        {this.dataValues.DD.map(
          (
            dd // don't show ownership dosen't matter
          ) =>
            dd.id < 3 &&
            !(dd.id === 2) && (
              <DropDown
                key={dd.id}
                id={dd.id}
                Count={this.props.liabilitysNo}
                Title={dd.Title}
                width={DROPDOWN_WIDE}
                defValue={dd.defValue}
                Values={dd.Values}
                updateDDown={this.updateDDown}
              />
            )
        )}
        <InputField
          inputName={CONTROLTITLE[this.props.language].amount}
          id={1}
          format={2}
          Count={this.props.liabilitysNo}
          language={this.props.language}
          inputValue={this.props.liabilityCurr.currValue}
          handleUpdateInput={this.handleUpdateInput}
        />
        
        {showRepay && (
          <InputField
            inputName={CONTROLTITLE[this.props.language].repay}
            id={4}
            format={2}
            Count={this.props.liabilitysNo}
            language={this.props.language}
            inputValue={this.props.liabilityCurr.repay}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}

        {appletMode!=="INA" && !loanOrTax &&
          this.dataValues.DD.map(
            dd =>
              dd.id === 3 &&
               (
                <DropDown
                  key={dd.id}
                  id={dd.id}
                  Count={this.props.liabilitysNo}
                  Title={dd.Title}
                  defValue={dd.defValue}
                  Values={dd.Values}
                  updateDDown={this.updateDDown}
                />
              )
          )}
        {appletMode!=="INA" && !loanOrTax && (
          <InputField
            inputName={
              growthSel === 0
                ? CONTROLTITLE[this.props.language].growth
                : CONTROLTITLE[this.props.language].changeRate
            }
            id={2}
            format={3}
            Count={this.props.liabilitysNo}
            language={this.props.language}
            inputValue={this.props.liabilityCurr.growth}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}

        {showExposure && (
          <InputField
            inputName={CONTROLTITLE[this.props.language].exposureDur}
            id={3}
            format={1}
            Count={this.props.liabilitysNo}
            language={this.props.language}
            inputValue={this.props.liabilityCurr.exposureDur}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}

{appletMode!=="INA" && (
        
        <img
          className="iconMore"
          onClick={this.handleClick}
          id="gridOn"
          alt="ll"
          src={
            this.state.displaySreadsheet === true
              ? require("../images/gridOff.png")
              : require("../images/gridOn.png")
          }
        />)}

        <AddRemove
          currentID={this.props.liabilityCurr.id}
          minComps={0}
          id={this.props.liabilityCurr.liabTypeKey}
          numberComps={this.props.liabilitysNo}
          handleDoAdd={this.handleDoAdd}
          handleDoRemove={this.handleDoRemove}
        />
        {/*isMobileDevice() &&
        this.props.liabilityCurr.id < this.props.liabilitysNo ? (
          <hr className="ppi2" />
        ) : (
          ""
        )*/}
        {this.state.displaySreadsheet === true && (
          <div style={{ clear: "both", float: "left", width: "60%" }}>
            <DataTable
              gridColumnsHeaders={this.dataColTitles}
              gridColumnsDataMain={this.dataProjection}
              gridTitle={getListItemNameFromKey(LIABILITIES,this.props.liabilityCurr.liabTypeKey,this.props.language) + " Projection"}
              language={this.props.language}
            />
          </div>
        )}
      </div>
    );
  }
}
