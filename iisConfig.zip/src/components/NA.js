﻿import React, { Component } from "react";
import { Client } from "./Client";
import { defaults } from "react-chartjs-2";
import { Asset } from "./Asset";
import { Liability } from "./Liability";
import { Source } from "./Source";
import { Need } from "./Need";
import { Header, hideRecover } from "./Header";
import { Presentation } from "./Presentation";
import { PopupUserinputDialog } from "./PopupUserInput";
//import { Collapsible } from "./AccPanel";
import { Collapsible } from "./Collapsible";
//import { getINAGridData } from "./ExcelSpreadsheetINA";
//import { getEPGridData } from "./ExcelSpreadsheetEP";
import {
  getEPGridData,
  getINAGridData,
} from "../data/aggregateGridProjections";
import { AggregateGrid } from "./AggregateGrid";
import { singleFieldValidation } from "../utils/validation";
import _ from "lodash";
import {
  fetchInsuranceNeedsData,
  fetchTimerAPICheck,
  convertProvince,
  getTaxRate,
  fetchGovBenefits,
  handleFetchInsuranceNeedsNew,
  //getGovBenefits
} from "../utils/FetchAPIs";
import debounce from "lodash.debounce";
import queryString from "query-string";
import { MultiButtons } from "./MultiButtons";
import { saveAs } from "file-saver";
import { OutputPresentation } from "./outputPresentation";
import { OutputPresentationEP } from "./outputPresentationEP";
import { OutputGraphs } from "./OutputGraphs";
import { OutputGraphsEP } from "./OutputGraphsEP";
import { AnalysisGraphs } from "./AnalysisGraph";
//import { ExcelSpreadsheetEP } from "./OLD_ExcelSpreadsheetEP2";
import {
  MESSAGES,
  ASSETS,
  PROVINCE,
  ASSET_TAX,
  INCOMESOURCES,
  OWNERSHIP,
  SEX,
  SMOKING,
  MEMBER,
  //LIABILITIES,
  LIABILITIES,
  TITLES,
  INCOMENEEDS,
  GROWTHDIR,
  ASSET_OWNERSHIP_ACTION,
  COLUMN_TITLES,
} from "../definitions/generalDefinitions";
import { AddRemove } from "./AddRemove";
import { Info } from "./Info";
import {
  isMobileDevice,
  clearListCookies,
  //isVersion2019,
  versionDetails,
  //INAFullSpreadsheetHeaders,
  //INAFullSpreadsheetData,
  getINA_LifeExp_Plus_yrs,
  getDataFutureEstateLiability,
  getProjectedLiabilities,
  getListItemKeyFromName,
} from "../utils/helper";
import {
  QUOTE_CLIENT,
  QUOTE_SPOUSE,
  appSiteAPI,
  DISPLAY_RETIREMENT,
  DISPLAY_LIFEEXP,
  DISPLAY_ENDAGE,
  DISPLAY_LIFEEXP_PLUS_3,
  ORPHAN_AGE_QC,
  ORPHAN_AGE_NON_QC,
  MAX_ORPHAN_DUR_QC,
  MAX_ORPHAN_DUR_NON_QC,
  UNIVERSITY_START_AGE,
  UNIVERSITY_END_AGE,
  DISPLAY_PRESENTATION,
  DISPLAY_GRAPHS,
  DISPLAY_SPREADSHEET,
  DISPLAY_ANALYSIS,
} from "../definitions/generalDefinitions";

import "isomorphic-fetch";
import shortid from "shortid";
import { UserInput } from "./UserInput";
import { buildMode, appletMode } from "../../package.json";
import { setUIDataToAPI, writeSavedDataToUI } from "../data/dataExchange";
import {
  createDefaultAsset,
  createDefaultPres,
  createDefaultClient,
  createDefaultSource,
  createDefaultNeed,
  createDefaultLiab,
} from "../data/createDefaults";
import {
  getInfoNoInternetAccess,
  getInfoIconSourcesGov,
  getGenericMessage,
} from "../definitions/infoIconsDefinitions";

import { getAssetGridValues } from "../data/assetGridProjections";

const COLLAPSIBLE_CLIENTS = 0;
const COLLAPSIBLE_ASSETS = 1;
const COLLAPSIBLE_LIABS = 2;
const COLLAPSIBLE_SOURCES = 3;
const COLLAPSIBLE_NEEDS = 4;
const COLLAPSIBLE_PRESENTATION = 5;
const COLLAPSIBLE_RESULTS = 6;

const COLLAPSIBLES_COUNT = 7;
const COLLAPSIBLES_CLOSED = false;
const COLLAPSIBLES_OPEN = true;

const DISPLAY_INCOME = 1;
const DISPLAY_TAXLIAB = 2;

const waitTime = 1800;

const SITE_TEST = "https://test-tkdirect";

// to send it to Proxy make API site ""
//const API_SITE="https://ppitoolkitapi.azurewebsites.net"
const API_SITE_PROD = ""; //"https://privateapi.ppi.ca/ToolkitDirect"
const API_SITE_TEST = ""; //"https://test-tkdirectapi.ppi.ca";
const API_SITE_LOCAL = "http://localhost:8082"; // ""; turn this to "" and use proxy server on 3003, first turn on from toolkitDirectProxy Server projet by npm start
//const API_SITE_LOCAL="http://www.toolkitdirectapi.com";
//const API_SITE="";

const PARENT_SITE_LOCAL = "http://localhost:8083";
const PARENT_SITE_TEST = "https://test-tkdirect.ppi.ca/";
const PARENT_SITE_PROD = "https://toolkitdirect.ppi.ca/";
const MODE_SAVE = 0;
const MODE_EMAIL = 1;

//"local"=0 "test-tkdirect"=1 "toolkitdirect" =2}
/* let appSiteAPI =
  buildMode === 0
    ? API_SITE_LOCAL
    : buildMode === 1
    ? API_SITE_TEST
    : API_SITE_PROD; */
let appSiteParent =
  buildMode === 0
    ? PARENT_SITE_LOCAL
    : buildMode === 1
    ? PARENT_SITE_TEST
    : PARENT_SITE_PROD;

defaults.global.maintainAspectRatio = false;

export class NA extends Component {
  displayName = appletMode;
  constructor(props) {
    super(props);
    this.excel = React.createRef();

    // define default starting clients assets .etc. rows
    let defaultClients = [];
    defaultClients.push(createDefaultClient(1));
    if (appletMode === "INA") defaultClients.push(createDefaultClient(2));
    const defaultSources = [createDefaultSource(1)];
    const defaultAsset = [createDefaultAsset(1)];
    const defaultLiab = [createDefaultLiab(1)];
    let defaultNeeds = [];
    defaultNeeds.push(createDefaultNeed(1));
    defaultNeeds.push(createDefaultNeed(2));
    const defaultPresentation = [createDefaultPres(1, this.provinceMargTax)];

    // build state with defaults
    this.state = {
      dataInput: {
        Clients: defaultClients, //, clientsNo: defaultClients.length },
        Assets: [], //, assetsNo: defaultAsset.length },
        Liabilitys: defaultLiab, //, liabilitysNo: 1 },
        Sources: defaultSources, //, sourcesNo: 1 },
        Needs: defaultNeeds, //,  needsNo: 2},
        Presentations: defaultPresentation, //, presentationsNo: 1 },
      },
      dataOutput: {
        dataInsuranceNeeds: [],
        dataCashFlowPersonal: [],
        dataTaxLiability: [],
        dataCashFlowGov: [],
        dataCashFlowNeeds: [],
        dataNAAges: [],
        dataShortfall: [],
        govBenefits: { cppSurvivor: null, cppDB: null, cppOrphan: null },
        lifeExpectancy: { client: 0, spouse: 0, joint: 0 },
        assetProjections: [],
        aggregateGrid: null,
      },
      /*  dataInput: { Clients: defaultClients },//, clientsNo: defaultClients.length },
      dataInput: { Assets: [] },//, assetsNo: defaultAsset.length },
      dataInput: { Liabilitys: defaultLiab },//, liabilitysNo: 1 },
      dataInput: { Sources: defaultSources },//, sourcesNo: 1 },
      dataInput: { Needs: defaultNeeds },//,  needsNo: 2},
      dataInput: { Presentations: defaultPresentation },//, presentationsNo: 1 }, */

      loading: true,
      failedAPI: false,
      showMsg: false,
    };
    /* this.state.dataOutput = {
      dataInsuranceNeeds: [],
      dataCashFlowPersonal: [],
      dataTaxLiability: [],
      dataCashFlowGov: [],
      dataCashFlowNeeds: [],
      dataNAAges: [],
      dataShortfall: [],
      govBenefits: { cppSurvivor: null, cppDB: null, cppOrphan: null },
      lifeExpectancy: { client: 0, spouse: 0, joint: 0 },
      assetProjections: [],
      aggregateGrid: null
    } */
    this.openCollapsible = [];
    let i;
    for (i = 0; i < COLLAPSIBLES_COUNT; ++i) {
      this.openCollapsible.push({
        open: COLLAPSIBLES_CLOSED,
        id: i,
      });
    }
    // open first bar
    this.openCollapsible[COLLAPSIBLE_CLIENTS].open = COLLAPSIBLES_OPEN;

    this.showRecover = 1;
    this.survIdx = appletMode === "INA" ? QUOTE_SPOUSE : QUOTE_CLIENT;
    this.graphs = false;

    //this.projectEndOption = DISPLAY_RETIREMENT;
    this.OKToRemove = true;
    //this.toRetirement = true;
    //this.periodOption = appletMode === "INA" ? DISPLAY_RETIREMENT : DISPLAY_ENDAGE;
    this.accessedAPI = false;
    //this.state.govBenefits.cpp = 0;
    //this.state.govBenefits.cppDB = 0;
    //this.lifeExp = 0;
    //this.lifeExpJLTD = 0;
    //this.lifeExpClient = 0;
    //this.orphan = 0;
    //this.orphan = 0;
    this.openParent = true;
    this.openForce = true;
    this.resultIsOpen = false;
    this.langText = "Français";
    /*   this.dataInsuranceNeeds = [];
      this.dataCashFlowPersonal = []; */
    this.provinceMargTax = 0;
    /* this.dataTaxLiability = [];
    this.dataCashFlowGov = [];
    this.dataCashFlowNeeds = [];
    this.dataNAAges = [];
    this.dataShortfall = []; */
    this.visibleOutputSection = 0;
    this.dataQS = "";
    this.intervalID = 0;
    this.INAOption = appletMode === "INA" ? DISPLAY_INCOME : DISPLAY_LIFEEXP;
    this.failedRemove = false;
  }

  afterTwoSeconds = (value) => {
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(value);
      }, 2000);
    });
  };

  govBenefits = async () => {
    // if not there add

    if (appletMode === "INA") {
      //this.failedRemove=false
      let gov1 = INCOMESOURCES.GOV_SURVIVORS_PENSION.Key; //value[this.state.dataInput.Presentations[0].language];
      let gov = this.state.dataInput.Sources.find(
        (x) => x.sourceTypeKey === gov1
      );

      let gov2 = INCOMESOURCES.GOV_DEATH_BENEFIT.Key; //value[this.state.dataInput.Presentations[0].language];
      let govDB = this.state.dataInput.Sources.find(
        (x) => x.sourceTypeKey === gov2
      );

      // console.log(this.cpp)
      if (gov === undefined || govDB === undefined) {
        const sourceGovSurv = {
          id: this.state.dataInput.Sources.length + 1, //sourcesNo + 1,
          sourceTypeKey: INCOMESOURCES.GOV_SURVIVORS_PENSION.Key,
          amount: parseInt(this.state.dataOutput.govBenefits.cppSurvivor), // * this.state.dataInput.Clients[QUOTE_CLIENT].Eligibility) / 100,
          startYear: 0,
          duration: 100,
          ownerID: 2,
        };
        const sourceGovDB = {
          id: this.state.dataInput.sourcesNo + 1,
          sourceTypeKey: INCOMESOURCES.GOV_DEATH_BENEFIT.Key,
          amount: parseInt(this.state.dataOutput.govBenefits.cppDB),
          startYear: 0,
          duration: 100,
          ownerID: 2,
        };
        await this.handleAddSource(sourceGovSurv);
        await this.handleAddSource(sourceGovDB);
      } else {
        let sourceGovSurv = gov;
        gov.amount = parseInt(this.state.dataOutput.govBenefits.cppSurvivor);

        //let gov2 = INCOMESOURCES.GOV_DEATH_BENEFIT.Key;//value[this.state.dataInput.Presentations[0].language];
        //let govDB = this.state.dataInput.Sources.find(x => x.sourceTypeKey === gov2);

        let sourceGovDB = govDB;
        govDB.amount = parseInt(this.state.dataOutput.govBenefits.cppDB);

        await this.handleUpdateSource(gov);
        await this.handleUpdateSource(govDB);
      }
      let govOrphan = INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key;
      //let govOrphans = this.state.dataInput.Sources.find(x => x.sourceTypeKey=== "GOV_ORPHANS_BENEFIT");
      let govOrphans = this.state.dataInput.Sources.filter(function (item) {
        return item.sourceTypeKey === govOrphan;
      });

      //alert(this.orphan)
      if (govOrphans.length > 0) {
        for (let i = 0; i < govOrphans.length; i++) {
          govOrphans[i].amount = parseInt(
            this.state.dataOutput.govBenefits.cppOrphan
          );
          await this.handleUpdateSource(govOrphans[i]);
        }
      } else if (this.areThereChildren() === true) this.manageOrphan();
      // console.log(govOrphans,this.state.govBenefits.cpp,this.orphan)

      /* console.log(this.state.dataInput.Sources)
        console.log(govOrphans,this.state.govBenefits.cpp,this.orphan)
        if(govOrphans !==undefined)
        {
          alert(govOrphans.length)
          if (govOrphans.amount===0) this.handleFetchInsuranceNeedsData()
          for (let i = 0; i < govOrphans.length; ++i) {
            
            govOrphans[i].amount= parseInt(this.orphan)
              this.handleUpdateSource(govOrphans[i]);
            }
        }; */
    }
  };

  componentDidMount = async () => {
    const defaultAsset = createDefaultAsset(1);
    await this.handleAddAsset(defaultAsset);

    /* const defaultClient1 = createDefaultClient(1);
    this.handleAddClient(defaultClient1)
    const defaultClient2 = createDefaultClient(2);
    this.handleAddClient(defaultClient2)
 */
    const query = queryString.parse(window.location.search);
    if (query.lang === "fr") {
      this.changeLang();
    }
    // console.log(query);
    //	console.log("Site: " + process.env.REACT_APP_SITE_URL);
    //	console.log(window.env.API_URL);

    if (query.QS !== undefined) {
      console.log(query.QS);
      this.handleFetchQueryStringGet(query.QS);
      /* fetch(appSiteAPI+'/api/NA_QS?QS='+ query.QS)
			.then(response => response.json())
			.then(data => 
					{
						console.log(data);
						let objJSONData=writeSavedDataToUI(data,this.state);
						console.log(objJSONData);
						this.updateState(objJSONData);
					}
			) 
			.catch(error => {// console.log(error);
			}); */
    }

    // console.log(ASSET_TAX.NON_TAXABLE.Key)
    this.intervalID = setInterval(this.loadData, 100000);

    localStorage.setItem("INAAPIFails", parseInt(0));

    this.OKToRemove = true;
    //this.handleClick(1);
    //this.handleFetchInsuranceNeeds();
    //this.handleUpdataData()

    let presentation = this.state.dataInput.Presentations[0];
    await this.handleUpdatePresentation(presentation, true);

    await this.govBenefits();

    /* setTimeout(this.afterTwoSeconds=()=> {
				this.handleAddSource(INCOMESOURCES.GOV_SURVIVORS_PENSION.value[this.state.dataInput.Presentations[0].language], parseInt(this.state.govBenefits.cpp) * this.state.dataInput.Clients[QUOTE_CLIENT].Eligibility / 100,100,2, 0);
				this.handleAddSource(INCOMESOURCES.GOV_DEATH_BENEFIT.value[this.state.dataInput.Presentations[0].language], parseInt(this.state.govBenefits.cppDB),100,2, 0);

			}, 400) */
  };

  /* debounceHandleFetchInsuranceNeeds = debounce(() => {
    this.handleFetchInsuranceNeeds();
  }, waitTime);
 */

  /* Region gets all API calls if necessary, debounce if necessary */
  debounceHandleUpdataData = debounce(
    () => this.handleUpdataData, //async () => {
    /* const dataNA = await setUIDataToAPI(this.state.dataInput);

    const data = await handleFetchInsuranceNeedsNew(dataNA, this.state.dataInput)
    console.log(data)
    await this.populateOutput(data)

    await this.updateOutputData() */
    //}
    waitTime
  );

  handleUpdataData = async () => {
    //await this.handleFetchInsuranceNeeds();
    const dataNA = await setUIDataToAPI(this.state.dataInput);

    const data = await handleFetchInsuranceNeedsNew(
      dataNA,
      this.state.dataInput
    );
    console.log(data);
    await this.populateOutput(data);
    this.state.dataInput.Assets.forEach(async (element) => {
      await this.updateProjection(element);
    });
    await this.updateOutputData();
  };

  handleUpdateOutput = async (newStateCandidateInput, dataOutput) => {
    //await this.handleFetchInsuranceNeeds();
    const dataNA = await setUIDataToAPI(newStateCandidateInput);

    // main output data
    const data = await handleFetchInsuranceNeedsNew(
      dataNA,
      newStateCandidateInput
    );
    let newStateCandidateOutput = this.populateOutput2(data, dataOutput);

    // assets projs
    newStateCandidateOutput.assetProjections = await this.updateAssetProjectionOutput(
      dataNA,
      newStateCandidateInput,
      newStateCandidateOutput
    );

    // liabs projs

    // aggregate grid proj
    newStateCandidateOutput.aggregateGrid = await this.updateOutputData2(
      newStateCandidateInput,
      newStateCandidateOutput
    );
    console.log(newStateCandidateOutput);
    return newStateCandidateOutput;
  };
  /* end Region */

  updateAssetProjectionOutput = async (
    dataNA,
    newStateCandidateInput,
    newStateCandidateOutput
  ) => {
    let assProjs = [];
    for (let i = 0; i < newStateCandidateInput.Assets.length; i++) {
      const element = newStateCandidateInput.Assets[i];
      let projection = await getAssetGridValues(
        dataNA,
        element,
        newStateCandidateInput.Presentations[0].language,
        false
      ); //    this.updateProjection2(element,dataNA)
      console.log(projection);
      let a = newStateCandidateOutput.assetProjections.find(
        (e) => e.id === element.id
      );
      console.log(a);
      if (a !== undefined) {
        a.grid = projection;
        console.log(a);
      } else
        newStateCandidateOutput.assetProjections.push({
          id: element.id,
          grid: projection,
        });

      console.log(newStateCandidateOutput.assetProjections[0].grid);
    }

    console.log(newStateCandidateOutput);
    return newStateCandidateOutput.assetProjections;
  };

  populateOutput2 = (dataOutputCandidate, dataOutput) => {
    dataOutput.dataInsuranceNeeds = dataOutputCandidate.dataInsuranceNeeds;
    dataOutput.dataCashFlowPersonal =
      dataOutputCandidate.dataCashFlowPersonal.numericValues;
    dataOutput.dataTaxLiability =
      dataOutputCandidate.dataTaxLiability.numericValues;
    dataOutput.dataCashFlowGov =
      dataOutputCandidate.dataCashFlowGov.numericValues;
    dataOutput.dataCashFlowNeeds =
      dataOutputCandidate.dataCashFlowNeeds.numericValues;
    dataOutput.dataNAAges = dataOutputCandidate.dataNAAges.numericValues;
    dataOutput.dataShortfall = dataOutputCandidate.dataShortfall.numericValues;
    dataOutput.govBenefits.cppSurvivor = dataOutputCandidate.cpp;
    dataOutput.govBenefits.cppDB = dataOutputCandidate.cppDB;
    dataOutput.govBenefits.cppOrphan = dataOutputCandidate.orphan;
    dataOutput.lifeExpectancy.client = dataOutputCandidate.lifeExpClient;
    dataOutput.lifeExpectancy.spouse = dataOutputCandidate.lifeExp;
    dataOutput.lifeExpectancy.joint = dataOutputCandidate.lifeExpJLTD;

    return dataOutput;
  };

  populateOutput = async (data) => {
    let dataOutput = this.state.dataOutput;

    dataOutput.dataInsuranceNeeds = data.dataInsuranceNeeds;
    dataOutput.dataCashFlowPersonal = data.dataCashFlowPersonal.numericValues;
    dataOutput.dataTaxLiability = data.dataTaxLiability.numericValues;
    dataOutput.dataCashFlowGov = data.dataCashFlowGov.numericValues;
    dataOutput.dataCashFlowNeeds = data.dataCashFlowNeeds.numericValues;
    dataOutput.dataNAAges = data.dataNAAges.numericValues;
    dataOutput.dataShortfall = data.dataShortfall.numericValues;
    dataOutput.govBenefits.cppSurvivor = data.cpp;
    dataOutput.govBenefits.cppDB = data.cppDB;
    dataOutput.govBenefits.cppOrphan = data.orphan;
    dataOutput.lifeExpectancy.client = data.lifeExpClient;
    dataOutput.lifeExpectancy.spouse = data.lifeExp;
    dataOutput.lifeExpectancy.joint = data.lifeExpJLTD;

    this.setState({ dataOutput: dataOutput });
  };

  /*  handleFetchInsuranceNeeds = async () => {
     // get tax rate
     let dataP = this.state.dataInput;
     /* const tr=await getTaxRate(appSiteAPI,"PERSONAL_INCOME", convertProvince(dataP.Presentations[0].Province,this.state.dataInput.Presentations[0].language))                                                                         
     dataP.Presentations[0].taxRate=(Math.round(tr*10000)/100).toFixed(4);
  
     // now get just INA numbers
     let dataNA;
     /* if (version >= "1.0.1")
       dataNA = setUIDataToAPI1(this.state);
     else 
     dataNA = setUIDataToAPI(this.state);
     //console.log('Data sent to POST');
     console.log("Data sent to POST:");
     //console.log(dataNA);
 
     let url = appSiteAPI + "/api/NA_InsuranceNeeds/";
 
     this.setState({ ...this.state, loading: true });
     fetch(url, {
       method: "POST",
       //			redirect: 'follow',
       //			credentials: 'same-origin',
       headers: {
         Accept: "application/json",
         "Content-Type": "application/json"
       },
       body: JSON.stringify(dataNA)
     })
       .then(response => {
         if (response.ok === false) {
           throw Error(response.statusText);
         }
         return response;
       })
       .then(response => response.json())
       .then(data => {
         if (data !== undefined) {
           console.log("POST: NA_InsuranceNeeds success");
           this.dataInsuranceNeeds = data;
           // make render
 
           this.setState({ loading: false, dataInput: dataP }, () =>
             // now get all INA data
             this.handleFetchInsuranceNeedsData()
           );
         }
       })
       .catch(error => {
         //window.location.reload(true);
         console.log("handleFetchInsuranceNeeds failed: ", error);
         // this.setState({failedAPI: true});
         /* this.saveToStorage();
         //alert(window.parent.location.href +"&ina="+ shortid.generate());
         let url=PARENT_SITE_PROD+"?ina="+ shortid.generate();
         //console.log(window.parent.location.href);
         //alert(url);
         const url2=window.location.href;
         console.log(url2);
         console.log(url2.indexOf(SITE_TEST));
       	
         alert("You need to login again. Your data has been saved. Click 'Recover' in INA to load your input data.")
         document.getElementById("dialog").dialog("open");
       	
 
         if (url2.indexOf(SITE_TEST)!==-1)
           url=PARENT_SITE_TEST+"?ina="+ shortid.generate();
       	
         //url=window.parent.location.href+(window.parent.location.href.includes("?")?"&":"?")+"ina="+ shortid.generate();
         //url="https://adfs.ppi.ca/adfs/ls?wa=wsignout1.0";
         window.parent.location.href =url;// window.parent.location.href+(window.parent.location.href.includes("?")?"&":"?")+"ina="+ Math.random();
          
       });
   }; */

  /* handleFetchInsuranceNeedsData = async () => {
    let dataNA = setUIDataToAPI(this.state);
    // console.log(dataNA);
    let data = await fetchInsuranceNeedsData(dataNA)

    if (data !== undefined) {
      // console.log(data[0]);
      console.log("POST: NA_OutputAll success");
      this.dataNAAges = data.ages;
      this.dataCashFlowGov = data.govCF;
      this.dataCashFlowPersonal = data.personalCF;
      this.dataCashFlowNeeds = data.needs;
      this.dataShortfall = data.shortfall;
      this.state.govBenefits.cpp = data.cpp;
      this.state.govBenefits.cppDB = data.cppDB;
      this.orphan = data.orphan;
      this.lifeExp = data.lifeExp;
      this.lifeExpClient = data.lifeExpClient;
      this.lifeExpJLTD = data.lifeExpJLTD;
      this.provinceMargTax = data.provinceMargTax;
      this.dataTaxLiability = data.dataTaxLiability;

    /* fetchInsuranceNeedsData(dataNA).then(data =>  {
        /* console.log(data[0]);
        if (data[1] !== undefined) {
          console.log("POST: NA_OutputAll success");
          this.dataNAAges = data[1];
          this.dataCashFlowGov = data[3];
          this.dataCashFlowPersonal = data[4];
          this.dataCashFlowNeeds = data[5];
          this.dataShortfall = data[6];
          this.state.govBenefits.cpp = data[7].Values[0];
          this.state.govBenefits.cppDB = Math.round(data[8].Values[0]);
          this.orphan = Math.round(data[9].Values[0]);
          this.lifeExp = Math.round(data[12].Values[0]);
          this.lifeExpClient = Math.round(data[13].Values[0]);
          this.lifeExpJLTD = Math.round(data[14].Values[0]);
          this.provinceMargTax = data[15].Values[0];
          this.dataTaxLiability = data[16]; 
        // make render
        let l = this.state.loading;
        l = false;

        this.setState({ l });//, () => this.waitForSetStateCallback(0, 0));
      }
    };
 */
  /* 




  let url = appSiteAPI + "/api/NA_OutputAll/";

  fetch(url, {
    method: "POST",
    //			redirect: 'follow',
    //			credentials: 'same-origin',
    headers: {
      Accept: "application/json",
      "Content-Type": "application/json"
    },
    body: JSON.stringify(dataNA)
  })
    .then(response => {
      if (response.ok === false) {
        throw Error(response.statusText);
      }
      return response;
    })
    .then(response => response.json())
    .then(data => {
      if (data[1] !== undefined) {
        console.log("POST: NA_OutputAll success");
        this.dataNAAges = data[1];
        this.dataCashFlowGov = data[3];
        this.dataCashFlowPersonal = data[4];
        this.dataCashFlowNeeds = data[5];
        this.dataShortfall = data[6];
        this.state.govBenefits.cpp = data[7].Values[0];
        this.state.govBenefits.cppDB = Math.round(data[8].Values[0]);
        this.orphan = Math.round(data[9].Values[0]);
        this.lifeExp = Math.round(data[12].Values[0]);
        // make render
        let l = this.state.loading;
        l = false;
        this.setState({ l }, () => this.waitForSetStateCallback(0, 0));
      }
    })
    .catch(error => {
      console.log("handleFetchInsuranceNeedsData failed: " + error);
      // this.setState({failedAPI: true});
    });
};

/* handleFetchAssetProjection = () => {
  let dataNA = setUIDataToAPI(this.state);

  return dataNA;
};
*/
  handleFetchQueryString = (mode) => {
    let dataNA = setUIDataToAPI(this.state.dataInput);
    // console.log(dataNA);

    let url = appSiteAPI + "/api/NA_QS/";

    this.setState({ ...this.state });
    fetch(url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(dataNA),
    })
      .then((response) => {
        if (response.ok === false) {
          throw Error(response.statusText);
        }
        return response;
      })
      .then((response) => response.json())
      .then((data) => {
        if (data !== undefined) {
          this.dataQS = data;
          if (mode === MODE_SAVE) this.setState({ showMsg: true });
          else if (mode === MODE_EMAIL)
            window.location.href =
              "mailto: ?subject= Needs Analysis Quote &body=The following link takes you to the landing page of Toolkit Direct. Once there, click on Insurance Needs Analysis to open up the attached quote.%0D%0A" +
              appSiteParent +
              "?QS=" +
              this.dataQS;
        }
      })
      .catch((error) => {
        console.log("handleFetchQueryString failed: " + error);
        // this.setState({failedAPI: true});
      });
  };

  handleFetchQueryStringGet = (contentsFile) => {
    fetch(appSiteAPI + "/api/NA_QS?QS=" + contentsFile)
      .then((response) => {
        if (response.ok === false) {
          throw Error(response.statusText);
        }
        return response;
      })
      .then((response) => response.json())
      .then(async (data) => {
        console.log("file data: ");
        console.log(contentsFile); //, data, this.state);
        let objJSONData = writeSavedDataToUI(data, this.state.dataInput);
        console.log(objJSONData);
        // update gov bens
        await this.govBenefits();
        // update asset proj
        this.state.dataInput.Assets.forEach(async (element) => {
          await this.updateProjection(element);
        });
        this.updateStateInput(objJSONData, () =>
          this.waitForSetStateCallback()
        );
      })
      .catch((error) => {
        console.log("handleFetchQueryStringGet failed: " + error);
        // console.log(this.state);
      });
  };

  // handle data updates
  updateState = (data) => {
    this.setState({ data }, () => this.waitForSetStateCallback(0));
  };
  // handle data updates
  updateStateInput = (dataInput) => {
    this.setState({ dataInput: dataInput }, () =>
      this.waitForSetStateCallback()
    );
  };

  handleUpdateClient = async (client) => {
    // keep render to just once until or if needed. this also avoids flshing page before final render
    this.setState({ loading: true });

    const { dataOutput, dataInput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    newDataInput.Clients[client.id - 1] = client;

    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );

    this.setState({ ...newState, loading: false });
  };

  reSync_reCalculate_reRender = async (
    newStateCandidateInput,
    dataOutput,
    debounce
  ) => {
    // reSync
    newStateCandidateInput = this.syncPanelsValues2(newStateCandidateInput);

    let newStateCandidateOutput;
    // reCalculate
    if (debounce)
      newStateCandidateOutput = await this.debounceHandleUpdateOutput(
        newStateCandidateInput,
        dataOutput
      );
    else
      newStateCandidateOutput = await this.handleUpdateOutput(
        newStateCandidateInput,
        dataOutput
      );
    if (newStateCandidateOutput.assetProjections[0] !== undefined) {
      console.log(newStateCandidateOutput);
      console.log(newStateCandidateOutput.assetProjections[0].grid);
      //console.log(newStateCandidateOutput.assetProjections.grid.dataProjection[2])
      //alert('setS0   ' + newStateCandidateOutput.assetProjections.grid.dataProjection[2][0])
      //console.log('setS0   ' + newStateCandidateOutput.assetProjections.grid.dataProjection[2][0])}
    }

    return {
      dataInput: newStateCandidateInput,
      dataOutput: newStateCandidateOutput,
    };
    //if(this.state.dataOutput.assetProjections[0]!==undefined)
    //alert('setS1   ' + this.state.dataOutput.assetProjections.grid.dataProjection[2][0])
  };

  updateOutputData = async () => {
    if (true) {
      //appletMode === "INA") {
      let insNeed = 0;
      let insNeedRet = 0;
      let insNeedLE = 0;
      let insNeedEAge = 0;
      let insNeedLE3 = 0;
      let dataGov;
      let dataAges;
      let dataPCV;
      let dataNeed;
      let dataShort;

      let hasSurivor = false;
      /*       const spKey = appletMode === "INA" ? MEMBER.SPOUSE.Key : MEMBER.CLIENT.Key;
            let Survivor = this.state.dataInput.Clients.find(x => x.memberKey === spKey);
      
            if (Survivor !== undefined) {
              hasSurivor = true;
            }
       */
      const Survivor = this.state.dataInput.Clients[this.survIdx]; //.find(x => x.memberKey === spKey);
      if (Survivor !== undefined) {
        hasSurivor = true;
      }

      const dataOutput = this.state.dataOutput;
      const insuranceNeeds = dataOutput.dataInsuranceNeeds;
      const periodOption = this.state.dataInput.Presentations[0].periodOption;

      const inputOutputIsValid =
        insuranceNeeds.length > 0 &&
        dataOutput.dataNAAges !== undefined &&
        Survivor !== undefined;

      if (inputOutputIsValid) {
        if (this.state.dataOutput.dataInsuranceNeeds.length > 0) {
          insNeed =
            periodOption === DISPLAY_RETIREMENT
              ? insuranceNeeds[DISPLAY_RETIREMENT].Value
              : periodOption === DISPLAY_LIFEEXP
              ? insuranceNeeds[DISPLAY_LIFEEXP].Value
              : periodOption === DISPLAY_LIFEEXP_PLUS_3
              ? getINA_LifeExp_Plus_yrs(
                  insuranceNeeds[DISPLAY_LIFEEXP].Value,
                  dataOutput.dataShortfall,
                  this.state.dataInput.Presentations[0].invRate,
                  dataOutput.lifeExpectancy.spouse,
                  3
                )
              : insuranceNeeds[DISPLAY_ENDAGE].Value;
          insNeedRet = insuranceNeeds[DISPLAY_RETIREMENT].Value;
          insNeedLE = insuranceNeeds[DISPLAY_LIFEEXP].Value;
          insNeedEAge = insuranceNeeds[DISPLAY_ENDAGE].Value;
          insNeedLE3 =
            dataOutput.dataShortfall !== undefined
              ? getINA_LifeExp_Plus_yrs(
                  insuranceNeeds[DISPLAY_LIFEEXP].Value,
                  dataOutput.dataShortfall,
                  this.state.dataInput.Presentations[0].invRate,
                  dataOutput.lifeExpectancy.joint,
                  3
                )
              : insNeed;
        }

        let projectEnd = 65;
        let noProjectYrs = 0;
        let survAge;

        if (this.survIdx !== -1 && this.survIdx !== undefined) {
          projectEnd =
            periodOption === DISPLAY_RETIREMENT
              ? this.state.dataInput.Clients[this.survIdx].retirementAge
              : periodOption === DISPLAY_LIFEEXP
              ? dataOutput.lifeExpectancy.spouse +
                this.state.dataInput.Clients[this.survIdx].Age
              : periodOption === DISPLAY_ANALYSIS
              ? dataOutput.lifeExpectancy.joint +
                this.state.dataInput.Clients[this.survIdx].Age +
                3
              : 99;
          noProjectYrs =
            projectEnd - this.state.dataInput.Clients[this.survIdx].Age;
          survAge = this.state.dataInput.Clients[this.survIdx].Age;
        } else survAge = this.state.dataInput.Clients[QUOTE_CLIENT].Age;

        dataAges = dataOutput.dataNAAges.slice(0, noProjectYrs);
        dataGov = dataOutput.dataCashFlowGov.slice(0, noProjectYrs);
        dataPCV = dataOutput.dataCashFlowPersonal.slice(0, noProjectYrs);
        dataNeed = dataOutput.dataCashFlowNeeds.slice(0, noProjectYrs);
        dataShort = dataOutput.dataShortfall.slice(0, noProjectYrs);

        let aggregateGrid;
        if (appletMode === "INA") {
          aggregateGrid = await getINAGridData(
            insNeed,
            insNeedRet,
            insNeedLE,
            dataPCV,
            Survivor,
            dataNeed,
            dataGov,
            dataShort,
            this.state.dataInput.Presentations[0].inflation,
            this.state.dataInput.Presentations[0].language,
            this.state.dataInput.Presentations[0].invRate,
            this.state.dataInput.Sources,
            dataOutput.govBenefits.cppDB *
              (1 - this.state.dataInput.Clients[QUOTE_CLIENT].avgTaxRate / 100)
          );
        } else if (appletMode === "EP") {
          aggregateGrid = await getEPGridData(
            noProjectYrs,
            this.state.dataInput
          );
        }
        let output = this.state.dataOutput;
        output.aggregateGrid = aggregateGrid;
        console.log(aggregateGrid);
        this.setState({ dataOutput: output });
      }
    }
  };

  updateOutputData2 = async (
    newStateCandidateInput,
    newStateCandidateOutput
  ) => {
    if (true) {
      //appletMode === "INA") {
      let insNeed = 0;
      let insNeedRet = 0;
      let insNeedLE = 0;
      let insNeedEAge = 0;
      let insNeedLE3 = 0;
      let dataGov;
      let dataAges;
      let dataPCV;
      let dataNeed;
      let dataShort;

      let hasSurivor = false;

      let aggregateGrid;

      /*       const spKey = appletMode === "INA" ? MEMBER.SPOUSE.Key : MEMBER.CLIENT.Key;
            let Survivor = this.state.dataInput.Clients.find(x => x.memberKey === spKey);
      
            if (Survivor !== undefined) {
              hasSurivor = true;
            }
       */
      const Survivor = newStateCandidateInput.Clients[this.survIdx]; //.find(x => x.memberKey === spKey);
      if (Survivor !== undefined) {
        hasSurivor = true;
      }

      const insuranceNeeds = newStateCandidateOutput.dataInsuranceNeeds;
      const periodOption = newStateCandidateInput.Presentations[0].periodOption;

      const inputOutputIsValid =
        insuranceNeeds.length > 0 &&
        newStateCandidateOutput.dataNAAges !== undefined &&
        Survivor !== undefined;

      if (inputOutputIsValid) {
        if (newStateCandidateOutput.dataInsuranceNeeds.length > 0) {
          insNeed =
            periodOption === DISPLAY_RETIREMENT
              ? insuranceNeeds[DISPLAY_RETIREMENT].Value
              : periodOption === DISPLAY_LIFEEXP
              ? insuranceNeeds[DISPLAY_LIFEEXP].Value
              : periodOption === DISPLAY_LIFEEXP_PLUS_3
              ? getINA_LifeExp_Plus_yrs(
                  insuranceNeeds[DISPLAY_LIFEEXP].Value,
                  newStateCandidateOutput.dataShortfall,
                  newStateCandidateInput.Presentations[0].invRate,
                  newStateCandidateOutput.lifeExpectancy.spouse,
                  3
                )
              : insuranceNeeds[DISPLAY_ENDAGE].Value;
          insNeedRet = insuranceNeeds[DISPLAY_RETIREMENT].Value;
          insNeedLE = insuranceNeeds[DISPLAY_LIFEEXP].Value;
          insNeedEAge = insuranceNeeds[DISPLAY_ENDAGE].Value;
          insNeedLE3 =
            newStateCandidateOutput.dataShortfall !== undefined
              ? getINA_LifeExp_Plus_yrs(
                  insuranceNeeds[DISPLAY_LIFEEXP].Value,
                  newStateCandidateOutput.dataShortfall,
                  newStateCandidateInput.Presentations[0].invRate,
                  newStateCandidateOutput.lifeExpectancy.joint,
                  3
                )
              : insNeed;
        }

        let projectEnd = 65;
        let noProjectYrs = 0;
        let survAge;

        if (this.survIdx !== -1 && this.survIdx !== undefined) {
          projectEnd =
            periodOption === DISPLAY_RETIREMENT
              ? newStateCandidateInput.Clients[this.survIdx].retirementAge
              : periodOption === DISPLAY_LIFEEXP
              ? newStateCandidateOutput.lifeExpectancy.spouse +
                newStateCandidateInput.Clients[this.survIdx].Age
              : periodOption === DISPLAY_ANALYSIS
              ? newStateCandidateOutput.lifeExpectancy.joint +
                newStateCandidateInput.Clients[this.survIdx].Age +
                3
              : 99;
          noProjectYrs =
            projectEnd - newStateCandidateInput.Clients[this.survIdx].Age;
          survAge = newStateCandidateInput.Clients[this.survIdx].Age;
        } else survAge = newStateCandidateInput.Clients[QUOTE_CLIENT].Age;

        dataAges = newStateCandidateOutput.dataNAAges.slice(0, noProjectYrs);
        dataGov = newStateCandidateOutput.dataCashFlowGov.slice(
          0,
          noProjectYrs
        );
        dataPCV = newStateCandidateOutput.dataCashFlowPersonal.slice(
          0,
          noProjectYrs
        );
        dataNeed = newStateCandidateOutput.dataCashFlowNeeds.slice(
          0,
          noProjectYrs
        );
        dataShort = newStateCandidateOutput.dataShortfall.slice(
          0,
          noProjectYrs
        );

        if (appletMode === "INA") {
          aggregateGrid = await getINAGridData(
            insNeed,
            insNeedRet,
            insNeedLE,
            dataPCV,
            Survivor,
            dataNeed,
            dataGov,
            dataShort,
            newStateCandidateInput.Presentations[0].inflation,
            newStateCandidateInput.Presentations[0].language,
            newStateCandidateInput.Presentations[0].invRate,
            newStateCandidateInput.Sources,
            newStateCandidateOutput.govBenefits.cppDB *
              (1 -
                newStateCandidateInput.Clients[QUOTE_CLIENT].avgTaxRate / 100)
          );
        } else if (appletMode === "EP") {
          aggregateGrid = await getEPGridData(
            noProjectYrs,
            newStateCandidateInput
          );
        }
      }
      return aggregateGrid;
    }
  };

  switchClients = () => {
    if (
      this.state.dataInput.Clients.find(
        (x) => x.memberKey === MEMBER.SPOUSE.Key
      ) !== undefined
    ) {
      let data2 = this.state.dataInput;
      let client1 = data2.Clients[QUOTE_CLIENT];
      data2.Clients[QUOTE_CLIENT] = data2.Clients[QUOTE_SPOUSE];
      data2.Clients[QUOTE_SPOUSE] = client1;
      // keep member
      data2.Clients[QUOTE_CLIENT].memberKey = MEMBER.CLIENT.Key;
      data2.Clients[QUOTE_SPOUSE].memberKey = MEMBER.SPOUSE.Key;
      data2 = this.syncPanelsValues2(data2);
      this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(0)
      );
    }
  };

  handleUpdateAsset = async (asset) => {
    // console.log(asset)
    this.setState({ loading: true });
    const { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    if (asset.assetTypeKey === ASSETS.RRSP_RRIF.Key) this.addRRIFSource(asset);

    newDataInput.Assets[asset.id - 1] = asset;

    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });

    /* this.setState(
      { dataInput: dataA, loading: true },
      () => this.waitForSetStateCallback(0)
    ); */
    //await this.updateProjection(asset)
  };

  /*   handleUpdateAsset = asset => {
      // console.log(asset)
      if (asset.assetTypeKey === ASSETS.RRSP_RRIF.Key)
        this.addRRIFSource(asset)
  
      this.setState(
        prevState => {
          let data2 = { ...prevState.dataInput };
          data2.Assets[asset.id - 1] = asset;
          return { dataInput: data2 };
        },
        () => this.waitForSetStateCallback(0)
      );
    };
   */

  handleUpdateLiability = async (liability) => {
    this.setState({ loading: true });
    let { dataInput, dataOutput } = this.state.dataInput;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    newDataInput.Liabilitys[liability.id - 1] = liability;

    // before updating state, resync, recalcuate, then update state to re_render
    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });

    /* this.setState({ dataInput: data2 }, () =>
      this.waitForSetStateCallback()
    ); */
  };

  handleUpdateSource = async (source, updateState = true) => {
    // console.log(source, this.state.dataInput.Sources)
    console.log("this");
    let { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    newDataInput.Sources[source.id - 1] = source;

    if (updateState) {
      this.setState({ loading: true });
      // before updating state, resync, recalcuate, then update state to re_render
      const newState = await this.reSync_reCalculate_reRender(
        newDataInput,
        newDataOutput
      );
      this.setState({ ...newState, loading: false });
    } else {
      return dataInput;
    }
    //this.setState({ dataInput: data2 }, () => this.waitForSetStateCallback());
  };

  handleUpdateNeed = async (need) => {
    this.setState({ loading: true });
    let { dataInput, dataOutput } = this.state.dataInput;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    newDataOutput.Needs[need.id - 1] = need;

    // before updating state, resync, recalcuate, then update state to re_render
    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });

    //this.setState({ dataInput: data2 }, () => this.waitForSetStateCallback(0));
  };

  handleUpdatePresentation = async (presentation, init) => {
    this.setState({ loading: true });
    let { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);

    // update tax rate
    if (
      init === true ||
      newDataInput.Presentations[0].provinceKey !== presentation.provinceKey
    ) {
      const tr = await getTaxRate(
        "PERSONAL_INCOME",
        presentation.provinceKey
        //convertProvince(presentation.provinceKey, this.state.dataInput.Presentations[0].language)
      );
      presentation.taxRate = (Math.round(tr * 10000) / 100).toFixed(4);
    }
    // update gov bens
    /* if (presentation.provinceKey === "QC" || this.state.dataInput.Presentations[0].provinceKey === "QC") {

      await this.handleUpdateGovbenefits(presentation.provinceKey)
      
    } */

    let debounce = false;
    if (
      newDataInput.Presentations[0].designedBy !== presentation.designedBy ||
      newDataInput.Presentations[0].designedFor !== presentation.designedFor ||
      newDataInput.Presentations[0].notes !== presentation.notes
    )
      debounce = true;

    newDataInput.Presentations[presentation.id - 1] = presentation;

    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );

    // before eupdating state, resync, recalcuate, update state to re_render
    this.setState({ ...newState, loading: false });
    // use debounce re Notes, des for and des by
    //  data2 = this.syncPanelsValues2(data2);
    //  this.setState({ dataInput: data2 }, () => this.waitForSetStateCallback(0, debounce));
    //this.syncPanelsValues2(2);
    await this.govBenefits();
  };

  handleUpdateGovbenefits = async (provinceKey) => {
    let dataNA = setUIDataToAPI(this.state.dataInput);
    let data = await fetchGovBenefits(dataNA, provinceKey);
    // console.log(data)

    let data3 = this.state.dataOutput;
    if (data !== undefined) {
      data3.govBenefits.cppSurvivor = data.cpp;
      data3.govBenefits.cppDB = data.cppDB;
      data3.govBenefits.cppOrphan = data.orphan;
    }
    this.setState({ dataOutput: data3 });

    await this.govBenefits();
  };

  // handle adding component rows
  updateStateAdd = (data) => {
    this.setState({ data }, () => this.waitForSetStateCallback(0));
  };

  handleAddClient = async (client) => {
    this.setState({ loading: true });
    const { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    newDataInput.Clients.push(client);

    // resync, recalcuate, then update state to re_render
    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });
    //this.setState({ dataInput: data2 }, () => this.manageAddingChild());
    //this.syncPanelsValues2(1);
  };

  manageAddingChild = () => {
    this.manageEducation();
    this.manageOrphan();
    this.waitForSetStateCallback(0);
  };

  handleAddAsset = async (asset) => {
    this.setState({ loading: true });

    const { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    if (asset === undefined) {
      asset = createDefaultAsset(1);
    }
    //  dataInput.assetsNo++;
    newDataInput.Assets.push(asset);
    // add RRIF if RRSP
    if (asset.assetTypeKey === ASSETS.RRSP_RRIF.Key)
      //this.addRRIFSource(asset)
      newDataInput = this.addRRIFSource2(asset, newDataInput);

    // resync, recalcuate, then update state to re_render
    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });

    /*     this.setState({ dataInput: dataInput, loading: true }, () =>
      this.waitForSetStateCallback(0) // no need to save to storage when default is added
    );
 */ //await this.updateProjection(asset)
  };

  updateProjection = async (asset) => {
    /*  updateProjection = async (asset) => {
         let dataOA = this.state.output
      let dataNA = await setUIDataToAPI(this.state);
      dataOA.assetProjection = await getAssetGridValues(dataNA, asset, this.state.dataInput.Presentations[0].language, false)
      this.setState({ output: dataOA, loading: false }); */
    let dataInput = this.state.dataInput;
    console.log(dataInput, asset.id);
    let dataNA = await setUIDataToAPI(this.state.dataInput);
    dataInput.Assets[asset.id - 1].projection = await getAssetGridValues(
      dataNA,
      asset,
      this.state.dataInput.Presentations[0].language,
      false
    );
    console.log(dataInput.Assets[asset.id - 1].projection);
    this.setState({ dataInput: dataInput, loading: false }, () =>
      console.log(dataInput)
    );
  };

  handleAddAssetTaxLiability = (taxLiab, assetTaxLiabID) => {
    let data2 = this.state.dataInput;
    // check if already there
    let exists = false;
    data2.Liabilitys.forEach((element) => {
      if (element.assetTaxLiabID === assetTaxLiabID) {
        if (taxLiab[0] === 0) this.handleRemoveLiability(element.id);
        else {
          element.currValue = taxLiab[0];
          element.assetTaxLiabProj = taxLiab;
          exists = true;
        }
      }
    });

    if (exists === false && taxLiab[0] > 0) {
      if (exists === false) {
        //data2.liabilitysNo++;
        data2.Liabilitys.push({
          id: this.state.dataInput.Liabilitys.length, //liabilitysNo,
          //Type: LIABILITIES.OTHER.value[this.state.dataInput.Presentations[0].language],
          liabTypeKey: LIABILITIES.OTHER.Key,
          ownerKey: OWNERSHIP.SPOUSE.Key,
          currValue: taxLiab[0],
          growthDir:
            GROWTHDIR[this.state.dataInput.Presentations[0].language].Values[0], //increases
          growth: 0,
          repay: 0,
          exposureDur: 99,
          assetTaxLiabID: assetTaxLiabID,
          assetTaxLiabProj: taxLiab,
        });
        console.log(data2);
        this.setState({ dataInput: data2 }, () =>
          this.waitForSetStateCallback()
        );
      }
    }
  };

  handleAddLiability = async (Liab) => {
    this.setState({ loading: true });
    const { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    if (Liab === undefined) {
      Liab = {
        id: 1,
        //Type: LIABILITIES.LAST_EXPENSES.value["en"],
        liabTypeKey: LIABILITIES.LAST_EXPENSES.Key,
        ownerKey: OWNERSHIP.CLIENT.Key,
        currValue: 0,
        growthDir: GROWTHDIR["en"].Values[0], //increases
        growth: 0,
        repay: 0,
        exposureDur: 99,
        assetTaxLiabID: 0,
        assetTaxLiabProj: [],
      };
    }

    newDataInput.Liabilitys.push(Liab);

    // resync, recalcuate, then update state to re_render
    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });

    /*     this.setState({ dataInput: data2 }, () =>
      this.waitForSetStateCallback(0) // no need to save to storage when default is added
    ); */
  };

  handleAddAssetTaxCredit = (type) => {
    let data2 = this.state.dataInput;
    // check if already there
    let taxCredit = 0;
    this.state.dataInput.Liabilitys.forEach((element) => {
      if (element.liabTypeKey === LIABILITIES.CHARITABLE_GIFTS.Key) {
        taxCredit += element.currValue;
      }
    });

    taxCredit *= this.state.dataInput.Presentations[0].taxRate / 100;
    //alert(taxCredit)
    let exists = false;
    data2.Assets.forEach((element) => {
      if (element.assetTypeKey === type) {
        exists = true;
        if (Math.abs(element.currValue - taxCredit) > 1) {
          element.currValue = taxCredit;
          this.handleUpdateAsset(element);
        }
      }
    });
    if (taxCredit > 0 && exists === false) {
      const asset = createDefaultAsset(this.state.dataInput.Assets.length + 1); //assetsNo + 1)
      asset.assetTypeKey = ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key;
      asset.ownerKey = ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key;
      asset.assetTaxTypeKey = ASSET_TAX.NON_TAXABLE.Key;
      asset.currValue = taxCredit;
      asset.DisposeYr = 0;

      this.handleAddAsset(asset);
      this.openCollapsible[COLLAPSIBLE_ASSETS].open = COLLAPSIBLES_OPEN;
    }
  };

  handleAddSource = async (source, updateState = true) => {
    const { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);
    console.log("GHITATSFSAH");
    // console.log(source)
    if (source !== undefined) {
      if (source.ownerID === undefined) source.ownerID = 2;
      if (source.amount === undefined) source.amount = 0;
      if (source.duration === undefined)
        source.duration =
          newDataInput.Sources.length > 0
            ? newDataInput.Sources[0].duration
            : 0;
      if (source.taxRate === undefined)
        source.taxRate = newDataInput.Clients[this.survIdx].avgTaxRate; // same as avg tax by default
      if (source.growthRate === undefined)
        source.growthRate = newDataInput.Presentations[0].inflation; // same as inflation

      //dataInput.sourcesNo++;

      const saveToStorage =
        source.sourceTypeKey === INCOMESOURCES.GOV_SURVIVORS_PENSION.Key ||
        source.sourceTypeKey === INCOMESOURCES.GOV_DEATH_BENEFIT.Key
          ? 0
          : 1;
      if (source.sourceTypeKey === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key)
        source.amount = newDataOutput.govBenefits.cppOrphan; // initial amount
      newDataInput.Sources.push({
        id: newDataInput.Sources.length + 1, //sourcesNo,
        sourceTypeKey: source.sourceTypeKey,
        amount: source.amount,
        startYear: source.startYear,
        duration: source.duration,
        ownerID: source.ownerID,
        taxRate: source.taxRate,
        growthRate: source.growthRate,
      });
      console.log("GHIT");
      if (updateState) {
        console.log("HIT");
        // resync, recalcuate, then update state to re_render
        this.setState({ loading: true });
        const newState = await this.reSync_reCalculate_reRender(
          newDataInput,
          newDataOutput
        );
        this.setState({ ...newState, loading: false });
      } else {
        return dataInput;
      }
      // console.log(data2.Sources)
      /* this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(saveToStorage)
      ); */
    }
  };

  handleAddNeed = async (nextKey, startYear, duration) => {
    this.setState({ loading: true });
    const { dataInput, dataOutput } = this.state;
    const newDataInput = _.cloneDeep(dataInput);
    const newDataOutput = _.cloneDeep(dataOutput);

    newDataInput.Needs.push({
      id: newDataInput.Needs.length + 1, //needsNo,
      needTypeKey: nextKey,
      amount: 0,
      Percent: 0,
      startYear: startYear,
      duration: duration,
    });

    // resync, recalcuate, then update state to re_render
    const newState = await this.reSync_reCalculate_reRender(
      newDataInput,
      newDataOutput
    );
    this.setState({ ...newState, loading: false });

    //    this.setState({ dataInput: data2 }, () => this.waitForSetStateCallback());
  };

  // handle removinging component rows
  updateStateAfterRemove = (data) => {
    this.setState({ data }, () => this.waitForSetStateCallback(1)); //, 1, 1));
  };

  handleRemoveClient = async (id) => {
    if (this.OKToRemove) {
      this.setState({ loading: true });
      const { dataInput, dataOutput } = this.state;
      const newDataInput = _.cloneDeep(dataInput);
      const newDataOutput = _.cloneDeep(dataOutput);
      this.OKToRemove = false;

      newDataInput.Clients.splice(id - 1, 1);
      let i;
      for (i = 1; i <= newDataInput.Clients.length; ++i) {
        newDataInput.Clients[i - 1].id = i;
      }
      //data2.clientsNo = data2.Clients.length;

      /* const surv1=MEMBER[this.state.dataInput.Presentations[0].language].Values[1];
			const surv2=MEMBER[this.state.dataInput.Presentations[0].language].Values[3];
			let survCl=data2.Clients.filter((item)=> { return item.member === surv1;})
			if (survCl.length>0)
				this.survIdx=survCl.id;
			else{
				survCl=data2.Clients.filter((item)=> { return item.member === surv2;})
				if (survCl.length>0)
					this.survIdx=survCl.id;
				else
					this.survIdx=-1;
			}	

 */
      // resync, recalcuate, then update state to re_render
      const newState = await this.reSync_reCalculate_reRender(
        newDataInput,
        newDataOutput
      );
      this.setState({ ...newState, loading: false });

      /*   this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(1)//, 1, 1)
      ); */
      //this.syncPanelsValues2(1);
      await this.govBenefits();
    }
  };

  handleRemoveAsset = async (id) => {
    if (this.OKToRemove) {
      this.OKToRemove = false;

      this.setState({ loading: true });
      const { dataInput, dataOutput } = this.state;
      const newDataInput = _.cloneDeep(dataInput);
      const newDataOutput = _.cloneDeep(dataOutput);
      newDataInput.splice(id - 1, 1);
      let i;
      for (i = 1; i <= newDataInput.Assets.length; ++i) {
        newDataInput.Assets[i - 1].id = i;
      }
      // data2.assetsNo = data2.Assets.length;

      // resync, recalcuate, then update state to re_render
      const newState = await this.reSync_reCalculate_reRender(
        newDataInput,
        newDataOutput
      );
      this.setState({ ...newState, loading: false });
      /* this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(1)//, 1, 1)
      ); */
    }
  };

  handleRemoveLiability = async (id) => {
    if (this.OKToRemove) {
      this.OKToRemove = false;

      // console.log(id, this.state.dataInput)

      this.setState({ loading: true });
      const { dataInput, dataOutput } = this.state;
      const newDataInput = _.cloneDeep(dataInput);
      const newDataOutput = _.cloneDeep(dataOutput);
      newDataInput.Liabilitys.splice(id - 1, 1);
      let i;
      for (i = 1; i <= newDataInput.Liabilitys.length; ++i) {
        newDataInput.Liabilitys[i - 1].id = i;
      }
      //data2.liabilitysNo = data2.Liabilitys.length;

      // resync, recalcuate, then update state to re_render
      const newState = await this.reSync_reCalculate_reRender(
        newDataInput,
        newDataOutput
      );
      this.setState({ ...newState, loading: false });

      /* this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(1)//, 1, 1)
      ); */
    }
  };

  handleRemoveSource = async (id) => {
    if (this.OKToRemove) {
      this.OKToRemove = false;
      // console.log(id, this.state.dataInput)

      this.setState({ loading: true });
      const { dataInput, dataOutput } = this.state;
      const newDataInput = _.cloneDeep(dataInput);
      const newDataOutput = _.cloneDeep(dataOutput);
      let i;

      //this.failedRemove=false
      for (i = 0; i < newDataInput.Sources.length; ++i) {
        if (
          newDataInput.Sources[i].id === id &&
          (newDataInput.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_SURVIVORS_PENSION.Key ||
            newDataInput.Sources[i].sourceTypeKey ===
              INCOMESOURCES.GOV_DEATH_BENEFIT.Key)
        )
          this.failedRemove = true;
      }

      if (this.failedRemove === false) {
        newDataInput.Sources.splice(id - 1, 1);
        for (i = 1; i <= newDataInput.Sources.length; ++i) {
          newDataInput.Sources[i - 1].id = i;
        }
        //dataInput.sourcesNo = dataInput.Sources.length;
        // console.log(id, this.state.dataInput)
      }

      // resync, recalcuate, then update state to re_render
      const newState = await this.reSync_reCalculate_reRender(
        newDataInput,
        newDataOutput
      );
      this.setState({ ...newState, loading: false });

      /* this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(1)//, 1, 1)
      ); */
    }
  };

  handleRemoveNeed = async (id) => {
    if (this.OKToRemove) {
      this.OKToRemove = false;

      this.setState({ loading: true });
      const { dataInput, dataOutput } = this.state;
      const newDataInput = _.cloneDeep(dataInput);
      const newDataOutput = _.cloneDeep(dataOutput);
      newDataInput.Needs.splice(id - 1, 1);
      let i;
      for (i = 1; i <= newDataInput.Needs.length; ++i) {
        newDataInput.Needs[i - 1].id = i;
      }
      //data2.needsNo = data2.Needs.length;

      // resync, recalcuate, then update state to re_render
      const newState = await this.reSync_reCalculate_reRender(
        newDataInput,
        newDataOutput
      );
      this.setState({ ...newState, loading: false });

      /* this.setState({ dataInput: data2 }, () =>
        this.waitForSetStateCallback(1)//, 1, 1)
      ); */
    }
  };

  addRRIFSource = (asset) => {
    const existingRRIF = this.state.dataInput.Sources.find(
      (x) => x.sourceTypeKey === INCOMESOURCES.RRIF.Key
    );
    // this is done based on asset in API. this display only
    // console.log(existingRRIF, this.state.dataInput.Sources)
    if (existingRRIF === undefined) {
      const sourceRRIF = {
        sourceTypeKey: INCOMESOURCES.RRIF.Key,
        amount: 0,
        startYear: asset.RRIFStartAge,
        duration: 99,
        ownerID: 2,
        taxRate: 0,
        growthRate: 0,
      };
      // console.log(sourceRRIF)
      this.handleAddSource(sourceRRIF);
    } else {
      // console.log(existingRRIF, this.state.dataInput.Sources)
      existingRRIF.startYear = asset.RRIFStartAge;
      this.handleUpdateSource(existingRRIF);
    }
  };

  addRRIFSource2 = (dataInput, asset) => {
    const existingRRIF = dataInput.Sources.find(
      (x) => x.sourceTypeKey === INCOMESOURCES.RRIF.Key
    );
    // this is done based on asset in API. this display only
    // console.log(existingRRIF, this.state.dataInput.Sources)
    if (existingRRIF === undefined) {
      const sourceRRIF = {
        sourceTypeKey: INCOMESOURCES.RRIF.Key,
        amount: 0,
        startYear: asset.RRIFStartAge,
        duration: 99,
        ownerID: 2,
        taxRate: 0,
        growthRate: 0,
      };
      // console.log(sourceRRIF)
      dataInput = this.handleAddSource(sourceRRIF, false);
    } else {
      // console.log(existingRRIF, this.state.dataInput.Sources)
      existingRRIF.startYear = asset.RRIFStartAge;
      dataInput = this.handleUpdateSource(existingRRIF, false);
    }

    return dataInput;
  };

  /* getAssetProjection = asset => {
    let data = this.handleFetchAssetProjection(asset.id);
    // console.log(data)
    return data;
  };
 */
  updateFreq = (id, selection) => {
    let data1 = this.state.dataInput;
    if (id === 1) data1.PremiumFreq = selection;
    this.setState({ dataInput: data1 }, () => this.waitForSetStateCallback());
  };

  changeLang = () => {
    //alert('cookies');
    clearListCookies();
    //alert('cookies done');

    let data2 = this.state;
    this.openParent = false;
    let oldLang = this.state.dataInput.Presentations[0].language;
    data2.lang =
      this.state.dataInput.Presentations[0].language === "en" ? "fr" : "en";
    this.langText =
      this.state.dataInput.Presentations[0].language === "en"
        ? "Français"
        : "English";

    // close all
    let i;
    for (i = 0; i < COLLAPSIBLES_COUNT; ++i) {
      this.openCollapsible[i].open = COLLAPSIBLES_CLOSED;
    }
    //
    //this.handleCollapsibleClick
    //  (this.openCollapsible[0])

    this.setState({ data2 }, () => this.updateDataLang(oldLang));
  };

  onChange3 = (event) => {
    const { value } = event;
    //alert(name);
    //alert(value);
  };

  onChange = (event) => {
    const { name, value } = event.target;
    const { formCredentials } = this.state;
    formCredentials[name] = value;
    this.setState({ formCredentials });
    this.debounceSingleFieldValidation({ name, value });
  };

  debounceSingleFieldValidation = debounce(({ name, value }) => {
    const { formErrors } = this.state;
    const { isValid, errors } = singleFieldValidation({ key: name, value });
    if (!isValid) {
      this.setState({ formErrors: { ...formErrors, [name]: errors[name] } });
    } else {
      this.setState({ formErrors: { ...formErrors, [name]: null } });
    }
  }, waitTime);

  debounceSaveToStorage = debounce(
    () => {
      return this.saveToStorage();
    },
    waitTime,
    { leading: false, trailing: true }
  );

  areThereChildren = () => {
    let Children = this.state.dataInput.Clients.find(
      (x) => x.memberKey === MEMBER.CHILD.Key
    );
    if (Children !== undefined) return true;
    else return false;
  };

  manageEducation = () => {
    let Children = this.state.dataInput.Clients.find(
      (x) => x.memberKey === MEMBER.CHILD.Key
    );
    if (Children !== undefined) {
      let eduFunds = this.state.dataInput.Needs.find(
        (x) => x.needTypeKey === INCOMENEEDS.EDUCATION_FUND.Key
      );
      if (eduFunds === undefined)
        this.handleAddNeed(
          INCOMENEEDS.EDUCATION_FUND.Key,
          Math.max(0, UNIVERSITY_START_AGE - Children.Age),
          Math.min(4, Math.max(0, UNIVERSITY_END_AGE - Children.Age))
        );
    }
  };

  manageOrphan = () => {
    const childMember = MEMBER.CHILD.Key;
    //const orphanBen = INCOMESOURCES.GOV_ORPHANS_BENEFIT.value[this.state.dataInput.Presentations[0].language];
    const orphanBen = INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key;
    let Children = this.state.dataInput.Clients.filter(function (item) {
      return item.memberKey === childMember;
    });
    let orphSources = this.state.dataInput.Sources.filter(function (item) {
      return item.sourceTypeKey === orphanBen;
    });

    let maxDur =
      this.state.dataInput.Presentations[0].provinceKey === "QC"
        ? MAX_ORPHAN_DUR_QC
        : MAX_ORPHAN_DUR_NON_QC;
    let orphAge =
      this.state.dataInput.Presentations[0].provinceKey === "QC"
        ? ORPHAN_AGE_QC
        : ORPHAN_AGE_NON_QC;

    if (Children.length > 0) {
      Children.forEach((element) => {
        if (
          element.Age <= orphAge &&
          orphSources.filter((item) => {
            return item.ownerID === element.id;
          }).length === 0
        ) {
          const source = {
            id: this.state.dataInput.Sources.length + 1, //sourcesNo + 1,
            sourceTypeKey: orphanBen,
            amount: this.state.dataOutput.govBenefits.cppOrphan,
            startYear: 0,
            duration: maxDur - element.Age,
            ownerID: element.id,
          };
          // no elig jan 2019 this.handleAddSource(orphanBen,this.orphan * this.state.dataInput.Clients[QUOTE_CLIENT].Eligibility / 100,25-element.Age,element.id, 1);
          this.handleAddSource(source);
        }
      });
    }
  };

  updateDataLang = (oldLang) => {
    this.openParent = false;
    this.openForce = false;
    //let data2 = this.state;

    //let newLang = this.state.dataInput.Presentations[0].language;
    /*slet o = SEX[oldLang].Values;
    data2.dataInput.Clients.forEach(function (element) {
      element.Sex = SEX[newLang].Values[o.indexOf(element.Sex)];
    });
    o = SMOKING[oldLang].Values;
    data2.dataInput.Clients.forEach(function (element) {
      element.smokerKey = SMOKING[newLang].Values[o.indexOf(element.smokerKey)];
    }); */
    /* o = MEMBER[oldLang].Values;
    data2.dataInput.Clients.forEach(function(element) {
      element.member = MEMBER[newLang].Values[o.indexOf(element.member)];
    }); */
    /* o = ASSETS[oldLang].Values;
    data2.dataInput.Assets.forEach(function(element) {
      element.Type = ASSETS[newLang].Values[o.indexOf(element.Type)];
    });
     /* 
     o = OWNERSHIP[oldLang].Values;
    data2.dataInput.Assets.forEach(function(element) {
      element.Owner = OWNERSHIP[newLang].Values[o.indexOf(element.Owner)];
    }); */
    //o = ASSET_OWNERSHIP_ACTION[oldLang].Values;
    //data2.dataInput.Assets.forEach(function(element) {
    // element.Owner =
    //  ASSET_OWNERSHIP_ACTION[newLang].Values[o.indexOf(element.Owner)];
    //});

    /* o = ASSET_TAX[oldLang].Values;
    data2.dataInput.Assets.forEach(function(element) {
      element.avgTaxRate = ASSET_TAX[newLang].Values[o.indexOf(element.avgTaxRate)];
    }); */
    /* o = INCOMENEEDS[oldLang].Values;
    data2.dataInput.Needs.forEach(function(element) {
      element.Type = INCOMENEEDS[newLang].Values[o.indexOf(element.Type)];
    });
 */
    /* o = INCOMESOURCES[oldLang].Values;
    data2.dataInput.Sources.forEach(function(element) {
      element.Type = INCOMESOURCES[newLang].Values[o.indexOf(element.Type)];
    });
 */
    /* o = LIABILITIES[oldLang].Values;
    data2.dataInput.Liabilitys.forEach(function(element) {
      element.Type = LIABILITIES[newLang].Values[o.indexOf(element.Type)];
    }); */
    /*    o = OWNERSHIP[oldLang].Values;
       data2.dataInput.Liabilitys.forEach(function (element) {
         element.Owner = OWNERSHIP[newLang].Values[o.indexOf(element.Owner)];
       });
   
       /* o = ASSET_OWNERSHIP_ACTION[oldLang].Values;
       data2.dataInput.Liabilitys.forEach(function(element) {
         element.Owner = ASSET_OWNERSHIP_ACTION[newLang].Values[o.indexOf(element.Owner)];
       }); */
    /* o = PROVINCE[oldLang].Values;
    data2.dataInput.Presentations.forEach(function(element) {
      element.Province = PROVINCE[newLang].Values[o.indexOf(element.Province)];
    });
 */
    //  this.setState({ data2 }, () => this.waitForSetStateCallback());
    // this.openParent = true;
  };

  syncRowsIDs = (data2) => {
    let refresh = false;
    let i;
    for (i = 1; i <= data2.length; ++i) {
      if (data2[i - 1].id !== i) {
        data2[i - 1].id = i;
        refresh = true;
      }
    }
    return refresh;
  };

  waitForSetStateCallback = async (saveToStorage, debounce) => {
    //  if (syncPanels === undefined) syncPanels = 0;
    if (saveToStorage === undefined) saveToStorage = 1;
    if (debounce === undefined) debounce = false;
    //if (okRemove === undefined) okRemove = 0;
    //	if(okRemove===1)
    //syncPanels = 0;
    this.OKToRemove = true;

    /* if (syncPanels === 1) {
      let surv = this.state.dataInput.Clients.find(
        x => x.memberKey === MEMBER.SPOUSE.Key
      );
      if (surv === undefined)
        surv = this.state.dataInput.Clients.find(
          x => x.memberKey === MEMBER.DEPENDENT_ADULT.Key
        );
      if (surv === undefined)
        surv = this.state.dataInput.Clients.find(
          x => x.memberKey === MEMBER.CLIENT.Key
        );
      if (surv !== undefined) this.survIdx = surv.id - 1;
      else this.survIdx = -1;
    } */
    if (appletMode === "EP") {
      //this.openCollapsible[COLLAPSIBLE_RESULTS].open=false
    }
    if (saveToStorage !== 0) this.debounceSaveToStorage();
    this.openParent = true;
    // if (syncPanels !== 0) this.syncPanelsValues(0);
    //if (this.resultIsOpen || reFetch === 1 ) {
    // ALWAYS REFETCH
    {
      //await this.debounceHandleFetchInsuranceNeeds();
      console.log("refetch");
      // custom components InputField and DropDown d'ont need rebounce Notes, des for and des by do

      // if(this.visibleOutputSection>0)
      {
        if (debounce) await this.debounceHandleUpdataData();
        else await this.handleUpdataData();
      }
      // await this.handleFetchInsuranceNeeds();
      // await this.updateOutputData()
    }
  };

  getAfterTaxTotalIncome = () => {
    return (
      this.state.dataInput.Clients[QUOTE_CLIENT].Income *
        (1 - this.state.dataInput.Clients[QUOTE_CLIENT].avgTaxRate / 100) +
      this.state.dataInput.Clients[this.survIdx].Income *
        (1 - this.state.dataInput.Clients[this.survIdx].avgTaxRate / 100)
    ); //* Math.pow(1+this.state.dataInput.Presentations[0].inflation / 100,data2.Needs[i].startYear)
  };

  setSurivorIndex = () => {
    const spKey = appletMode === "INA" ? MEMBER.SPOUSE.Key : MEMBER.CLIENT.Key;
    let Survivor = this.state.dataInput.Clients.find(
      (x) => x.memberKey === spKey
    );

    if (Survivor === undefined && appletMode === "INA") {
      if (this.state.dataInput.Clients.length === 1)
        Survivor = this.state.dataInput.Clients.find(
          (x) => x.memberKey === MEMBER.CLIENT.Key
        );
      else {
        Survivor = this.state.dataInput.Clients.find(
          (x) => x.memberKey === MEMBER.DEPENDENT_ADULT.Key
        );
        if (Survivor === undefined)
          Survivor = this.state.dataInput.Clients.find(
            (x) => x.memberKey === MEMBER.CHILD.Key
          );
      }
    }

    console.log(Survivor);
    return Survivor.id - 1; // id is 1-based
  };

  syncPanelsValues = (syncAll) => {
    // EP dosent have needs and sources to sync

    this.survIdx = this.setSurivorIndex();
    //alert(this.survIdx)
    if (appletMode === "INA") {
      if (this.survIdx !== -1) {
        let i;
        let data2 = this.state.dataInput;
        let refresh = false;
        for (i = 0; i < data2.Needs.length; i++) {
          const needPercent = parseInt(
            (data2.Needs[i].Percent / 100) * this.getAfterTaxTotalIncome()
          );

          const dur =
            this.state.dataInput.Clients[this.survIdx].retirementAge -
            this.state.dataInput.Clients[this.survIdx].Age;
          //const dur = 100 - this.state.dataInput.Clients[this.survIdx].Age;
          if (data2.Needs[i].needTypeKey === INCOMENEEDS.PERCET_OF_INCOME.Key) {
            if (
              needPercent !== data2.Needs[i].amount &&
              data2.Needs[i].Percent >= 0
            ) {
              data2.Needs[i].amount = needPercent;
              refresh = true;
            }
            if (
              syncAll === 1 &&
              dur > data2.Needs[i].duration &&
              data2.Needs[i].duration !== 100 &&
              dur > 0
            ) {
              data2.Needs[i].duration = dur;
              refresh = true;
            }
            if (
              syncAll === 1 &&
              data2.Needs[i].duration === 100 &&
              dur > 0 &&
              data2.Needs[i].startYear < dur
            ) {
              data2.Needs[i].startYear = dur;
              refresh = true;
            }
          }
          if (data2.Needs[i].needTypeKey === INCOMENEEDS.EDUCATION_FUND.Key) {
            let children = this.state.dataInput.Clients.find(
              (x) => x.memberKey === MEMBER.CHILD.Key
            );
            let indices = this.state.dataInput.Clients.map((e) =>
              e.memberKey === MEMBER.CHILD.Key ? e.id : ""
            ).filter(String);
            let idxCh = data2.Needs.map((e) =>
              e.needTypeKey === INCOMENEEDS.EDUCATION_FUND.Key ? e.id : ""
            ).filter(String);

            if (children !== undefined) {
              if (
                data2.Needs[i].startYear !==
                  Math.max(0, UNIVERSITY_START_AGE - children.Age) &&
                children.length > 0
              ) {
                data2.Needs[i].startYear = Math.max(
                  0,
                  UNIVERSITY_START_AGE - children.Age
                );
                data2.Needs[i].duration = Math.max(
                  0,
                  Math.min(4, UNIVERSITY_END_AGE - children.Age)
                );
                refresh = true;
              }
            }
          }
        }
        if (refresh === true)
          this.setState({ dataInput: data2 }, () =>
            this.waitForSetStateCallback(0)
          );

        let data3 = this.state.dataInput;
        refresh = false;
        for (i = 0; i < data3.Sources.length; i++) {
          // all at income tax except divdend
          if (
            data3.Sources[i].sourceTypeKey !== INCOMESOURCES.DIVIDEND_INCOME.Key
          )
            data3.Sources[i].taxRate = this.state.dataInput.Clients[
              this.survIdx
            ].avgTaxRate; // spouse

          const dur =
            this.state.dataInput.Clients[this.survIdx].retirementAge -
            this.state.dataInput.Clients[this.survIdx].Age;
          if (
            syncAll === 1 &&
            data3.Sources[i].sourceTypeKey ===
              INCOMESOURCES.SURVIVORS_INCOME.Key &&
            data3.Sources[i].startYear === 0 &&
            dur !== data3.Sources[i].duration &&
            dur > 0
          ) {
            data3.Sources[i].duration = dur;
            refresh = true;
          }

          if (
            data3.Sources[i].sourceTypeKey ===
              INCOMESOURCES.GOV_SURVIVORS_PENSION.Key &&
            data3.Sources[i].amount !==
              parseInt(this.state.dataOutput.govBenefits.cppSurvivor) //*
            //this.state.dataInput.Clients[QUOTE_CLIENT].Eligibility) /
            //100
          ) {
            if (isNaN(this.state.dataOutput.govBenefits.cppSurvivor))
              data3.Sources[i].amount = 0;
            else
              data3.Sources[i].amount = parseInt(
                this.state.dataOutput.govBenefits.cppSurvivor
              );
            if (refresh === false)
              refresh = !isNaN(this.state.dataOutput.govBenefits.cppSurvivor);
          }
          if (
            data3.Sources[i].sourceTypeKey ===
              INCOMESOURCES.GOV_DEATH_BENEFIT.Key &&
            data3.Sources[i].amount !==
              parseInt(this.state.dataOutput.govBenefits.cppDB)
          ) {
            if (isNaN(this.state.dataOutput.govBenefits.cppDB))
              data3.Sources[i].amount = 0;
            else
              data3.Sources[i].amount = parseInt(
                this.state.dataOutput.govBenefits.cppDB
              );

            if (refresh === false)
              refresh = !isNaN(this.state.dataOutput.govBenefits.cppDB);
          }
          // no need to adjust orphans
          /* if (
            data3.Sources[i].sourceTypeKey === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key &&
            data3.Sources[i].amount !== parseInt(this.orphan)
          ) {
            this.warningMsg=
            // jan 2019} * this.state.dataInput.Clients[QUOTE_CLIENT].Eligibility / 100) {
            if (isNaN(this.orphan)) data3.Sources[i].amount = 0;
            else data3.Sources[i].amount = parseInt(this.orphan); // jan 2019 * this.state.dataInput.Clients[QUOTE_CLIENT].Eligibility / 100;
  
            if (refresh === false) refresh = !isNaN(this.orphan);
          } */

          if (
            data3.Sources[i].sourceTypeKey ===
              INCOMESOURCES.SURVIVORS_INCOME.Key &&
            data3.Sources[i].amount !==
              parseInt(this.state.dataInput.Clients[this.survIdx].Income)
          ) {
            data3.Sources[i].amount = parseInt(
              this.state.dataInput.Clients[this.survIdx].Income
            );
            refresh = true;
          }
          // manage orphans durs
          if (
            data3.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key
          ) {
            const childMember = MEMBER.CHILD.Key;
            const sourceID = data3.Sources[i].ownerID;
            let Children = this.state.dataInput.Clients.filter(function (item) {
              return item.memberKey === childMember;
            });
            if (Children.length > 0) {
              const child = Children.filter((item) => {
                return item.id === sourceID;
              });
              let maxDur =
                this.state.dataInput.Presentations[0].provinceKey === "QC"
                  ? MAX_ORPHAN_DUR_QC
                  : MAX_ORPHAN_DUR_NON_QC;
              let orphAge =
                this.state.dataInput.Presentations[0].provinceKey === "QC"
                  ? ORPHAN_AGE_QC
                  : ORPHAN_AGE_NON_QC;

              if (child.length > 0 && child[0].Age <= orphAge) {
                if (data3.Sources[i].duration !== maxDur - child[0].Age) {
                  data3.Sources[i].duration = maxDur - child[0].Age;
                  refresh = true;
                }
              } // delete source if no child
              else {
                const sourceid = data3.Sources[i].id;

                this.OKToRemove = true;
                this.handleRemoveSource(sourceid);
                refresh = true;
              }
            } else {
              const sourceid = data3.Sources[i].id;

              this.OKToRemove = true;
              this.handleRemoveSource(sourceid);
              refresh = true;
            }
          }
        }
        if (refresh === true)
          this.setState({ dataInput: data3 }, () =>
            this.waitForSetStateCallback(0)
          );
      } else {
        let i;
        let data2 = this.state.dataInput;
        for (i = 0; i < data2.Needs.length; i++) {
          if (data2.Needs[i].needTypeKey === INCOMENEEDS.PERCET_OF_INCOME.Key)
            data2.Needs[i].amount = 0;
        }
        this.setState({ dataInput: data2 }, () =>
          this.waitForSetStateCallback(0)
        );

        let data3 = this.state.dataInput;
        for (i = 0; i < data3.Sources.length; i++) {
          if (
            data3.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_SURVIVORS_PENSION.Key
          )
            data3.Sources[i].amount = 0;
          else if (
            data3.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_DEATH_BENEFIT.Key
          )
            data3.Sources[i].amount = 0;
          else if (
            data3.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key
          )
            data3.Sources[i].amount = 0;
          else if (
            data3.Sources[i].sourceTypeKey ===
            INCOMESOURCES.SURVIVORS_INCOME.Key
          )
            data3.Sources[i].amount = 0;
        }
        this.setState({ dataInput: data3 }, () =>
          this.waitForSetStateCallback(0)
        );
      }
    }
  };

  syncPanelsValues2 = (newStateCandidateInput) => {
    // EP dosent have needs and sources to sync

    this.survIdx = this.setSurivorIndex();
    //alert(this.survIdx)
    if (appletMode === "INA") {
      if (this.survIdx !== -1) {
        let i;
        let refresh = false;
        for (i = 0; i < newStateCandidateInput.Needs.length; i++) {
          const needPercent = parseInt(
            (newStateCandidateInput.Needs[i].Percent / 100) *
              this.getAfterTaxTotalIncome()
          );

          const dur =
            newStateCandidateInput.Clients[this.survIdx].retirementAge -
            newStateCandidateInput.Clients[this.survIdx].Age;
          //const dur = 100 - newStateCandidateInput.Clients[this.survIdx].Age;
          if (
            newStateCandidateInput.Needs[i].needTypeKey ===
            INCOMENEEDS.PERCET_OF_INCOME.Key
          ) {
            if (
              needPercent !== newStateCandidateInput.Needs[i].amount &&
              newStateCandidateInput.Needs[i].Percent >= 0
            ) {
              newStateCandidateInput.Needs[i].amount = needPercent;
              refresh = true;
            }
            if (
              // syncAll === 1 &&
              dur > newStateCandidateInput.Needs[i].duration &&
              newStateCandidateInput.Needs[i].duration !== 100 &&
              dur > 0
            ) {
              newStateCandidateInput.Needs[i].duration = dur;
              refresh = true;
            }
            if (
              newStateCandidateInput.Needs[i].duration === 100 &&
              dur > 0 &&
              newStateCandidateInput.Needs[i].startYear < dur
            ) {
              newStateCandidateInput.Needs[i].startYear = dur;
              refresh = true;
            }
          }
          if (
            newStateCandidateInput.Needs[i].needTypeKey ===
            INCOMENEEDS.EDUCATION_FUND.Key
          ) {
            let children = newStateCandidateInput.Clients.find(
              (x) => x.memberKey === MEMBER.CHILD.Key
            );
            let indices = newStateCandidateInput.Clients.map((e) =>
              e.memberKey === MEMBER.CHILD.Key ? e.id : ""
            ).filter(String);
            let idxCh = newStateCandidateInput.Needs.map((e) =>
              e.needTypeKey === INCOMENEEDS.EDUCATION_FUND.Key ? e.id : ""
            ).filter(String);

            if (children !== undefined) {
              if (
                newStateCandidateInput.Needs[i].startYear !==
                  Math.max(0, UNIVERSITY_START_AGE - children.Age) &&
                children.length > 0
              ) {
                newStateCandidateInput.Needs[i].startYear = Math.max(
                  0,
                  UNIVERSITY_START_AGE - children.Age
                );
                newStateCandidateInput.Needs[i].duration = Math.max(
                  0,
                  Math.min(4, UNIVERSITY_END_AGE - children.Age)
                );
                refresh = true;
              }
            }
          }
        }
        /* if (refresh === true)
          this.setState({ dataInput: data2 }, () =>
            this.waitForSetStateCallback(0)
          );
 */
        refresh = false;
        for (i = 0; i < newStateCandidateInput.Sources.length; i++) {
          // all at income tax except divdend
          if (
            newStateCandidateInput.Sources[i].sourceTypeKey !==
            INCOMESOURCES.DIVIDEND_INCOME.Key
          )
            newStateCandidateInput.Sources[i].taxRate =
              newStateCandidateInput.Clients[this.survIdx].avgTaxRate; // spouse

          const dur =
            newStateCandidateInput.Clients[this.survIdx].retirementAge -
            newStateCandidateInput.Clients[this.survIdx].Age;
          if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
              INCOMESOURCES.SURVIVORS_INCOME.Key &&
            newStateCandidateInput.Sources[i].startYear === 0 &&
            dur !== newStateCandidateInput.Sources[i].duration &&
            dur > 0
          ) {
            newStateCandidateInput.Sources[i].duration = dur;
            refresh = true;
          }

          if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
              INCOMESOURCES.GOV_SURVIVORS_PENSION.Key &&
            newStateCandidateInput.Sources[i].amount !==
              parseInt(this.state.dataOutput.govBenefits.cppSurvivor) //*
            //newStateCandidateInput.Clients[QUOTE_CLIENT].Eligibility) /
            //100
          ) {
            if (isNaN(this.state.dataOutput.govBenefits.cppSurvivor))
              newStateCandidateInput.Sources[i].amount = 0;
            else
              newStateCandidateInput.Sources[i].amount = parseInt(
                this.state.dataOutput.govBenefits.cppSurvivor
              );
            if (refresh === false)
              refresh = !isNaN(this.state.dataOutput.govBenefits.cppSurvivor);
          }
          if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
              INCOMESOURCES.GOV_DEATH_BENEFIT.Key &&
            newStateCandidateInput.Sources[i].amount !==
              parseInt(this.state.dataOutput.govBenefits.cppDB)
          ) {
            if (isNaN(this.state.dataOutput.govBenefits.cppDB))
              newStateCandidateInput.Sources[i].amount = 0;
            else
              newStateCandidateInput.Sources[i].amount = parseInt(
                this.state.dataOutput.govBenefits.cppDB
              );

            if (refresh === false)
              refresh = !isNaN(this.state.dataOutput.govBenefits.cppDB);
          }
          // no need to adjust orphans
          /* if (
            newStateCandidateInput.Sources[i].sourceTypeKey === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key &&
            newStateCandidateInput.Sources[i].amount !== parseInt(this.orphan)
          ) {
            this.warningMsg=
            // jan 2019} * newStateCandidateInput.Clients[QUOTE_CLIENT].Eligibility / 100) {
            if (isNaN(this.orphan)) newStateCandidateInput.Sources[i].amount = 0;
            else newStateCandidateInput.Sources[i].amount = parseInt(this.orphan); // jan 2019 * newStateCandidateInput.Clients[QUOTE_CLIENT].Eligibility / 100;
  
            if (refresh === false) refresh = !isNaN(this.orphan);
          } */
          if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
              INCOMESOURCES.SURVIVORS_INCOME.Key &&
            newStateCandidateInput.Sources[i].amount !==
              parseInt(newStateCandidateInput.Clients[this.survIdx].Income)
          ) {
            newStateCandidateInput.Sources[i].amount = parseInt(
              newStateCandidateInput.Clients[this.survIdx].Income
            );
            refresh = true;
          }
          // manage orphans durs
          if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key
          ) {
            const childMember = MEMBER.CHILD.Key;
            const sourceID = newStateCandidateInput.Sources[i].ownerID;
            let Children = newStateCandidateInput.Clients.filter(function (
              item
            ) {
              return item.memberKey === childMember;
            });
            if (Children.length > 0) {
              const child = Children.filter((item) => {
                return item.id === sourceID;
              });
              let maxDur =
                newStateCandidateInput.Presentations[0].provinceKey === "QC"
                  ? MAX_ORPHAN_DUR_QC
                  : MAX_ORPHAN_DUR_NON_QC;
              let orphAge =
                newStateCandidateInput.Presentations[0].provinceKey === "QC"
                  ? ORPHAN_AGE_QC
                  : ORPHAN_AGE_NON_QC;

              if (child.length > 0 && child[0].Age <= orphAge) {
                if (
                  newStateCandidateInput.Sources[i].duration !==
                  maxDur - child[0].Age
                ) {
                  newStateCandidateInput.Sources[i].duration =
                    maxDur - child[0].Age;
                  refresh = true;
                }
              } // delete source if no child
              else {
                const sourceid = newStateCandidateInput.Sources[i].id;

                this.OKToRemove = true;
                this.handleRemoveSource(sourceid);
                refresh = true;
              }
            } else {
              const sourceid = newStateCandidateInput.Sources[i].id;

              this.OKToRemove = true;
              this.handleRemoveSource(sourceid);
              refresh = true;
            }
          }
        }
        /* if (refresh === true)
          this.setState({ dataInput: newStateCandidateInput }, () =>
            this.waitForSetStateCallback(0)
          ); */
      } else {
        let i;
        for (i = 0; i < newStateCandidateInput.Needs.length; i++) {
          if (
            newStateCandidateInput.Needs[i].needTypeKey ===
            INCOMENEEDS.PERCET_OF_INCOME.Key
          )
            newStateCandidateInput.Needs[i].amount = 0;
        }
        /* this.setState({ dataInput: data2 }, () =>
          this.waitForSetStateCallback(0)
        );
 */
        let newStateCandidateInput = newStateCandidateInput;
        for (i = 0; i < newStateCandidateInput.Sources.length; i++) {
          if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_SURVIVORS_PENSION.Key
          )
            newStateCandidateInput.Sources[i].amount = 0;
          else if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_DEATH_BENEFIT.Key
          )
            newStateCandidateInput.Sources[i].amount = 0;
          else if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
            INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key
          )
            newStateCandidateInput.Sources[i].amount = 0;
          else if (
            newStateCandidateInput.Sources[i].sourceTypeKey ===
            INCOMESOURCES.SURVIVORS_INCOME.Key
          )
            newStateCandidateInput.Sources[i].amount = 0;
        }
        /* this.setState({ dataInput: newStateCandidateInput }, () =>
          this.waitForSetStateCallback(0) */
        // );
      }
    }
    return newStateCandidateInput;
  };

  setRates = () => {
    let dataE = {
      investmentRate: this.state.dataInput.Presentations[0].invRate / 100,
      taxRate: this.state.dataInput.Presentations[0].taxRate / 100,
      dividendTaxRate: 0.33,
      capitalGainsInclusion: 0.5,
      inflationRate: this.state.dataInput.Presentations[0].inflation / 100,
    };

    return dataE;
  };

  loadStorage = () => {
    //	this.openParent = false;
    const objJSONData = JSON.parse(localStorage.getItem("INAData"));
    console.log(objJSONData);
    if (objJSONData !== null && objJSONData !== undefined)
      this.updateStateInput(objJSONData, () => this.waitForSetStateCallback());
  };

  updateState = (objJSONData) => {
    let data2 = this.state.dataInput;
    /*  let dataInput2 = this.state.dataInput;
     let dataInput2 = this.state.dataInput;
     let dataInput2 = this.state.dataInput;
     let dataInput2 = this.state.dataInput;
     let Presentations2 = this.state.dataInput; */

    data2 = objJSONData.dataInput;
    /* dataInput2 = objJSONData.dataInput;
    dataInput2 = objJSONData.dataInput;
    dataInput2 = objJSONData.dataInput;
    dataInput2 = objJSONData.dataInput;
    //Settings2 = objJSONData.Settings;
    Presentations2 = objJSONData.dataInput; */

    this.setState(
      {
        dataInput: data2,
        /*  dataInput: dataInput2,
         dataInput: dataInput2,
         dataInput: dataInput2,
         dataInput: dataInput2,
         dataInput: Presentations2,
         lang: objJSONData.lang */
      },
      () => this.waitForSetStateCallback(0)
    );
  };

  saveToStorage = () => {
    // in case we need to clear all
    // localStorage.clear();
    localStorage.setItem("INAData", JSON.stringify(this.state.dataInput));

    // const objJSONData = JSON.parse(localStorage.getItem("INAData"));
    // console.log(JSON.stringify(this.state))
    console.log("objJSONData");
    // no recovery anymore
    this.showRecover = 0;
    hideRecover();
  };

  loadFromFile = (e) => {
    const fileTarget = e.target.files[0];
    if (!fileTarget) {
      return;
    }
    // close all
    let i;
    for (i = 0; i < COLLAPSIBLES_COUNT; ++i) {
      this.openCollapsible[i].open = COLLAPSIBLES_CLOSED;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      let contentsFile = e.target.result;
      var objJSONData;
      // console.log(contentsFile, contentsFile.search("dataInput"));
      // is this a non-encrypted file
      const encrptedSave =
        contentsFile.search("dataInput") > 0 ||
        versionDetails().saveEncrypt === false
          ? false
          : true;

      if (encrptedSave === true) {
        //isVersion2019() === false) {
        this.handleFetchQueryStringGet(contentsFile);
      } else {
        // name changes
        contentsFile = contentsFile.split("Amount").join("amount");
        contentsFile = contentsFile.split("StartYr").join("startYear");
        contentsFile = contentsFile.split("Duration").join("duration");
        contentsFile = contentsFile
          .split("" + "Tax" + "")
          .join("" + "avgTaxRate" + "");
        contentsFile = contentsFile.split("retireAge").join("retirementAge");
        // console.log(contentsFile);
        objJSONData = JSON.parse(contentsFile);

        // old files
        objJSONData.dataInput.Clients.forEach(function (element) {
          if (element.sexKey == undefined) {
            element.sexKey = getListItemKeyFromName(SEX, element.Sex);
            delete element.Sex;
          }
        });
        // old files
        objJSONData.dataInput.Clients.forEach(function (element) {
          if (element.smokerKey == undefined) {
            element.smokerKey = getListItemKeyFromName(SMOKING, element.Smoker);
            delete element.Smoker;
          }
        });
        // old files
        objJSONData.dataInput.Clients.forEach(function (element) {
          if (element.memberKey == undefined) {
            element.memberKey = getListItemKeyFromName(MEMBER, element.member);
            delete element.member;
          }
        });

        // old files
        objJSONData.dataInput.Assets.forEach(function (element) {
          if (element.assetTypeKey == undefined) {
            element.assetTypeKey = getListItemKeyFromName(ASSETS, element.Type);
            delete element.Type;
          }
        });
        // old files
        objJSONData.dataInput.Assets.forEach(function (element) {
          if (element.assetTaxTypeKey == undefined) {
            element.assetTaxTypeKey = getListItemKeyFromName(
              ASSET_TAX,
              element.Tax
            );
            delete element.Tax;
          }
        });

        // old files
        objJSONData.dataInput.Assets.forEach(function (element) {
          if (element.ownerKey == undefined) {
            element.ownerKey = ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key;
          }
        });

        // console.log(contentsFile, objJSONData)
        // old files note change in spelling
        objJSONData.dataInput.Liabilitys.forEach(function (element) {
          if (element.liabTypeKey == undefined) {
            element.liabTypeKey = getListItemKeyFromName(
              LIABILITIES,
              element.Type
            );
            delete element.Type;
          }
        });
        // console.log(contentsFile, objJSONData)
        // old files
        objJSONData.dataInput.Sources.forEach(function (element) {
          if (element.sourceTypeKey == undefined) {
            element.sourceTypeKey = getListItemKeyFromName(
              INCOMESOURCES,
              element.Type
            );
            delete element.Type;
          }
        });
        // console.log(contentsFile, objJSONData)
        // old files
        objJSONData.dataInput.Needs.forEach(function (element) {
          if (element.needTypeKey == undefined) {
            element.needTypeKey = getListItemKeyFromName(
              INCOMENEEDS,
              element.Type
            );
            delete element.Type;
          }
        });
        // console.log(contentsFile, objJSONData)

        // old files
        objJSONData.dataInput.Presentations.forEach(function (element) {
          if (element.provinceKey == undefined) {
            element.provinceKey = getListItemKeyFromName(
              PROVINCE,
              element.Province
            );
            delete element.Province;
          }
        });

        this.updateState(objJSONData);
        // console.log(contentsFile, objJSONData)
      }
    };
    reader.readAsText(fileTarget);
  };

  respondToSaveRequest = (fileName) => {
    this.setState({ showMsg: false });
    let blob;
    if (versionDetails().saveEncrypt === false)
      // regular text file
      blob = new Blob([JSON.stringify(this.state.dataInput)], {
        type: "text/plain;charset=utf-8",
      });
    else blob = new Blob([this.dataQS], { type: "text/plain;charset=utf-8" });

    // iphone
    var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    if (fileName !== "") {
      if (iOS === false) {
        // works on IE and Edge to save file, would also work on Chrome, Firedox for desktop
        saveAs(
          blob,
          fileName === undefined ? "INASavedData.json" : fileName + ".json"
        );
        //saveAs(blob, fileName===undefined?"INASavedData.json":prompt('Please enter file name:'))
      } else {
        // Chrome, Firefox, and Chrome and Safari on iOS
        //var dataUrl = JSON.stringify(this.state);
        //var open = window.open(dataUrl);
        //if (open === null || typeof (open) === 'undefined') {
        blob = new Blob([JSON.stringify(this.state.dataInput)]);
        saveAs(
          blob,
          fileName === undefined
            ? "INASavedData.json"
            : "SignInINASavedData.json"
        );
        //      var blobUrl = URL.createObjectURL(blob)
        //      window.location.href = blobUrl;
        //	 }
      }
    }
  };

  saveToFile_OLD = () => {
    const blob = new Blob([JSON.stringify(this.state.dataInput)], {
      type: "text/plain;charset=utf-8",
    });
    saveAs(blob, "INASavedData.json");
  };

  saveToFile = (fileName) => {
    if (versionDetails().saveEncrypt === false)
      // regular text file
      this.respondToSaveRequest("fileINA");
    else {
      this.handleFetchQueryString(MODE_SAVE);
    }
  };

  loadData = () => {
    /*   try {
      const res = await fetch(appSiteAPI+'/api/MCC_Carriers?id=1');
      const blocks = await res.json();
      console.log(blocks)
    } catch (e) {
      console.log(e);
	  this.setState({failedAPI: true}, () => this.waitForSetStateCallback());
    } */

    /*     fetch(appSiteAPI + "/api/MCC_Carriers?id=1")
      .then(response => response.json())
      .then(data => console.log("timer API check"))
      .catch(error => {
        console.log("error, timer API failed", error);
        let fails = parseInt(localStorage.getItem("INAAPIFails"));
        //console.log(fails);

        if (!fails) fails = 0;
        //console.log(fails);
        fails++;
        localStorage.setItem("INAAPIFails", parseInt(fails));
        if (fails > 1) this.setState({ failedAPI: true });
        //clearInterval(this.intervalID);
        //console.log('failedAPI', this.state.failedAPI);
        //console.log(appSiteAPI+'/api/MCC_Carriers?id=1');
      }); */
    let fails = fetchTimerAPICheck();
    if (fails > 1) this.setState({ failedAPI: true });
  };

  respondToPopUp = () => {
    this.saveToStorage();

    let urlReload = PARENT_SITE_PROD + "?ina=" + shortid.generate();
    const url2 = window.location.href;

    if (url2.indexOf(SITE_TEST) !== -1)
      urlReload = PARENT_SITE_TEST + "?ina=" + shortid.generate();

    const urlLogoff = "https://adfs.ppi.ca/adfs/ls/?wa=wsignout1.0";
    //	if(fails>1){
    //localStorage.setItem('INAAPIFails', parseInt(0));
    window.parent.location.href = urlLogoff;
    //	}
    //	else
    {
      window.parent.location.href = urlReload;
    }
  };

  EmailINA = () => {
    // test

    this.handleFetchQueryString(MODE_EMAIL);
    //window.location.href ='mailto: msamiei@ppi.ca ?subject= Needs Analysis Quote &body=' + this.dataQS;
  };
  /* 	callAPI2 = (e) => {
		
		if (!this.resultIsOpen){
			this.handleFetchInsuranceNeeds();
		}
		if(this.accessedAPI){
			this.resultIsOpen = !e;
		}
			
	}
	callAPI = (e) => {
		this.callAPI2(e);
	}
 */
  callCalculateResultsAPI = (e) => {
    //  console.log(e)
    if (!this.resultIsOpen)
      //this.handleUpdataData();
      this.resultIsOpen = !e;
  };

  adjustVisibleOutputSection = (unit) => {
    this.visibleOutputSection = this.visibleOutputSection + unit;
    console.log(this.visibleOutputSection);
  };

  handleCollapsibleClick = async (collapsible) => {
    if (collapsible.id === COLLAPSIBLE_RESULTS) {
      this.adjustVisibleOutputSection(
        this.openCollapsible[COLLAPSIBLE_RESULTS].open ? -1 : 1
      );

      this.callCalculateResultsAPI(collapsible.open);
    }
    if (collapsible.id === COLLAPSIBLE_SOURCES) {
      // recheck gov
      await this.govBenefits();
    }

    this.openCollapsible[collapsible.id].open = !collapsible.open;
    // console.log(this.openCollapsible)
  };

  /* handleClick = e => {
    alert("e")
    this.dlgLogin.click();
  }; */
  /* isMobileDevice=()=> {
		return  (typeof window.orientation !== "undefined") || (navigator.userAgent.indexOf('IEMobile') !== -1);
	} */

  setOutput = (e) => {
    // Internet Explorer 6-11
    let isIE = /*@cc_on!@*/ false || !!document.documentMode;

    if (isIE)
      alert(MESSAGES[this.state.dataInput.Presentations[0].language].ie);
    else this.graphs = e === 2 ? true : false;
    this.setState({ loading: false });
  };

  /* setInsduration = e => {
    this.toRetirement = e === 1 ? true : false;
    this.setState({ loading: false }, () =>
      this.waitForSetStateCallback(0, 1)
    );
  }; */

  selectMultiButtonPeriod = (e) => {
    // selection is 1-based
    let pres = this.state.dataInput.Presentations;

    if (e === DISPLAY_RETIREMENT + 1) {
      pres[0].periodOption = DISPLAY_RETIREMENT;
    } else if (e === DISPLAY_LIFEEXP + 1) {
      pres[0].periodOption = DISPLAY_LIFEEXP;
    } else if (e === DISPLAY_ENDAGE + 1) {
      pres[0].periodOption = DISPLAY_ENDAGE;
    } else if (e === DISPLAY_LIFEEXP_PLUS_3 + 1) {
      pres[0].periodOption = DISPLAY_LIFEEXP_PLUS_3;
    }
    this.setState({ Presentations: pres }, () => this.updateOutputData());
  };

  selectMultiButton = (e) => {
    let pres = this.state.dataInput.Presentations;

    if (e === DISPLAY_SPREADSHEET) {
      pres[0].resultsOption = DISPLAY_SPREADSHEET;
    } else if (e === DISPLAY_GRAPHS) {
      pres[0].resultsOption = DISPLAY_GRAPHS;
    } else if (e === DISPLAY_ANALYSIS) {
      pres[0].resultsOption = DISPLAY_ANALYSIS;
      pres[0].periodOption = DISPLAY_ENDAGE;
      // try this now
      pres[0].resultsOption = DISPLAY_LIFEEXP_PLUS_3;
      pres[0].periodOption = DISPLAY_LIFEEXP_PLUS_3;
    } else {
      pres[0].resultsOption = DISPLAY_PRESENTATION;
      //periodOption = DISPLAY_RETIREMENT;
    }
    this.setState({ Presentations: pres });
  };

  selectMultiButtonINAorTax = (e) => {
    if (e === DISPLAY_TAXLIAB) {
      this.INAOption = DISPLAY_TAXLIAB;
      // }else if (e === DISPLAY_TAXLIAB_JLTD) {
      //  this.INAOption = DISPLAY_TAXLIAB_JLTD;
    } else if (e === DISPLAY_INCOME) {
      this.INAOption = DISPLAY_INCOME;
    }
    let l = this.state.loading;
    l = !l;
    this.setState({ loading: l });
  };

  render() {
    /* 
    if(this.state.loading=== true)
      return ""
    else */

    let i = 1;
    let j = 1;
    let k = 1;
    let l = 1;
    let n = 1;
    let v = 1;

    console.log(this.state);
    //alert('cookies');
    //clearListCookies();
    //alert('cookies done');
    const showInput = this.state.showMsg;

    const pres =
      this.state.dataInput.Presentations[0].language === "en"
        ? "Presentation"
        : "Présentation";
    const gr =
      this.state.dataInput.Presentations[0].language === "en"
        ? "Graphs"
        : "graphique";
    const ret =
      this.state.dataInput.Presentations[0].language === "en"
        ? "Retirement"
        : "Retraite";
    const le =
      this.state.dataInput.Presentations[0].language === "en"
        ? "Life Expectancy"
        : "Espérance de vie";

    const dataInput = this.state.dataInput;

    let insNeed = 0;
    let insNeedRet = 0;
    let insNeedLE = 0;
    let insNeedLE3 = 0;
    let insNeedEAge = 0;
    /*  if (this.dataInsuranceNeeds.length > 0) {
      insNeed = this.toRetirement
        ? this.dataInsuranceNeeds[0].Value
        : this.dataInsuranceNeeds[1].Value;
      insNeedRet = this.dataInsuranceNeeds[0].Value;
      insNeedLE = this.dataInsuranceNeeds[1].Value;
    }
    */
    const dataOutput = this.state.dataOutput;
    const insuranceNeeds = this.state.dataOutput.dataInsuranceNeeds;
    const periodOption = dataInput.Presentations[0].periodOption;

    if (insuranceNeeds.length > 0) {
      insNeed =
        periodOption === DISPLAY_RETIREMENT
          ? insuranceNeeds[DISPLAY_RETIREMENT].Value
          : periodOption === DISPLAY_LIFEEXP
          ? insuranceNeeds[DISPLAY_LIFEEXP].Value
          : periodOption === DISPLAY_LIFEEXP_PLUS_3
          ? getINA_LifeExp_Plus_yrs(
              insuranceNeeds[DISPLAY_LIFEEXP].Value,
              dataOutput.dataShortfall,
              dataInput.Presentations[0].invRate,
              dataOutput.lifeExpectancy.spouse,
              3
            )
          : insuranceNeeds[DISPLAY_ENDAGE].Value;
      insNeedRet = insuranceNeeds[DISPLAY_RETIREMENT].Value;
      insNeedLE = insuranceNeeds[DISPLAY_LIFEEXP].Value;
      insNeedEAge = insuranceNeeds[DISPLAY_ENDAGE].Value;
      insNeedLE3 =
        dataOutput.dataShortfall !== undefined
          ? getINA_LifeExp_Plus_yrs(
              insuranceNeeds[DISPLAY_LIFEEXP].Value,
              dataOutput.dataShortfall,
              dataInput.Presentations[0].invRate,
              dataOutput.lifeExpectancy.joint,
              3
            )
          : insNeed;
    }

    let projectEnd = 65;
    let noProjectYrs = 0;
    let survAge;

    if (this.survIdx !== -1 && this.survIdx !== undefined) {
      projectEnd =
        periodOption === DISPLAY_RETIREMENT
          ? dataInput.Clients[this.survIdx].retirementAge
          : periodOption === DISPLAY_LIFEEXP
          ? dataOutput.lifeExpectancy.spouse +
            dataInput.Clients[this.survIdx].Age
          : periodOption === DISPLAY_ANALYSIS
          ? dataOutput.lifeExpectancy.joint +
            dataInput.Clients[this.survIdx].Age +
            3
          : 100;
      noProjectYrs = projectEnd - dataInput.Clients[this.survIdx].Age;
      survAge = dataInput.Clients[this.survIdx].Age;
    } else survAge = dataInput.Clients[QUOTE_CLIENT].Age;

    let hasSurivor = false;
    /*     const spKey = appletMode === "INA" ? MEMBER.SPOUSE.Key : MEMBER.CLIENT.Key;
        let Survivor = dataInput.Clients.find(x => x.memberKey === spKey);
    
        if (Survivor !== undefined && appletMode === "INA") {
          if (dataInput.Clients.length === 1)
            Survivor = dataInput.Clients.find(x => x.memberKey === MEMBER.CLIENT.Key);
          else {
            Survivor = dataInput.Clients.find(x => x.memberKey === MEMBER.DEPENDENT_ADULT.Key);
            if (Survivor !== undefined)
              Survivor = dataInput.Clients.find(x => x.memberKey === MEMBER.CHILD.Key);
    
    
          }
    
        }
    
        if (Survivor !== undefined || appletMode === "EP") {
          hasSurivor = true;
        }
     */
    const Survivor = this.state.dataInput.Clients[this.survIdx]; //.find(x => x.memberKey === spKey);
    if (Survivor !== undefined) {
      hasSurivor = true;
    }

    if (this.survIdx !== undefined) hasSurivor = true;
    const inputOutputIsValid =
      insuranceNeeds.length > 0 &&
      dataOutput.dataNAAges !== undefined &&
      hasSurivor;

    //Survivor !== undefined

    if (this.state.failedAPI) console.log("timer API call failed re ADSF");

    let dataAges;
    let dataGov;
    let dataPCV;
    let dataNeed;
    let dataShort;
    let buttonCaption;
    let buttonCaption3;
    let buttonCaptionPeriod;
    /* let gridColumnAligns;
    let dataTitle;
    let dataColHeaders;
    let gridColumnNoofDecimals;
    let dataColumns;
    let excelDataInfoSection; */
    let tableWidth;
    let dataEstateLiability;
    let aggregateGrid;

    buttonCaption = [
      TITLES[dataInput.Presentations[0].language].presBut,
      TITLES[dataInput.Presentations[0].language].graphsBut,
      TITLES[dataInput.Presentations[0].language].spreadsheetBut,
      TITLES[dataInput.Presentations[0].language].analysisBut,
    ];
    buttonCaption3 = [
      TITLES[dataInput.Presentations[0].language].presBut,
      TITLES[dataInput.Presentations[0].language].graphsBut,
      TITLES[dataInput.Presentations[0].language].spreadsheetBut,
    ];
    buttonCaptionPeriod = [
      TITLES[dataInput.Presentations[0].language].retBut,
      TITLES[dataInput.Presentations[0].language].leBut,
      TITLES[dataInput.Presentations[0].language].age100But,
    ];
    if (dataInput.Clients[this.survIdx].memberKey !== MEMBER.SPOUSE.Key)
      buttonCaptionPeriod = [
        TITLES[dataInput.Presentations[0].language].protectButton,
      ];
    if (inputOutputIsValid) {
      // project liabs
      var totalLiabProjections = getProjectedLiabilities(
        dataInput,
        projectEnd,
        dataInput.Presentations[0].language
      );

      dataAges = dataOutput.dataNAAges.slice(0, noProjectYrs);
      dataGov = dataOutput.dataCashFlowGov.slice(0, noProjectYrs);
      dataPCV = dataOutput.dataCashFlowPersonal.slice(0, noProjectYrs);
      // if(this.INAOption!==DISPLAY_INCOME)
      dataEstateLiability = getDataFutureEstateLiability(
        //getDataFutureEstateLiability(this.dataTaxLiability.numericValues, totalLiabProjections).slice(0, noProjectYrs);
        dataOutput.dataTaxLiability,
        totalLiabProjections
      );
      dataNeed = dataOutput.dataCashFlowNeeds.slice(0, noProjectYrs);
      dataShort = dataOutput.dataShortfall.slice(0, noProjectYrs);

      let dataSurvivorSalaryIncome = dataInput.Sources.find(
        (x) => x.sourceTypeKey === INCOMESOURCES.SURVIVORS_INCOME
      );
      if (dataSurvivorSalaryIncome !== undefined) {
        dataSurvivorSalaryIncome.reduce((a, b) => a + b, 0);
      }
      dataSurvivorSalaryIncome = dataOutput.dataShortfall.slice(
        0,
        noProjectYrs
      );

      console.log(dataShort);

      // INA spreadsheet
      /* if (appletMode === "INA")
        aggregateGrid = getINAGridData(
          insNeed,
          insNeedRet,
          insNeedLE,
          dataPCV,
          Spouse,
          dataNeed,
          dataGov,
          dataShort,
          dataInput.Presentations[0].inflation,
          dataInput.Presentations[0].language,
          dataInput.Presentations[0].invRate,
          dataInput.Sources,
          this.state.govBenefits.cppDB * (1 - dataInput.Clients[QUOTE_CLIENT].avgTaxRate / 100),
        )
      else if       // EP grid
        (appletMode === "EP")
        /* aggregateGrid = getEPGridData(
          noProjectYrs,
          this.state
        )
        console.log(aggregateGrid)
      if (aggregateGrid !== undefined)
        tableWidth = Math.min(100, 10 * aggregateGrid.gridColumnsHeaders.length) + "%";
 */
      if (this.state.dataOutput.aggregateGrid !== null)
        tableWidth =
          Math.min(
            100,
            10 * this.state.dataOutput.aggregateGrid.gridColumnsHeaders.length
          ) + "%";

      // MCC quote
      // dataMCC= INAMCCQuote(this.state,insNeed);
      // console.log(dataMCC)
    }

    const altRow = "#F8F8F8";

    const graphs = (
      <OutputGraphs
        insuranceNeed={insNeed}
        projectEnd={projectEnd}
        dataCashFlowPersonal={dataPCV}
        dataInput={dataInput}
        dataNAAges={dataAges}
        dataCashFlowNeeds={dataNeed}
        dataCashFlowGov={dataGov}
        dataShortfall={dataShort}
        language={dataInput.Presentations[0].language}
        //projectTo={this.toRetirement ? 0 : 1}

        periodOption={periodOption}
        /* projectTo={
        periodOption === DISPLAY_RETIREMENT
          ? DISPLAY_RETIREMENT
          : periodOption === DISPLAY_LIFEEXP
            ? DISPLAY_LIFEEXP
            : DISPLAY_ENDAGE
      } */
      />
    );

    const graphsEP = (
      <OutputGraphsEP
        insuranceNeed={insNeedLE3}
        projectEnd={projectEnd} // try this now // always to the end
        dataEstateLiability={dataEstateLiability}
        dataInput={dataInput}
        dataNAAges={dataAges}
        lifeExp={dataOutput.lifeExpectancy.spouse}
        lifeExpJLTD={dataOutput.lifeExpectancy.joint}
        lifeExpClient={dataOutput.lifeExpectancy.client}
        INAOption={this.INAOption}
        dataShortfall={dataShort}
        dataAPISite={appSiteAPI}
        language={dataInput.Presentations[0].language}
        //projectTo={this.toRetirement ? 0 : 1}
        periodOption={DISPLAY_LIFEEXP_PLUS_3}
      />
    );

    const analysis = (
      <div
        style={{
          marginTop: "-4px",
          backgroundColor: "lightgrey",
          paddingLeft: "5px",
        }}
      >
        <AnalysisGraphs
          insuranceNeed={insNeedLE3}
          projectEnd={projectEnd} // try this now // always to the end
          dataEstateLiability={dataEstateLiability}
          dataInput={dataInput}
          dataNAAges={dataAges}
          lifeExp={dataOutput.lifeExpectancy.spouse}
          lifeExpJLTD={dataOutput.lifeExpectancy.joint}
          lifeExpClient={dataOutput.lifeExpectancy.client}
          INAOption={this.INAOption}
          dataShortfall={dataShort}
          dataAPISite={appSiteAPI}
          language={dataInput.Presentations[0].language}
          //projectTo={this.toRetirement ? 0 : 1}
          periodOption={DISPLAY_LIFEEXP_PLUS_3}
          //projectTo={this.lifeExp + 3} // always to the end
          /* periodOption === DISPLAY_RETIREMENT
          ? 0
          : periodOption === DISPLAY_LIFEEXP
          ? 1
          : 2
      } */
        />
      </div>
    );

    let infoIcon = getGenericMessage(dataInput.Presentations[0].language);
    infoIcon.infoText = getInfoIconSourcesGov(
      dataInput.Presentations[0].language
    ).infoText;
    const govPopup = this.failedRemove && (
      <div style={{ paddingLeft: "45%" }}>
        {" "}
        <Info
          infoIcon={infoIcon}
          respondToPopUp={(this.failedRemove = false)}
        />
      </div>
    );

    return (
      <div id="main" className="mainDiv">
        <Header
          title={
            this.INAOption === DISPLAY_INCOME
              ? TITLES[dataInput.Presentations[0].language].appletINA
              : TITLES[dataInput.Presentations[0].language].appletEP
          }
          saveToFile={this.saveToFile}
          loadFromFile={this.loadFromFile}
          loadStorage={this.loadStorage}
          EmailINA={this.EmailINA}
          changeLang={this.changeLang}
          language={dataInput.Presentations[0].language}
        />

        {/* <div style={{marginTop:'15px'}} ><MultiButtons
        
          noButtons={2}
          buttonCaption={["Income Protection", "Estate Protection"]}
          selectMultiButton={this.selectMultiButtonINAorTax}
        /></div>
         */}

        <div className="topMargin" />

        <div style={{ height: "0px" }}>
          <PopupUserinputDialog
            openDialog={showInput === true}
            language={dataInput.Presentations[0].language}
            respondToInput={this.respondToSaveRequest}
          />
        </div>
        <Collapsible
          id={COLLAPSIBLE_PRESENTATION}
          title={TITLES[dataInput.Presentations[0].language].presentations}
          openParent={this.openParent}
          openCollapsible={this.openCollapsible[COLLAPSIBLE_PRESENTATION]}
          handleCollapsibleClick={this.handleCollapsibleClick}
        >
          {dataInput.Presentations.map((presentation) => (
            <Presentation
              key={presentation.id}
              id={1}
              provinceKey={presentation.provinceKey}
              presentationCurr={presentation}
              language={dataInput.Presentations[0].language}
              presentationsNo={1}
              handleUpdate={this.handleUpdatePresentation}
            />
          ))}
        </Collapsible>
        <Collapsible
          id={COLLAPSIBLE_CLIENTS}
          title={TITLES[dataInput.Presentations[0].language].clients}
          openParent={this.openParent}
          openForce={this.openForce}
          handleCollapsibleClick={this.handleCollapsibleClick}
          openCollapsible={this.openCollapsible[COLLAPSIBLE_CLIENTS]}
        >
          {dataInput.Clients.map((client) => (
            <Client
              key={client.id}
              id={i++}
              clientCurr={client}
              hasSurivor={hasSurivor}
              isTheSurvivor={
                dataInput.Clients[this.survIdx].memberKey === client.memberKey
                  ? true
                  : false
              }
              themeColor={i % 2 && isMobileDevice() ? altRow : "white"}
              language={dataInput.Presentations[0].language}
              clientsNo={dataInput.Clients.length} //clientsNo}
              handleUpdate={this.handleUpdateClient}
              handleAddClient={this.handleAddClient}
              handleRemoveClient={this.handleRemoveClient}
              switchClients={this.switchClients}
            />
          ))}
        </Collapsible>

        <Collapsible
          id={COLLAPSIBLE_ASSETS}
          title={TITLES[dataInput.Presentations[0].language].assets}
          openParent={this.openParent}
          openCollapsible={this.openCollapsible[COLLAPSIBLE_ASSETS]}
          handleCollapsibleClick={this.handleCollapsibleClick}
        >
          {dataInput.Assets.map((asset) => (
            <Asset
              key={asset.id}
              assetCurr={asset}
              id={j++}
              language={dataInput.Presentations[0].language}
              themeColor={j % 2 && isMobileDevice() ? altRow : "white"}
              assetsNo={dataInput.Assets.length} //.assetsNo}
              handleUpdate={this.handleUpdateAsset}
              handleAddAsset={this.handleAddAsset}
              handleRemoveAsset={this.handleRemoveAsset}
              handleAddAssetTaxLiability={this.handleAddAssetTaxLiability}
              adjustVisibleOutputSection={this.adjustVisibleOutputSection}
              //getAssetProjection={this.handleFetchAssetProjection}
              projection={dataOutput.assetProjections}
            />
          ))}
          {/* allow zero rows */}
          {dataInput.Assets.length === 0 ? ( //).assetsNo === 0 ? (
            <AddRemove
              currentID={0}
              minComps={0}
              numberComps={0}
              handleDoAdd={this.handleAddAsset}
              handleDoRemove={this.handleRemoveAsset}
            />
          ) : (
            ""
          )}
        </Collapsible>
        <Collapsible
          id={COLLAPSIBLE_LIABS}
          title={TITLES[dataInput.Presentations[0].language].liabilities}
          openParent={this.openParent}
          openCollapsible={this.openCollapsible[COLLAPSIBLE_LIABS]}
          handleCollapsibleClick={this.handleCollapsibleClick}
        >
          {dataInput.Liabilitys.map((liability) => (
            <Liability
              key={liability.id}
              liabilityCurr={liability}
              language={dataInput.Presentations[0].language}
              liabilitysNo={dataInput.Liabilitys.length} //.liabilitysNo}
              themeColor={k % 2 && isMobileDevice() ? altRow : "white"}
              handleUpdate={this.handleUpdateLiability}
              handleAddLiability={this.handleAddLiability}
              handleRemoveLiability={this.handleRemoveLiability}
              handleAddAssetTaxCredit={this.handleAddAssetTaxCredit}
            />
          ))}
          {/* allow zero rows */}
          {dataInput.Liabilitys.length === 0 ? ( //).liabilitysNo === 0 ? (
            <AddRemove
              currentID={0}
              minComps={0}
              numberComps={0}
              handleDoAdd={this.handleAddLiability}
              handleDoRemove={this.handleRemoveLiability}
            />
          ) : (
            ""
          )}
        </Collapsible>

        {this.INAOption === DISPLAY_INCOME && (
          <Collapsible
            id={COLLAPSIBLE_SOURCES}
            title={TITLES[dataInput.Presentations[0].language].sources}
            openParent={this.openParent}
            openCollapsible={this.openCollapsible[COLLAPSIBLE_SOURCES]}
            handleCollapsibleClick={this.handleCollapsibleClick}
          >
            {govPopup}
            {dataInput.Sources.map((source) => {
              let OrphanAges;
              let maxOrphanDur;
              if (
                source.sourceTypeKey === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key
              ) {
                OrphanAges = dataInput.Clients.filter(function (item) {
                  return source.ownerID === item.id;
                });
                maxOrphanDur =
                  (dataInput.Presentations[0].provinceKey === "QC"
                    ? MAX_ORPHAN_DUR_QC
                    : MAX_ORPHAN_DUR_NON_QC) - OrphanAges[0].Age;
              }
              return (
                <Source
                  key={source.id}
                  id={n++}
                  sourceCurr={
                    source.sourceTypeKey ===
                    INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key
                      ? {
                          ...source,
                          maxOrphan: this.orphan,
                          maxOrphanDur: maxOrphanDur,
                        }
                      : source
                  }
                  /* Type={source.Type}
              amount={source.amount}
              startYear={source.startYear}
              duration={source.duration}
              ownerID={source.ownerID} */
                  includeGovOrphanBenefit={this.areThereChildren()}
                  language={dataInput.Presentations[0].language}
                  sourcesNo={dataInput.Sources.length} //sourcesNo}
                  themeColor={n % 2 && isMobileDevice() ? altRow : "white"}
                  handleUpdate={this.handleUpdateSource}
                  handleAddSource={this.handleAddSource}
                  handleRemoveSource={this.handleRemoveSource}
                />
              );
            })}
          </Collapsible>
        )}
        {this.INAOption === DISPLAY_INCOME && (
          <Collapsible
            id={COLLAPSIBLE_NEEDS}
            title={TITLES[dataInput.Presentations[0].language].needs}
            openParent={this.openParent}
            openCollapsible={this.openCollapsible[COLLAPSIBLE_NEEDS]}
            handleCollapsibleClick={this.handleCollapsibleClick}
          >
            {dataInput.Needs.map((need) => (
              <Need
                key={need.id}
                id={l++}
                needCurr={need}
                language={dataInput.Presentations[0].language}
                needsNo={dataInput.Needs.length} //needsNo}
                afterTaxTotalIncome={this.getAfterTaxTotalIncome()}
                themeColor={l % 2 && isMobileDevice() ? altRow : "white"}
                handleUpdate={this.handleUpdateNeed}
                handleAddNeed={this.handleAddNeed}
                handleRemoveNeed={this.handleRemoveNeed}
              />
            ))}
          </Collapsible>
        )}
        {/*<Collapsible id="8" title={TITLES[dataInput.Presentations[0].language].settings} openParent={this.openParent}  handleCollapsibleClick
={this. handleCollapsibleClick
}>
					<Setting key={this.state.dataSettings.Settings.id} index={1} Province={this.state.dataSettings.Settings.Province} invRate={this.state.dataSettings.Settings.invRate} inflation={this.state.dataSettings.Settings.inflation} taxRate={this.state.dataSettings.Settings.taxRate} language={dataInput.Presentations[0].language}  handleUpdate={this.handleUpdateSetting} />
					
				</Collapsible>*/}

        {this.state.failedAPI ? (
          <div style={{ paddingLeft: "40%" }}>
            <Info
              infoIcon={getInfoNoInternetAccess(
                dataInput.Presentations[0].language
              )}
              respondToPopUp={this.respondToPopUp}
              ref={(Info) => (this.dlgLogin = Info)}
            />
          </div>
        ) : (
          ""
        )}

        <Collapsible
          id={COLLAPSIBLE_RESULTS}
          title={TITLES[dataInput.Presentations[0].language].results}
          openParent={this.openParent}
          openCollapsible={this.openCollapsible[COLLAPSIBLE_RESULTS]}
          handleCollapsibleClick={this.handleCollapsibleClick}
        >
          {/*<div>
					<div style={{height:'10px',width: '100%',textAlign: 'right', fontSize: '12px',paddingTop: '0px', color: 'maroon',  clear:'both' }}>	{msg1}		
					</div>
					
					<div style={{width: '100%',float: 'left', clear: 'left'}}>
							<MultiButtons button1={pres} button2={gr} buttonActive={this.graphs ? 2 : 1} selectButton={this.setOutput} />
					</div>*/}
          <div style={{ width: "100%", float: "left", clear: "left" }}>
            {versionDetails().allowAnalysis === true && appletMode !== "INA" ? (
              <MultiButtons
                noButtons={4}
                buttonCaption={buttonCaption}
                selected={dataInput.Presentations[0].resultsOption}
                selectMultiButton={this.selectMultiButton}
              />
            ) : (
              <MultiButtons
                noButtons={3}
                buttonCaption={buttonCaption3}
                selected={dataInput.Presentations[0].resultsOption}
                selectMultiButton={this.selectMultiButton}
              />
            )}
          </div>

          <div style={{ width: "100%", float: "left", clear: "left" }}>
            {/* <MultiButtons
              button1={ret}
              button2={le}
              buttonActive={this.toRetirement ? 1 : 2}
              selectButton={this.setInsDuration}
            /> */}
            {this.INAOption === DISPLAY_INCOME &&
              dataInput.Presentations[0].resultsOption !== DISPLAY_ANALYSIS && (
                <MultiButtons
                  noButtons={
                    dataInput.Clients[this.survIdx].memberKey !==
                    MEMBER.SPOUSE.Key
                      ? 1
                      : 3
                  }
                  buttonCaption={buttonCaptionPeriod}
                  selected={dataInput.Presentations[0].periodOption + 1}
                  selectMultiButton={this.selectMultiButtonPeriod}
                />
              )}
            {periodOption !== DISPLAY_RETIREMENT &&
              dataInput.Presentations[0].resultsOption !== DISPLAY_ANALYSIS && (
                <span style={{ fontSize: "10px", fontColor: "grey" }}>
                  {/* <Info iconName="infoRed.png" id="warning" msg={msg1} /> */}
                </span>
              )}
          </div>
          {dataOutput.dataCashFlowPersonal.length === 0 ? (
            ""
          ) : dataInput.Presentations[0].resultsOption === DISPLAY_GRAPHS ? (
            appletMode === "INA" ? (
              graphs
            ) : (
              graphsEP
            )
          ) : dataInput.Presentations[0].resultsOption ===
            DISPLAY_SPREADSHEET ? (
            //<div style={{ width: tableWidth }}>
            <div>
              {/* {appletMode === "INA" && this.state.dataOutput.aggregateGrid !== null && this.state.dataOutput.aggregateGrid !== undefined ? */}
              {
                this.state.dataOutput.aggregateGrid !== null &&
                  this.state.dataOutput.aggregateGrid !== undefined && (
                    <AggregateGrid
                      aggregateGrid={this.state.dataOutput.aggregateGrid}
                      lang={dataInput.Presentations[0].language}
                    />
                  )
                /*<DataTable >
                  /* gridTitle={this.state.dataOutput.aggregateGrid.gridTitle}
                  gridColumnsHeaders={this.state.dataOutput.aggregateGrid.gridColumnsHeaders}
                  gridColumnsDataMain={this.state.dataOutput.aggregateGrid.gridColumnsDataMain}
                  gridColumnsDataExcelInfoSection={this.state.dataOutput.aggregateGrid.gridColumnsDataExcelInfoSection}
                  gridColumnAligns={this.state.dataOutput.aggregateGrid.gridColumnAligns}
                  gridIcons={this.state.dataOutput.aggregateGrid.gridIcons}
                  language={dataInput.Presentations[0].language}
                /> */
              }
              {/* : appletMode === "EP" && <ExcelSpreadsheetEP input={this.state} noProjectYrs={noProjectYrs} />} */}
            </div>
          ) : dataInput.Presentations[0].resultsOption === DISPLAY_ANALYSIS ? (
            analysis
          ) : this.INAOption === DISPLAY_INCOME ? (
            <OutputPresentation
              insuranceNeed={insNeed}
              insuranceNeedRet={insNeedRet}
              insuranceNeedLE={insNeedLE}
              insuranceNeedEAge={insNeedEAge}
              projectEnd={projectEnd}
              LE={dataOutput.lifeExpectancy.spouse + survAge}
              dataInput={dataInput}
              INAOption={this.INAOption}
              dataShortfall={dataShort}
              //periodOption={periodOption}
            />
          ) : (
            <OutputPresentationEP
              insuranceNeed={insNeed}
              insuranceNeedRet={insNeedRet}
              insuranceNeedLE={insNeedLE}
              insuranceNeedEAge={insNeedEAge}
              projectEnd={projectEnd}
              LE={dataOutput.lifeExpectancy.spouse + survAge}
              dataInput={dataInput}
              INAOption={this.INAOption}
              dataEstateLiability={dataEstateLiability} //getDataFutureEstateLiability(this.dataTaxLiability.numericValues, totalLiabProjections)}
              dataShortfall={dataShort}
              periodOption={periodOption}
            />
          )}
        </Collapsible>
        <div id="copyDiv"></div>

        {/*				<DownloadExcel ref={this.excel}  id="DExcel" downloadNow={this.state.downloadExcelNow} hideElement={true}/>						
			
				
				
 <button onPress={() => Linking.openURL('mailto:support@example.com?subject=SendMail&body=Description') }
      title="support@example.com" /> */}
        <br />
      </div>
    );
  }
}
