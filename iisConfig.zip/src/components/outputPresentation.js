﻿import React, { Component } from "react";
import "./Output.css";
import { Table } from "react-bootstrap";
import {
  CONTROLTITLE,
  DISPLAY_RETIREMENT,
  DISPLAY_LIFEEXP,
  DISPLAY_ENDAGE,
  MAX_ORPHAN_DUR_QC,
  MAX_ORPHAN_DUR_NON_QC,
  ORPHAN_AGE_QC,
  ORPHAN_AGE_NON_QC,
  PROVINCE

} from "../definitions/generalDefinitions";
import { OUTPUTTEXT } from "../definitions/outputDefinitions";
import { Bar } from "react-chartjs-2";
import { doSavePdfAction } from "./OutputPDF";
//import jsPDF from 'jspdf';
//import * as jsPDF from 'jspdf';
import { cleanFormat, formatMoney, getListItemKeyFromName } from "../utils/helper";
import { getOutputValues } from "../data/dataExchange";
import {
  getInfoINA,
} from "../definitions/infoIconsDefinitions";
import { Info } from "./Info";


export class OutputPresentation extends Component {
  constructor(props) {
    super(props);
    this.dateApplet = "";
  }

  doPDF = () => {
    doSavePdfAction(this.props);
  };

  render() {

    // presentation output shared with pdf
    let output = getOutputValues(this.props)
    const lang = this.props.dataInput.Presentations[0].language
    const labelsBilingual = OUTPUTTEXT[lang]
    const decimalChar = lang === "en" ? "." : ","
    const thousands = lang === "en" ? "," : " "
    const formatFr=lang==="fr"? true:false
    
    const provinceKey = getListItemKeyFromName(PROVINCE, output.province);
    let maxDur = provinceKey === "QC" ? MAX_ORPHAN_DUR_QC : MAX_ORPHAN_DUR_NON_QC
    let orphAge = provinceKey === "QC" ? ORPHAN_AGE_QC : ORPHAN_AGE_NON_QC;

    // graph details
    const options = {
      legend: {
        display: false
      },
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        xAxes: [{ stacked: true }],
        yAxes: [
          {
            stacked: true,
            ticks: {
              beginAtZero: true,
              steps: 10,
              stepValue: 5
            }
          }
        ]
      }
    };

    // console.log(output)	


    var dataLabels = ["A", "B"];
    var dataValues = [
      output.insNeedLE + output.totalAsset - output.totalLiab,
      output.insNeedRet + output.totalAsset - output.totalLiab
    ];
    var dColor = ["#7399c6", "#d9d3a4"];
    const under25 = output.ygChild < maxDur ? output.insNeedYgChild25 + output.totalAsset - output.totalLiab : 0
    const under18 = output.ygChild < orphAge ? output.insNeedYgChild18 + output.totalAsset - output.totalLiab : 0

    if (output.hasChild) {
      dataLabels = ["A", "B", "C", "D"];
      dataValues = [
        output.insNeedLE + output.totalAsset - output.totalLiab,
        output.insNeedRet + output.totalAsset - output.totalLiab,
        under25,
        under18
      ];
      dColor = ["#7399c6", "#d9d3a4", "#949ca1", "#847a18"];
    }

    var dataValues2 = [output.insNeedLE, output.insNeedRet];
    if (output.hasChild) {
      dataLabels = ["A", "B", "C", "D"];
      dataValues2 = [output.insNeedLE, output.insNeedRet, output.insNeedYgChild25, output.insNeedYgChild18];
      dColor = ["#7399c6", "#d9d3a4", "#949ca1", "#847a18"];
    }

    const dataInsurance = {
      labels: dataLabels,
      datasets: [
        {
          label: "", //Income Shortfall',
          data: dataValues,
          fill: false, // Don't fill area under the line
          borderColor: "#2B3856", // Line color
          backgroundColor: dColor
        }
      ]
    };

    const dataInsurance2 = {
      labels: dataLabels,
      datasets: [
        {
          label: "", //Income Shortfall',
          data: dataValues2,
          fill: false, // Don't fill area under the line
          borderColor: "#2B3856", // Line color
          backgroundColor: dColor
        }
      ]
    };

    let needTo =
      this.props.dataInput.Presentations[0].periodOption === DISPLAY_RETIREMENT ? labelsBilingual.insNeedsRet : (this.props.dataInput.Presentations[0].periodOption === DISPLAY_ENDAGE ? labelsBilingual.insNeeds100 : labelsBilingual.insNeedsRetLE)
    if (this.props.dataInput.Presentations[0].periodOption !== DISPLAY_ENDAGE)
      needTo += + this.props.projectEnd + ")";
    //		return <div><h2>this useless output is for {designedFor} designed by {designedBy}: {noRow} and this {val}</h2></div>;

    return (
      <div>
        <input
          className="multiButtons multiButtonsAct"
          style={{
            width: "130px",
            marginTop: "0px",
            paddingRight: "8px",
            float: "right"
          }}
          onClick={this.doPDF}
          type="button"
          value={CONTROLTITLE[lang].pdf}
        />
        <h3 className="ppi1">
          {needTo}: ${formatMoney(cleanFormat(this.props.insuranceNeed,formatFr), 0, decimalChar, thousands)}
          <Info
            infoIcon={getInfoINA(lang)}
          />
        </h3>

        <div className="contentPres">
          <br />
          <br />
          <img
            className="ppi1 pict"
            id="INAPage1"
            src={require("../images/INA.png")}
          />
          <h1 className="ppi1">{labelsBilingual.pg1T}</h1>
          <h5 className="ppi2">
            {labelsBilingual.pg1P1} {output.designedFor}
            <br />
            {labelsBilingual.pg1P2} {output.designedBy}
            <br />
            {labelsBilingual.pg1P3} {output.dateApplet}
            <br />
            {labelsBilingual.pg1P4} {output.province}
            <br />
          </h5>
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg1T}</h2>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            {/* PAGE 2 profile*/}
            <table className="blueTable">
              <thead>
                <tr>
                  <th style={{ width: "23%" }}>
                    {labelsBilingual.pg2TabT1}
                  </th>
                  <th style={{ width: "20%" }}>
                    {labelsBilingual.pg2TabT2}
                  </th>
                  <th style={{ width: "30%" }}>
                    {labelsBilingual.pg2TabT3}
                  </th>
                  <th style={{ width: "27%" }}>
                    {labelsBilingual.pg2TabT4}
                  </th>
                </tr>
              </thead>
              <tbody>
                {output.clients.map(item => (
                  <tr key={item.id}>
                    <td>{item.member}</td>
                    <td className="textalignright">{item.age}</td>
                    <td className="textalignright">${formatMoney(cleanFormat(item.income,formatFr), 0, decimalChar, thousands)}</td>
                    <td className="textalignright">{item.ret}</td>
                  </tr>
                ))}
                {/*}			<tr>
							
							<td>Client</td><td className="textalignrightwidth110">${formatMoney(Income, 0,decimalChar,thousands)}</td><td className="textalignright">{retAge}</td><td className="textalignright">{retAge}</td></tr>
								<tr>
							<td>Spouse</td><td className="textalignrightwidth110">${formatMoney(Income2, 0,decimalChar,thousands)}</td><td className="textalignright">{retAge2}</td><td className="textalignright">{retAge}</td></tr>
						*/}
              </tbody>
            </table>
          </div>
          {/* PAGE 3 Family Cash Needs at Death*/}
          <br />
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg3T}</h2>
          <p className="ppi1">{labelsBilingual.pg3P1}</p>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <div className="tableTitle">
              {labelsBilingual.pg3TabT}
            </div>
            <table className="cashNeeds">
              <thead></thead>
              <tbody>
                {output.liabilities.map(item => (
                  <tr key={item.name}>
                    <td style={{ width: "50%" }}>{item.name}</td>
                    <td className="textalignright">
                      ${formatMoney(item.value, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                ))}
                <tr className="backgroundcolorDCE5F0">
                  <td>
                    <strong>
                      {labelsBilingual.pg3TabRTot}
                    </strong>
                  </td>
                  <td className="textalignrightpaddingright20">
                    <strong>${formatMoney(output.totalLiab, 0, decimalChar, thousands)}</strong>
                  </td>
                </tr>
                {/*	<tr className="backgroundcolorDCE5F0">
								<td><strong>Permanent Cash Needs <sup>p</sup></strong></td>
										<td className="textalignright"><strong>$200 <sup>p</sup></strong></td>
									</tr>*/}
              </tbody>
            </table>
          </div>
          {/* PAGE 4 Family Income Needs at Death*/}
          <br />
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg4T}</h2>
          <p className="ppi1">{labelsBilingual.pg4P1}</p>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <div className="tableTitle">
              {labelsBilingual.pg4TabT}
            </div>
            <table className="incomeNeeds">
              <thead></thead>
              <tbody>
                <tr>
                  <td className="paddingleft25" style={{ width: "70%" }}>
                    {labelsBilingual.pg4TabRow1}
                  </td>
                  <td className="textalignright">
                    ${formatMoney(output.Income + output.Income2, 0, decimalChar, thousands)}
                  </td>
                </tr>
                <tr className="backgroundcolorFFFFFF">
                  <td>
                    <br />
                    {labelsBilingual.pg4TabRow2}
                  </td>
                  <td></td>
                </tr>


                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg4TabRow3}
                    </td>
                    <td className="textalignright">{output.percent1}%</td>
                  </tr>
                }
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg4TabRow4}
                    </td>
                    <td className="textalignright">{output.percent2}%</td>
                  </tr>
                }
                {output.percent2 === 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg4TabRow4}
                    </td>
                    <td className="textalignright">{output.percent1}%</td>
                  </tr>

                }


                <tr className="backgroundcolorFFFFFF">
                  <td></td>
                  <td></td>
                </tr>
                <tr className="backgroundcolorFFFFFF">
                  <td>{labelsBilingual.pg4TabRow5}</td>
                  <td></td>
                </tr>
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg4TabRow6}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.percentNeed1, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                {output.percent2 > 0 &&

                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg4TabRow7}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.percentNeed2, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                {output.percent2 === 0 &&

                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg4TabRow7}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.percentNeed1, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
          <br />
          {/* PAGE 5 Family Cash Sourcess at Death*/}
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg5T}</h2>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <div className="tableTitle">
              {labelsBilingual.pg5TabT}
            </div>
            <table className="cashSources">
              <tbody>
                {/* add gov db*/}
                <tr>
                  <td style={{ height: "1px", width: "50%" }}>
                    {labelsBilingual.pg5TabRow1}
                  </td>
                  <td
                    className="textalignright"
                    style={{ height: "1px", width: "25%" }}
                  >
                    ${formatMoney(output.govDB, 0, decimalChar, thousands)}
                  </td>
                </tr>
                {output.assets.map(item => (
                  <tr key={item.name}>
                    <td style={{ height: "1px", width: "50%" }}>{item.name}</td>
                    <td
                      className="textalignright"
                      style={{ height: "1px", width: "25%" }}
                    >
                      ${formatMoney(item.value, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                ))}
                <tr className="backgroundcolorDCE5F0">
                  <td>{labelsBilingual.pg5TabRow3}</td>
                  <td className="textalignright">
                    ${formatMoney(output.totalAsset, 0, decimalChar, thousands)}
                  </td>
                  <td className="textalignright">
                    ${formatMoney(output.totalAsset, 0, decimalChar, thousands)}
                  </td>
                </tr>
                <tr className="backgroundcolorDCE5F0">
                  <td>{labelsBilingual.pg5TabRow4}</td>
                  <td> </td>
                  <td
                    className="textalignright"
                    style={{ height: "1px", width: "25%" }}
                  >
                    ${formatMoney(output.totalLiab, 0, decimalChar, thousands)}
                  </td>
                </tr>
                <tr>
                  <td>{labelsBilingual.pg5TabRow5}</td>
                  <td> </td>
                  <td className="textalignright">
                    ${formatMoney(output.totalAsset - output.totalLiab, 0, decimalChar, thousands)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          {/* PAGE 6 Family Income Sources at Death*/}
          <br />
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg6T}</h2>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <div className="tableTitle">
              {labelsBilingual.pg6TabT}
            </div>

            <table className="incomeSources">
              <tbody>
                {output.sources.map(item => (
                  <tr key={item.name}>
                    <td style={{ width: "70%" }}>{item.name}</td>
                    <td className="textalignright">
                      ${formatMoney(item.value, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                ))}
                <tr className="backgroundcolorFFFFFF">
                  <td></td>
                  <td></td>
                </tr>
                <tr className="backgroundcolorFFFFFF">
                  <td>{labelsBilingual.pg6TabRow1}</td>
                  <td></td>
                </tr>
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg6TabRow2}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.totalSource, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                {output.percent2 > 0 &&

                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg6TabRow3}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.totalSource2, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                {output.percent2 === 0 &&

                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg6TabRow3}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.totalSource, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                <tr className="backgroundcolorFFFFFF">
                  <td></td>
                  <td></td>
                </tr>
                <tr className="backgroundcolorFFFFFF">
                  <td>{labelsBilingual.pg6TabRow4}</td>
                  <td></td>
                </tr>
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg6TabRow5}
                    </td>
                    <td className="textalignrightbackgroundcolorDCE5F0">
                      <strong>
                        ${formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0, decimalChar, thousands)}
                      </strong>
                    </td>
                  </tr>
                }
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg6TabRow6}
                    </td>
                    <td className="textalignrightbackgroundcolorDCE5F0">
                      <strong>
                        ${formatMoney(Math.max(0, output.percentNeed2 - output.totalSource2), 0, decimalChar, thousands)}
                      </strong>
                    </td>
                  </tr>
                }
                {output.percent2 === 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg6TabRow6}
                    </td>
                    <td className="textalignrightbackgroundcolorDCE5F0">
                      <strong>
                        ${formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0, decimalChar, thousands)}
                      </strong>
                    </td>
                  </tr>}



              </tbody>
            </table>
          </div>
          {/* PAGE 7 life i anal*/}
          <br />
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg7T}</h2>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <div className="tableTitle">
              {labelsBilingual.pg7TabT}
            </div>

            <table className="incomePosition">
              <tbody>
                <tr className="backgroundcolorFFFFFF">
                  <td style={{ width: "70%" }}> </td>
                  <td> </td>
                </tr>
                <tr>
                  <td className="backgroundcolorFFFFFF">
                    {labelsBilingual.pg7TabRow1}
                  </td>
                  <td className="backgroundcolorFFFFFF"></td>
                </tr>
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg7TabRow2}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                {output.percent2 > 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg7TabRow3}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(Math.max(0, output.percentNeed2 - output.totalSource2), 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }
                {output.percent2 === 0 &&
                  <tr>
                    <td className="paddingleft25">
                      {labelsBilingual.pg7TabRow3}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0, decimalChar, thousands)}
                    </td>
                  </tr>
                }

                <tr>
                  <td className="paddingleft25">
                    {labelsBilingual.pg7TabRow4}
                  </td>
                  <td className="textalignright">{output.infRate}%</td>
                </tr>
                <tr>
                  <td className="paddingleft25">
                    {labelsBilingual.pg7TabRow5}
                  </td>
                  <td className="textalignright">{output.invRate}%</td>
                </tr>
                <tr className="backgroundcolorFFFFFF">
                  <td> </td>
                  <td> </td>
                </tr>
                <tr>
                  <td className="backgroundcolorFFFFFF">
                    {labelsBilingual.pg7TabRow6}
                  </td>
                  <td className="backgroundcolorFFFFFF"> </td>
                </tr>
                <tr>
                  <td>
                    <strong></strong>
                    {labelsBilingual.pg7TabRow7} {this.props.LE}
                    )
                  </td>
                  <td className="textalignright">
                    $
                    {formatMoney(
                    Math.max(0, output.insNeedLE + output.totalAsset - output.totalLiab),
                    0, decimalChar, thousands)}
                  </td>
                </tr>
                <tr>
                  <td>
                    <strong></strong>
                    {labelsBilingual.pg7TabRow8}
                  </td>
                  <td className="textalignright">
                    $
                    {formatMoney(
                    Math.max(0, output.insNeedRet + output.totalAsset - output.totalLiab),
                    0, decimalChar, thousands)}
                  </td>
                </tr>
                {output.hasChild && output.ygChild < maxDur && (
                  <tr>
                    <td>
                      <strong></strong>
                      {labelsBilingual.pg7TabRow9}
                    </td>
                    <td className="textalignright">
                      $
                      {formatMoney(
                      Math.max(0, output.insNeedYgChild25 + output.totalAsset - output.totalLiab),
                      0, decimalChar, thousands)}
                    </td>
                  </tr>
                )}
                {output.hasChild && output.ygChild < orphAge && (
                  <tr>
                    <td>
                      <strong></strong>
                      {labelsBilingual.pg7TabRow10}
                    </td>
                    <td className="textalignright">
                      $
                      {formatMoney(
                      Math.max(0, output.insNeedYgChild18 + output.totalAsset - output.totalLiab),
                      0, decimalChar, thousands)}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          {/* PAGE 7 chart*/}
          <div style={{ color: "darkBlue", marginTop: "55px" }}>
            <br />
            <div style={{ marginLeft: "20px", width: "90%" }}>
              <div style={{ width: "75%" }}>
                <article
                  id="bar1"
                  className="canvas-container"
                  style={{ height: "200px" }}
                >
                  <Bar data={dataInsurance} options={options} />
                </article>
              </div>
            </div>
          </div>
          <br />
          <br />
          {/* PAGE 8 Your Family Financial Position at Death*/}
          <br />
          <hr className="ppi1" />
          <h2 className="ppi1"> {labelsBilingual.pg8T}</h2>
          <div className="tableTitle">
            {labelsBilingual.pg8TabT}
          </div>
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <table className="incomePosition">
              <tbody>
                <tr>
                  <td width="70%">
                    {labelsBilingual.pg8TabRow1}
                  </td>
                  <td className="textalignright" width="30%">
                    ${formatMoney(output.totalAsset - output.totalLiab, 0, decimalChar, thousands)}
                  </td>
                </tr>
                <tr>
                  <td className="backgroundcolorFFFFFF">
                    <br />{labelsBilingual.pg8TabRow2}
                  </td>
                  <td className="backgroundcolorFFFFFF"></td>
                </tr>
                <tr>
                  <td>
                    <strong></strong>
                    {labelsBilingual.pg8TabRow3}
                    {this.props.LE})
                  </td>
                  <td className="textalignright">
                    ${this.props.insuranceNeedLE}
                  </td>
                </tr>
                <tr>
                  <td>
                    <strong></strong>
                    {labelsBilingual.pg8TabRow4}
                  </td>
                  <td className="textalignright">
                    ${this.props.insuranceNeedRet}
                  </td>
                </tr>
                {output.hasChild && output.ygChild < maxDur && (
                  <tr>
                    <td>
                      <strong></strong>
                      {labelsBilingual.pg8TabRow5}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.insNeedYgChild25, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                )}
                {output.hasChild && output.ygChild < orphAge && (
                  <tr>
                    <td>
                      <strong></strong>
                      {labelsBilingual.pg8TabRow6}
                    </td>
                    <td className="textalignright">
                      ${formatMoney(output.insNeedYgChild18, 0, decimalChar, thousands)}
                    </td>
                  </tr>
                )}
                <tr></tr>
              </tbody>
            </table>
          </div>
          {/* PAGE 8 chart*/}
          <div style={{ color: "darkBlue", marginTop: "55px" }}>
            <br />
            <div style={{ marginLeft: "20px", width: "90%" }}>
              <div style={{ width: "75%" }}>
                <article
                  id="bar2"
                  className="canvas-container"
                  style={{ height: "200px" }}
                >
                  <Bar data={dataInsurance2} options={options} />
                </article>
              </div>
            </div>
          </div>
          <br />
          <br />
          {/* PAGE 9 notes*/}
          <br />
          {/*<img className="ppi2" src="img/desktop/picture1.png" width="400" alt="Capital Requirements Chart" />*/}
          <br /> <br />
          <hr className="ppi1" />
          <h2 className="ppi1">{labelsBilingual.pg9T}</h2>
          <p className="ppi1">{labelsBilingual.pg9P1}</p>
          <br />
          <hr className="ppi1" />
          {/* PAGE 10 ackno*/}
          <br />
          <br /> <br />
          <h2 className="ppi1">{labelsBilingual.pg10T}</h2>
          <p className="ppi1">{labelsBilingual.pg10P1}</p>
          <br /> <br />
          <br />
          <br />
          <br />
          <p className="ppi1">
            {labelsBilingual.pg10TabRow1}
            <br />
            <span style={{ paddingLeft: "118px" }}>
              {labelsBilingual.pg10TabRow11}
            </span>
          </p>
          <br />
          <br />
          <p className="ppi1">
            {labelsBilingual.pg10TabRow2}
            <br />
            <span style={{ paddingLeft: "118px" }}>
              {labelsBilingual.pg10TabRow11}
            </span>
          </p>
          <br />
          <br />
          <p className="ppi1">
            {labelsBilingual.pg10TabRow3}
            <br />
            <span style={{ paddingLeft: "110px" }}>
              {labelsBilingual.pg10TabRow11}
            </span>
          </p>
          <br />
          <hr className="ppi1" />
        </div>
      </div>
    );
  }
}
