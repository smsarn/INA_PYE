import React, { Component } from "react";
import debounce from "lodash.debounce";
import { cleanFormat } from "../utils/helper";
import { Info } from "./Info";


const waitTime = 500;

export class InputField extends Component {
  constructor(props) {
    super(props);
    //alert(this.props.inputName);
    this.state = {
      inputValue: this.props.inputValue,
      isEditing: false
    };
    /* this.infoIcon= this.props.infoIcon === undefined? 
		{
			msg: "",
			iconAlert: false,
      checkInfo: false,
      popupRight:false,
			idM: 0
		} : {
			msg: this.props.infoIcon.infoText,
			iconAlert: this.props.infoIcon.infoAlert,
      checkInfo: this.props.infoIcon.showInfoIcon,
      popupRight: this.props.infoIcon.popupRight,
			idM: this.props.infoIcon.infoID
		} */
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.inputValue !== this.props.inputValue) {
      this.setState({ inputValue: nextProps.inputValue });
    }
  }

  updateInputValue(evt) {
    // console.log(this.props.maxValue);
    var input;
    let chkNum;
    if (
      this.props.language === "fr" &&
      this.props.format === 3 &&
      global.langFr
    )
      chkNum = cleanFormat(evt.target.value, true);
    else chkNum = cleanFormat(evt.target.value);

    if (isNaN(chkNum) || evt.target.value === "") input = 0;
    else input = chkNum;
    const max = this.props.format === 2 ? (this.props.maxValue===undefined?1000000000:this.props.maxValue) :  this.props.maxValue===undefined?100:this.props.maxValue;
    
    if (input > max) input = max;
    if (input < 0) input = 0;
    //input=parseInt(100*input/100);
    // console.log(input)
    this.setState({ inputValue: input });
  }

  afterStateUpdate() {
    //this.props.handleUpdateInput(this.props.inputName, this.state.inputValue);
    this.props.handleUpdateInput(this.props.id, this.state.inputValue);
  }

  handleFocus = event => {
    if (navigator.userAgent.match(/Edge\/(13|14|15|16|17)/)) {
      //	return setTimeout( event.target.select.bind( event.target ), 1)
    } else event.target.select();
  };

  selectField = event => {
    if (navigator.userAgent.match(/Edge\/(13|14|15|16|17)/)) {
      event.target.setSelectionRange(0, event.target.value.length);
    }
  };
  onMouseUpSelect = event => {
    if (/iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream) {
      event.target.select();
    }
  };

  handleFocusIOS = event => {
    event.target.value = cleanFormat(event.target.value);
  };

  toCurrency(number) {
    let formatter;
    if (
      this.props.language === "fr" &&
      this.props.format === 3 &&
      global.langFr
    )
      number = cleanFormat(number, true);
    else number = cleanFormat(number);
    if (isNaN(number) || number === "") number = 0;
    if (this.props.format === 2)
      formatter =
        (this.props.language === "fr" ? "" : "$") +
        new Intl.NumberFormat().format(parseInt(number));
    else if (this.props.format === 3) {
      /* alert(number.toString());
			alert(number.toString().length);
			alert(number.toString()[number.toString().length]); */
      if (this.props.language === "fr" && global.langFr) {
        formatter =
          number.toString()[number.toString().length - 1] === "."
            ? parseFloat(number) + ","
            : parseFloat(number);
        formatter = formatter.toString().replace(".", ",");
      } else
        formatter =
          number.toString()[number.toString().length - 1] === "."
            ? parseFloat(number) + "."
            : parseFloat(number);
    } else formatter = parseInt(number);
    //console.log(formatter)
    return formatter;
  }

  toggleEditing = e => {
    /* e.target.value=this.toCurrency(e.target.value);		
				if(this.props.format === 3)e.target.value+="%"; */

    this.setState({ isEditing: !this.state.isEditing }, () =>
      this.afterStateUpdate()
    );
    //	this.props.handleUpdateInput(this.props.id, this.state.inputValue);
  };

  getValue = value => {
    const last = value.toString()[value.toString().length - 1];
    const dec = value.toString().indexOf(".");
    const first = value.toString()[0];

    if (first === 0 && dec === -1)
      return (
        parseFloat(100 * value.toString().slice(1, value.toString().length)) /
        100
      );
    else return parseFloat(100 * value) / 100;
  };

  selectText = () => {
    var s = this.refs.InputTxt.value;
    if (s.length) {
      window.setTimeout(function() {
        this.refs.InputTxt.setSelectionRange(s.length - 1, s.length);
      }, 0);
    }
  };

  getRidOfZerosAfterDecimal=(displayValue)=>{
    
    
    const decimalPos=displayValue.indexOf(".")
    if(decimalPos>=0) 
    {
      if(displayValue.length>= decimalPos+3) // 2 decimals max
        displayValue=displayValue.substring(0,decimalPos+3)
      // get rid of zeros  
      while (displayValue.slice(-1)==="0" && displayValue.length> decimalPos+3) {
          displayValue=displayValue.substring(0,displayValue.length-1)
      }
    }
    
    return displayValue
  }
  
  
  render() {
    // console.log(this.state,this.state.inputValue,this.props.inputName)
    let displayValue=this.state.inputValue!==undefined?this.state.inputValue.toString():"";
    if (displayValue.indexOf(".")>=0)
        displayValue=this.getRidOfZerosAfterDecimal(displayValue)
      //  displayValue=parseFloat(displayValue).toFixed(2);
    
    const title = this.props.inputName; //  this.props.Count === 1 ? this.state.inputName : this.state.inputName;
    const disable = this.props.readOnly ? true : false;
    let styleClass = disable ? "inputField inputFieldDisabled" : "inputField";
    styleClass += this.props.language === "fr" ? " inputFieldFrench" : "";
    const styleClass2 =
      styleClass +
      (this.props.format === 3 ||
      (this.props.format === 2 && this.props.language === "fr")
        ? " percentField"
        : "");

    let divStyleClass = "dropDown inputDiv";
    divStyleClass += this.props.language === "fr" ? " inputDivFrench" : "";
    const step =
      this.props.format === 2 ? 1000 : this.props.format === 3 ? 0.01 : 1;
    const max = this.props.format === 2 ? (this.props.maxValue===undefined?1000000000:this.props.maxValue) :  this.props.maxValue===undefined?100:this.props.maxValue;
    var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
    //iOS=false;
    var iOS2 = false;
    var checkInfo = false;

    let msg = "";
    let idM = "";

    if (this.props.info !== undefined && (this.props.showInfo===true || this.props.showInfo===undefined)) {
      msg = this.props.info;
      checkInfo = true;
      idM = "info" + title;
    }
    //	let st1=this.props.format===3?"styleClass st1percentField":"";
    let perc = this.props.format === 3;

    if (this.props.language === "fr" && this.props.format === 2) {
      return (
        <div
          className={divStyleClass}
          french={this.props.language === "en" ? "true" : "false"}
        >
          <div className="controlTitle">
            {title}
           {/*  {checkInfo === true ? (
              <Info id={idM} msg={msg} infoPosition={this.props.infoPosition} />
            ) : (
              ""
            )} */}
            {this.props.infoIcon !== undefined ? (
              			<Info  infoIcon={this.props.infoIcon}  /> //id={this.props.infoIcon.infoID} msg={this.props.infoIcon.infoText}  popupRight={this.props.infoIcon.popupRight}  iconName={this.props.infoIcon.infoAlert? "infoRed.png":"info.png"} />
            		):""}
          </div>
          {/*{iOS ? <input type="number" inputmode="numeric" pattern="\d*"  min="0" max={max} step={step} className={styleClass} isDisabled={disable} onFocus={this.handleFocus} onClick={this.select} value={this.getValue(displayValue)} onChange={evt => this.updateInputValue(evt)} onBlur={this.toggleEditing.bind(this)} />*/}
          {iOS2 ? (
            "" //<input type="text" inputmode="decimal" min="0.0" max={max} step={step} className={styleClass} isDisabled={disable} onFocus={this.handleFocus} onClick={this.select} value={displayValue} onChange={evt => this.updateInputValue(evt)}  />
          ) : (
            <div className={styleClass}>
              <span>
                <input
                  type="text"
                  className={styleClass2}
                  style={{ paddingTop: "0px", width: "86%" }}
                  inputMode="decimal"
                  disabled={disable}
                  value={this.toCurrency(displayValue)}
                  autoFocus
                  onFocus={e => this.handleFocus(e)}
                  onMouseUp={this.onMouseUpSelect}
                  onClick={this.selectField}
                  onChange={evt => this.updateInputValue(evt)}
                  onBlur={this.toggleEditing.bind(this)}
                />
                <label
                  style={{
                    display: "inline-block",
                    float: "left",
                    width: "3%"
                  }}
                >
                  $
                </label>
              </span>
            </div>
          )}
        </div>
      );
    } else {
      return (
        <div
          className={divStyleClass}
          french={this.props.language === "en" ? "true" : "false"}
        >
          <div className="controlTitle">
            {title}
           {/*  {checkInfo === true && (
              <Info id={idM} msg={msg} infoPosition={this.props.infoPosition}/>
            )} */}
           {this.props.infoIcon !== undefined ? (
              			<Info  infoIcon={this.props.infoIcon}   /> // id={this.props.infoIcon.infoID} msg={this.props.infoIcon.infoText} popupRight={this.props.infoIcon.popupRight} iconName={this.props.infoIcon.infoAlert? "infoRed.png":"info.png"} />
            		):""}
          </div>
          {/*{iOS ? <input type="number" inputmode="numeric" pattern="\d*"  min="0" max={max} step={step} className={styleClass} isDisabled={disable} onFocus={this.handleFocus} onClick={this.select} value={this.getValue(displayValue)} onChange={evt => this.updateInputValue(evt)} onBlur={this.toggleEditing.bind(this)} />*/}
          {iOS2 ? (
            "" //<input type="text" inputmode="decimal" min="0.0" max={max} step={step} className={styleClass} isDisabled={disable} onFocus={this.handleFocus} onClick={this.select} value={displayValue} onChange={evt => this.updateInputValue(evt)}  />
          ) : (
            <div>
              {perc === false ? (
                <div>
                  <input
                    type="text"
                    className={styleClass}
                    inputMode="decimal"
                    disabled={disable}
                    value={this.toCurrency(displayValue)}
                    onFocus={e => this.handleFocus(e)}
                    onClick={this.selectField}
                    onMouseUp={this.onMouseUpSelect}
                    onChange={evt => this.updateInputValue(evt)}
                    onBlur={this.toggleEditing.bind(this)}
                  />
                </div>
              ) : (
                <div className={styleClass}>
                  {/* <div className="percentDiv"> */}
                  <span>
                    <input
                      type="text"
                      className={styleClass2}
                      style={{ paddingTop: "0px", width: "86%" }}
                      inputMode="decimal"
                      disabled={disable}
                      value={this.toCurrency(displayValue)}
                      onFocus={e => this.handleFocus(e)}
                      onMouseUp={this.onMouseUpSelect}
                      onClick={this.selectField}
                      onChange={evt => this.updateInputValue(evt)}
                      onBlur={this.toggleEditing.bind(this)}
                    />
                    <label
                      style={{
                        display: "inline-block",
                        float: "left",
                        width: "3%"
                      }}
                    >
                      %
                    </label>
                  </span>
                </div>
              )}
            </div>
          )}
        </div>
      );
    }
  }
}
