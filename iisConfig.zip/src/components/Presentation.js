﻿import React, { Component } from "react";
import { DropDown } from "./DropDown";
//import { InputField4 } from './inputField4';
import { InputField } from "./inputField";
import { cleanFormat,getListItemKeyFromName } from "../utils/helper";
import { CONTROLTITLE, PROVINCE } from "../definitions/generalDefinitions";
import  {DROPDOWN_WIDE
} from "../definitions/generalDefinitions";
import {getListItemNameFromKey, getListToShowByOrder } from "../utils/helper";
import {
  getInfoIconNotes
} from "../definitions/infoIconsDefinitions";
import { Info } from "./Info";

export class Presentation extends Component {
  displayName = Presentation.name;

  constructor(props) {
    super(props);
    let i;
    /* let typeValues = [];
    for (i = 0; i <= 9; ++i) {
      typeValues.push({
        label: PROVINCE[this.props.language].Values[i],
        value: i + 1
      });
    } */

    let typeValues = [];
    const listProvincesToShow = getListToShowByOrder(PROVINCE);
    // console.log(listProvincesToShow)
    for (i = 0; i < listProvincesToShow.length; ++i) {
      typeValues.push({
        label: listProvincesToShow[i].value[this.props.language],
        value: i + 1
      });
    }



    //	alert(this.props.Province);
    this.state = {};
    this.dataValues = {
      DD: [
        {
          id: 1,
          Title: CONTROLTITLE[this.props.language].province,
          defValue:  getListItemNameFromKey(PROVINCE,this.props.presentationCurr.provinceKey,this.props.language),
          Values: typeValues
        }
      ]
    };
  }
  // unsafe use getDerivedStateFromProps TBD
   
  componentWillReceiveProps(nextProps) {
    if(nextProps.presentationCurr!==this.props.presentationCurr){
      this.dataValues.DD[0].defValue = getListItemNameFromKey(PROVINCE,nextProps.presentationCurr.provinceKey,this.props.language);
      //		this.dataValues.DD[0].Title = CONTROLTITLE[this.props.language].province;
    //  alert('got ch')
    }
  } 

  /* static getDerivedStateFromProps(nextProps, prevState){
    
    if(nextProps.presentationCurr!==prevState.presentationCurr){
      return {presentationCurr : nextProps.presentationCurr};
    }
    else return null;
  }

 */

  getNewPresentation=()=>{
   return { id: this.props.id,
    provinceKey: this.props.presentationCurr.provinceKey,
    invRate: this.props.presentationCurr.invRate,
    inflation: this.props.presentationCurr.inflation,
    taxRate:this.props.presentationCurr.taxRate,
    designedFor: this.props.presentationCurr.designedFor,
    designedBy: this.props.presentationCurr.designedBy,
    notes:  this.props.presentationCurr.notes,
    periodOption: this.props.presentationCurr.periodOption,
    language: this.props.presentationCurr.language,
    resultsOption: this.props.presentationCurr.resultsOption
   }
  }  

  updateDDown = (id, selection) => {
    let pres = this.getNewPresentation()
    if (id === 1) pres.provinceKey = getListItemKeyFromName(PROVINCE,selection);
    this.props.handleUpdate(pres);
  };

  handleUpdateInput = (id, value) => {
    let pres = this.getNewPresentation()

    if (id === 1)
      pres.invRate =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    else if (id === 2)
      pres.inflation =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    else if (id === 3)
      pres.taxRate =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    this.props.handleUpdate(pres);
  };

  updateInputValue(id, evt) {
    let pres = this.getNewPresentation()
    if (id === 3) pres.designedFor = evt.target.value;
    else if (id === 4) pres.designedBy = evt.target.value;
    else if (id === 5) pres.notes = evt.target.value;
    // console.log(pres,id)
    this.props.handleUpdate(pres);
  }

  render() {
    //alert(this.state.data.id);
    const infoIcon= getInfoIconNotes(this.props.language);
    return (
      <div
            className="inputRow"
      >
        {this.dataValues.DD.map(dd => (
          <DropDown
            key={dd.id}
            id={dd.id}
            Count={1}
            Title={dd.Title}
            width={DROPDOWN_WIDE}
            defValue={dd.defValue}
            Values={dd.Values}
            updateDDown={this.updateDDown}
          />
        ))}
        <InputField
          inputName={CONTROLTITLE[this.props.language].taxRate}
          format={3}
          id={3}
          Count={1}
          language={this.props.language}
          inputValue={this.props.presentationCurr.taxRate}
          inputTitle={this.props.id}
          handleUpdateInput={this.handleUpdateInput}
        />
        <InputField
          inputName={CONTROLTITLE[this.props.language].invRate}
          format={3}
          id={1}
          Count={1}
          language={this.props.language}
          inputValue={this.props.presentationCurr.invRate}
          inputTitle={this.props.id}
          handleUpdateInput={this.handleUpdateInput}
        />
        <InputField
          inputName={CONTROLTITLE[this.props.language].inflation}
          format={3}
          id={2}
          Count={1}
          language={this.props.language}
          inputValue={this.props.presentationCurr.inflation}
          inputTitle={this.props.id}
          handleUpdateInput={this.handleUpdateInput}
        />
        <div className="dropDown inputText">
          <span className="controlTitle">
            {CONTROLTITLE[this.props.language].designedFor}
          </span>
          <input
            id={3}
            className="inputField Text"
            value={this.props.presentationCurr.designedFor}
            onFocus={this.handleFocus}
            onClick={this.select}
            type="text"
            onChange={evt => this.updateInputValue(3, evt)}
          />
        </div>
        <div className="dropDown inputText">
          <span className="controlTitle">
            {CONTROLTITLE[this.props.language].designedBy}
          </span>
          <input
            id={4}
            className="inputField Text"
            onFocus={this.handleFocus}
            onClick={this.select}
            type="text"
            value={this.props.presentationCurr.designedBy}
            onChange={evt => this.updateInputValue(4, evt)}
          />
        </div>
        <div className="dropDown inputTextNotes">
          <span className="controlTitle">
            {CONTROLTITLE[this.props.language].notes}
          </span>
          <Info infoIcon={infoIcon}/> {/* id={infoIcon.infoID} msg={infoIcon.infoText} popupRight={true}/> */}
          <textarea
            id={5}
            className="inputField textarea"
            onFocus={this.handleFocus}
            onClick={this.select}
            type="text"
            value={this.props.presentationCurr.notes}
            onChange={evt => this.updateInputValue(5, evt)}
          />
        </div>

      </div>
    );
  }
}
