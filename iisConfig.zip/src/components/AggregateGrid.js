import React, { Component } from "react";
import {
    formatMoney,
    cleanFormat
} from "../utils/helper";
import {
    COLUMN_TITLES,
    TITLES,
    INCOMESOURCES
} from "../definitions/generalDefinitions";
import {
    getInfoExcelcapFund,
    getInfoExcelAllAfterTax
} from "../definitions/infoIconsDefinitions";
import { Info } from "./Info";
import { getAssetGridValues } from "../data/assetGridProjections";
import { getOutputValues, setUIDataToAPI } from "../data/dataExchange";
import DataTable from "./GridExcelComponent/DataTable";
import Loader from 'react-loader-spinner'
import _ from 'lodash';

export class AggregateGrid extends Component {
    constructor(props) {
        super(props);
        this.state = {
            loading: true,
      //      aggregateGrid: null,
        }
    }

/*     async componentDidMount() {
        console.log('STARTED MOUNTING')
        this.setState({ loading: true });
        const data = await this.getEPGridData();
        this.setState({
            aggregateGrid: data,
            loading: false,
        })
    }

    async componentWillReceiveProps(nextProps) {
         if (!_.isEqual(nextProps.input, this.props.input)) {
            this.setState({ loading: true });
            const data = await this.getEPGridData();
            this.setState({
                aggregateGrid: data,
                loading: false,
            })
        }
    }
 */
    // componentWillReceiveProps(nextProps) {
    //     // console.log(this.props.assetCurr.assetTypeKey,nextProps.assetCurr.assetTypeKey, this.props.assetCurr, nextProps.assetCurr);
    //     if (_.isEqual(nextProps.aggregateGrid, this.props.aggregateGrid)) {
    //       return false
    //       }
    //     }


   
    render() {
   /*      const lang = this.props.input.lang
        const { grids, loading } = this.state;

        if (loading) {// || this.state.aggregateGrid===null || this.state.aggregateGrid===undefined) {
            console.log('LOADING');
            return <Loader type="TailSpin" color="black" height={30} width={30} />;
        }
        console.log('FINISHED LOADING');
        // if (!(loading || this.state.aggregateGrid===null || this.state.aggregateGrid===undefined)) 
        //     console.log(this.state.aggregateGrid.gridColumnsDataMain)
 */
        return (
            <div>
                <DataTable
                    gridTitle={this.props.aggregateGrid.gridTitle}
                    gridColumnsHeaders={this.props.aggregateGrid.gridColumnsHeaders}
                    gridColumnsDataMain={this.props.aggregateGrid.gridColumnsDataMain}
                    gridColumnsDataExcelInfoSection={this.props.aggregateGrid.gridColumnsDataExcelInfoSection}
                    gridColumnAligns={this.props.aggregateGrid.gridColumnAligns}
                    gridIcons={this.props.aggregateGrid.gridIcons}
                    language={this.props.lang}
                />
            </div>);
    }
}

