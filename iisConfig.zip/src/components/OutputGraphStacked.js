import React, { Component } from "react";
import { Pie, Bar, Line, Chart } from "react-chartjs-2";
import "./Output.css";
import { cleanFormat } from "../utils/helper";
  

export class OutputGraphStacked extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    var optionsEstate = {
     /*  "hover": {
        "animationDuration": 0
      },
      "animation": {
        "duration": 1,
        "onComplete": function() {
          var chartInstance = this.chart,
            ctx = chartInstance.ctx;
  
          ctx.font = Chart.helpers.fontString(Chart.defaults.global.defaultFontSize, Chart.defaults.global.defaultFontStyle, Chart.defaults.global.defaultFontFamily);
          ctx.textAlign = 'center';
          ctx.textBaseline = 'bottom';
  
          this.data.datasets.forEach(function(dataset, i) {
            var meta = chartInstance.controller.getDatasetMeta(i);
            meta.data.forEach(function(bar, index) {
              var data = dataset.data[index];
              ctx.fillText(data, bar._model.x, bar._model.y - 5);
            });
          });
        }
      }, */
      elements: { point: { radius: 0 }},
      responsive: true,
      title: {
        display: true,
        position: "top",
        text: "Estate Value & Tax Liability",
        fontSize: 14,//8,
        fontColor: "#111"
      },
      legend: {
        display: true,
        position: "bottom",
        labels: {
          fontColor: "#333",
          fontSize: 12//16
        }
      },
      scales: {
        yAxes: [{
          stacked: true,
          ticks: {
            beginAtZero: true
          }
        }],
        xAxes: [{
          stacked: true,
          ticks: {
            beginAtZero: true
          }
        }]
  
      }
    };
     
    let dataAssetnEstateLiabProj=[]
    
    let type=['line','bar']      
    
    let col=[]
    

    for (let i = 0; i < this.props.dataAssetnEstateLiabProj.length; ++i) {
      col=[]
      for (let k = 0; k < this.props.dataAges.length; ++k) 
      {
        col.push(this.props.dataAssetnEstateLiabProj[i].colour)
      }
      col[this.props.LE+3]=shadeColor(this.props.dataAssetnEstateLiabProj[i].colour,-20)
      dataAssetnEstateLiabProj.push(
        {
          type: type[i<1?0:1],
          label: this.props.dataAssetnEstateLiabProj[i].name,
          data: this.props.dataAssetnEstateLiabProj[i].values,//!== undefined?this.props.dataRE:[],
          fill: i==0?false:true,
          borderColor: this.props.dataAssetnEstateLiabProj[i].colour,
          backgroundColor: col//this.props.dataAssetnEstateLiabProj[i].colour
        })

    }

    /* console.log(this.props.dataAssetnEstateLiabProj)
    let dataTaxLiabLifeExp = [];
    let totalAtLE=0
    for (let i = 0; i < this.props.dataAssetnEstateLiabProj.length; ++i) 
      totalAtLE=parseInt(totalAtLE)+parseInt(this.props.dataAssetnEstateLiabProj[i].values[42])
    for (let k = 0; k < this.props.dataAges.length; ++k) 
    {
      dataTaxLiabLifeExp.push(totalAtLE);
      col.push('red')
    }
    dataTaxLiabLifeExp[42] = totalAtLE
    col[42] = 'blue'
    
    dataAssetnEstateLiabProj.push(
      {
        type: 'bar',
        label:
        this.props.language === "en"
          ? "Life Expectancy "
          : "Life Expectancy ^F", //Income Shortfall',
      //type: "line",
      data: dataTaxLiabLifeExp,
      fill: true, // Don't fill area under the line
      borderColor: "#6AAd8b",
      backgroundColor: col//"rgb(106,173,139,.5)"// "rgba(96, 125, 139, .7)"
      }) */

      function shadeColor(color, percent) {

        var R = parseInt(color.substring(1,3),16);
        var G = parseInt(color.substring(3,5),16);
        var B = parseInt(color.substring(5,7),16);
    
        R = parseInt(R * (100 + percent) / 100);
        G = parseInt(G * (100 + percent) / 100);
        B = parseInt(B * (100 + percent) / 100);
    
        R = (R<255)?R:255;  
        G = (G<255)?G:255;  
        B = (B<255)?B:255;  
    
        var RR = ((R.toString(16).length==1)?"0"+R.toString(16):R.toString(16));
        var GG = ((G.toString(16).length==1)?"0"+G.toString(16):G.toString(16));
        var BB = ((B.toString(16).length==1)?"0"+B.toString(16):B.toString(16));
    
        return "#"+RR+GG+BB;
    }


    const dataEstate = {
        labels: this.props.dataAges, // this.dataAges,
        datasets: 
        dataAssetnEstateLiabProj
      };

    // console.log(dataEstate)
    return (
        
        <div style={{ width: "90%" }}>
               <div>
                <article className="canvas-container" style={{marginLeft: '25px',height: "450px" }}>
                    <div style={{overflow:'hidden', float: 'left', width: '100%',height: "400px" }}>
                        <Bar data={dataEstate} options={optionsEstate} /></div>
                </article>
          </div>
        </div>
    )
  }
}
