﻿import React, { Component } from "react";
import { DropDown } from "./DropDown";
import { AddRemove } from "./AddRemove";
import { cleanFormat, getListToShowByOrder } from "../utils/helper";
import { CONTROLTITLE, INCOMESOURCES, DEFAULT_DIVIDEND_TAX_RATE } from "../definitions/generalDefinitions";
//import { InputField4 } from './inputField4';
import { InputField } from "./inputField";
import { isMobileDevice, getListItemNameFromKey, getListItemKeyFromName} from "../utils/helper";
import {
  DROPDOWN_WIDE
} from "../definitions/generalDefinitions";
import {
  getInfoIconSourcesGov,
  
} from "../definitions/infoIconsDefinitions";


export class Source extends Component {
  displayName = Source.name;

  constructor(props) {
    super(props);
    let i;
    let typeValues = []; 
    const listSourcesToShow = getListToShowByOrder(INCOMESOURCES);
    for (i = 0; i < listSourcesToShow.length; ++i) {
      {
        typeValues.push({
          label: listSourcesToShow[i].value[this.props.language],
          value: i + 1
        });
      }
    }
    
      
/* 
    for (i = 0; i <= 5; ++i) {
      typeValues.push({
        label: INCOMESOURCES[this.props.language].Values[i],
        value: i + 1
      });
    }
 */
    // console.log(this.props.sourceCurr)
    this.state = {};
    this.dataValues = {
      DD: [
        {
          id: 1,
          Title: CONTROLTITLE[this.props.language].type,
          defValue:getListItemNameFromKey( INCOMESOURCES,this.props.sourceCurr.sourceTypeKey,this.props.language),
          Values: typeValues

        }
      ]
    };
  }

  componentWillReceiveProps(nextProps) {
    if (nextProps.sourceCurr !== this.props.sourceCurr
      || nextProps.id !== this.props.id
        || nextProps.sourcesNo !== this.props.sourcesNo
      ) {
      // console.log(nextProps.sourceCurr.sourceTypeKey)
      this.dataValues.DD[0].defValue = getListItemNameFromKey(INCOMESOURCES,nextProps.sourceCurr.sourceTypeKey,this.props.language);
    }
  }

  handleDoRemove = id => {
    this.props.handleRemoveSource(id);
  };

  isSourceGovNonOrphanBenefit= key =>
  {
    if(key === INCOMESOURCES.GOV_SURVIVORS_PENSION.Key ||
    key ===INCOMESOURCES.GOV_DEATH_BENEFIT.Key)
      return true;
    else
      return false;
  }

  isDividendIncome= key =>
  {
    if(key === INCOMESOURCES.DIVIDEND_INCOME.Key)
      return true;
    else
      return false;
  }
  isSourceGovOrphansBenefit= key =>
  {
    if(key === INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key)
      return true;
    else
      return false;
  }

  handleDoAdd = () => {
    // no gov stuff
    
    var sourceNo =
      this.props.sourcesNo > this.dataValues.DD[0].Values.length - 1
        ? this.dataValues.DD[0].Values.length - 1
        : this.props.sourcesNo;
    //if(this.props.includeGovOrphanBenefit===false)
    //  sourceNo +=1;
    if(sourceNo > this.dataValues.DD[0].Values.length-1)
      sourceNo -=1;
    

    let sourceNextKey = (getListItemKeyFromName(INCOMESOURCES,this.dataValues.DD[0].Values[sourceNo].label));
    
    // dont add gov stuff unless has child && orphanben
    while (sourceNextKey===INCOMESOURCES.GOV_DEATH_BENEFIT.Key || sourceNextKey===INCOMESOURCES.GOV_SURVIVORS_PENSION.Key || ( sourceNextKey===INCOMESOURCES.GOV_ORPHANS_BENEFIT.Key && this.props.includeGovOrphanBenefit===false))
    {
      sourceNo +=1;
      sourceNextKey = (getListItemKeyFromName(INCOMESOURCES,this.dataValues.DD[0].Values[sourceNo].label));
    }  
    
    // dont repeat
    while (sourceNextKey===this.props.sourceCurr.sourceTypeKey && this.props.sourceCurr.sourceTypeKey!== INCOMESOURCES.OTHER.Key)
    {
      sourceNo +=1;
      sourceNextKey = (getListItemKeyFromName(INCOMESOURCES,this.dataValues.DD[0].Values[sourceNo].label));
    }  
    

    const source={
      id: this.props.sourcesNo,
        sourceTypeKey:sourceNextKey,
        amount: 0,
        startYear: 0,
        // set others based on INA other values tax infl        
    }
    if(sourceNextKey ===INCOMESOURCES.DIVIDEND_INCOME.Key)
      source.taxRate = DEFAULT_DIVIDEND_TAX_RATE
    // console.log(source)
    this.props.handleAddSource(source);
  };

  updateDDown = (id, selection) => {
    let source = {
      id: this.props.sourceCurr.id,
      //Type: this.props.Type,
      sourceTypeKey: this.props.sourceCurr.sourceTypeKey,
      amount: this.props.sourceCurr.amount,
      startYear: this.props.sourceCurr.startYear,
      duration: this.props.sourceCurr.duration,
      taxRate:this.props.sourceCurr.taxRate,
      annualGrowth:this.props.sourceCurr.annualGrowth
    };

    if (id === 1) source.sourceTypeKey =  getListItemKeyFromName(INCOMESOURCES, selection);
    else if (id === 2) source.ownerID =  selection;
    this.props.handleUpdate(source);
  };

  handleUpdateInput = (id, value) => {
    let source = {
      id: this.props.sourceCurr.id,
      //Type: this.props.Type,
      sourceTypeKey: this.props.sourceCurr.sourceTypeKey,
      amount: this.props.sourceCurr.amount,
      startYear: this.props.sourceCurr.startYear,
      duration: this.props.sourceCurr.duration,
      ownerID: this.props.sourceCurr.ownerID,
      taxRate:this.props.sourceCurr.taxRate,
      annualGrowth:this.props.sourceCurr.annualGrowth
    };

    let changed = false;
    if (id === 1) {
      changed = source.amount !== parseInt(cleanFormat(value)) ? true : false;
      source.amount = parseInt(cleanFormat(value));
    } else if (id === 2) {
      changed = source.startYear !== value ? true : false;
      source.startYear = value;
    } else if (id === 3) {
      changed = source.duration !== value ? true : false;
      source.duration = value;
    } else if (id === 4) {
      changed =
      source.taxRate !==
        parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
          source.taxRate =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    } else if (id === 5) {
      changed =
      source.annualGrowth !==
        parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
          source.annualGrowth =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    
    }

    if (changed) this.props.handleUpdate(source);
  };

  render() {
    const gov =this.isSourceGovNonOrphanBenefit(this.props.sourceCurr.sourceTypeKey)
    const govOrphan = this.isSourceGovOrphansBenefit(this.props.sourceCurr.sourceTypeKey);
    const dividend=this.isDividendIncome(this.props.sourceCurr.sourceTypeKey);
    const RRIF=this.props.sourceCurr.sourceTypeKey===INCOMESOURCES.RRIF.Key
    // console.log(this.props.sourceCurr,govOrphan,this.props.sourceCurr.maxOrphan)

    let unlistedGreyedOption;
    if(RRIF)
    {
      unlistedGreyedOption = [];
      unlistedGreyedOption.push({
        	label: INCOMESOURCES.RRIF.value[this.props.language],
        	value: 1
      		});
    }

    return (
      <div
        className="inputRow"
       >
        {this.dataValues.DD.map(dd => (
          <DropDown
            key={dd.id}
            id={dd.id}
            Count={this.props.sourcesNo}
            Title={dd.Title}
           // infoIcon={gov && !govOrphan ? getInfoIconSourcesGov(this.props.language): undefined}
            width={DROPDOWN_WIDE}
            language={this.props.language}
            defValue={dd.defValue}
            Values={dd.Values}
            unlistedGreyedOption={unlistedGreyedOption}
            updateDDown={this.updateDDown}
          />
        ))}
        { !RRIF &&
        <InputField
          format={2}
          id={1}
          inputName={CONTROLTITLE[this.props.language].amount}
          readOnly={gov}
          Count={this.props.sourcesNo}
          language={this.props.language}
          infoIcon={gov && !govOrphan ? getInfoIconSourcesGov(this.props.language): undefined}
          maxValue={govOrphan?this.props.sourceCurr.maxOrphan:undefined}
          inputValue={this.props.sourceCurr.amount}
          inputTitle={this.props.sourceCurr.id}
          handleUpdateInput={this.handleUpdateInput}
        />}
       
        

        {gov || govOrphan ? (
          ""
        ) : (
          <InputField
            format={1}
            id={2}
            inputName={RRIF? CONTROLTITLE[this.props.language].RRIFAge:CONTROLTITLE[this.props.language].startYear}
            Count={this.props.sourcesNo}
            language={this.props.language}
            inputValue={this.props.sourceCurr.startYear}
            //infoIcon={RRIF ? getInfoIconSourcesRRIF(this.props.language): undefined}
            readOnly={RRIF}
            inputTitle={this.props.sourceCurr.id}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {gov || RRIF ? (
          ""
        ) : (
          <InputField
            format={1}
            id={3}
            inputName={CONTROLTITLE[this.props.language].dur}
            Count={this.props.sourcesNo}
            language={this.props.language}
            inputValue={this.props.sourceCurr.duration}
            maxValue={govOrphan?this.props.sourceCurr.maxOrphanDur:undefined}
            inputTitle={this.props.sourceCurr.id}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}

        {dividend && (
          <InputField
            id={4}
            inputName={CONTROLTITLE[this.props.language].dividendTaxRate}
            format={3}
            Count={this.props.sourcesNo}
            language={this.props.language}
         //   infoIcon={getInfoIconDividend(this.props.language)}
            inputValue={this.props.sourceCurr.taxRate}
            inputTitle={this.props.sourceCurr.id}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}

        <AddRemove
          currentID={this.props.sourceCurr.id}
          numberComps={this.props.sourcesNo}
          handleDoAdd={this.handleDoAdd}
          handleDoRemove={this.handleDoRemove}
        />
        {/* {isMobileDevice() && this.props.sourceCurr.id < this.props.sourcesNo ? (
          <hr className="ppi2" />
        ) : (
          ""
        )} */}
      </div>
    );
  }
}
