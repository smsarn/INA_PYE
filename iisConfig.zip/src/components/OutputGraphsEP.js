import React, { Component } from "react";
import { Bar, Line, Chart,Pie } from "react-chartjs-2";
//import "./Output.css";
import "./Output.css";
import { readMCCData } from "../data/dataExchangeMCC";
import { fetchMCCData } from "../utils/FetchAPIs";
import { setUIDataToAPI} from "../data/dataExchange";
import {
  getProjectedLiabilities,
  cleanFormat,
  numFormat,
  getAssetsTaxCategoryTotal,
  getAssetsCategoryTotal,
  getTaxLiabCategoryTotal,
  getLiabsCategoryTotal
} from "../utils/helper";
import {
  GROWTHDIR,
  QUOTE_CLIENT,
  QUOTE_SPOUSE,
  QUOTE_JOINT,
  ASSET_TAX,
  ASSETS,
  LIABILITIES

} from "../definitions/generalDefinitions";
import MCCGraph from "./MCCGraph";
import { MultiButtons } from "./MultiButtons";
import { InputField } from "./inputField";
import DataTable from "./GridExcelComponent/DataTable";

// props option
const DISPLAY_INCOME = 1;

// for Estate
const DISPLAY_TAXLIAB_CLIENT = 1;
const DISPLAY_TAXLIAB_JLTD = 2;



export class OutputGraphsEP extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
        loadingMCC: true,
        estateLiab: [],
        estateLiabLE: [],
        taxL:0
      };
      this.dataAges = [];
      this.dataPremiums = [];
      this.dataDB = [];
      this.dataSVEquiBuild = [];
      this.dataSVManulife = [];
      this.Prem = 0;
      this.bestPremiumDur = 100;
      this.bestMinMultiple = 0;
      this.premiumDur = 10;
      this.lifeExp = 0;
      this.minMultiple = 0;
      this.insMultiple = 0;
      this.bestFitEquiBuild = false;
      this.INAEstateOption = DISPLAY_TAXLIAB_CLIENT;
      
        this.chartRef = React.createRef();
        this.taxLiabChartRef = React.createRef();
        console.log(this.props.input.dataInput)
    }  
    componentDidMount() {
        this.getEstateLiabPieCharts()
     
    }
  
    getDataFutureINA = () => {
    let dataFutureINA = [];
    let i;
    let j;
    var pv;
    var totalLiab = 0;
    var totalLiabProjections = [];
    // project liabs

    totalLiabProjections = getProjectedLiabilities(
      this.props.input.dataInput,
      this.props.projectEnd,
      this.props.language
    );

  
    const currINA = parseFloat(cleanFormat(this.props.insuranceNeed));
    const intRate = parseFloat(
      this.props.input.dataInput.Presentations[0].invRate / 100
    );
    const inflation = parseFloat(
      this.props.input.dataInput.Presentations[0].inflation / 100
    );
    dataFutureINA.push(currINA);
    console.log(this.props)
    for (i = 1; i < this.props.projectEnd; ++i) {
      pv =
        (dataFutureINA[i - 1] - this.props.dataShortfall[i - 1]) *
        (1 + intRate);
      //   console.log(pv)
      dataFutureINA.push(Math.round(Math.max(0, pv)));
    }
    // add liab
    for (i = 1; i < this.props.projectEnd; ++i) {
      dataFutureINA[i] += totalLiabProjections[i];
    }
    return dataFutureINA;
  };

  getEstateLiabPieCharts= async () => {
     
    const totalLiabProjections = getProjectedLiabilities(
      this.props.input.dataInput,
      this.props.projectEnd,
      this.props.language
    );



    // console.log(this.state.estateLiab,this.state.estateLiabLE)

    let dataNA = setUIDataToAPI(this.props.input);

    let estateLiab2=[]
    estateLiab2.push(totalLiabProjections[0])
    const l1= await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.REGISTERED.Key,dataNA, 0);
    this.setState({taxL: l1})
    estateLiab2.push(l1)
    const l2=await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.CAPITAL_GAINS_ANNUAL.Key,dataNA, 0)
    const l3=await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.CAPITAL_GAINS_DEFERRED.Key,dataNA, 0)
    estateLiab2.push(l2+l3)
    estateLiab2.push(await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.FULLY_TAXABLE.Key,dataNA, 0))
    estateLiab2.push(await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.DIVIDEND.Key,dataNA, 0));


    this.setState({estateLiab: estateLiab2});

    let estateLiab3=[]
    estateLiab3.push(totalLiabProjections[this.props.lifeExp])
    estateLiab3.push(await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.REGISTERED.Key,dataNA, this.props.lifeExp))
    const l2LE=await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.CAPITAL_GAINS_ANNUAL.Key,dataNA, this.props.lifeExp)
    const l3LE=await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.CAPITAL_GAINS_DEFERRED.Key,dataNA, this.props.lifeExp)
    estateLiab3.push(l2LE+l3LE)
    estateLiab3.push(await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.FULLY_TAXABLE.Key,dataNA, this.props.lifeExp))
    estateLiab3.push(await getTaxLiabCategoryTotal(this.props.input.dataInput,ASSET_TAX.DIVIDEND.Key,dataNA, this.props.lifeExp));
    this.setState({estateLiabLE: estateLiab3});

    // console.log(this.state.estateLiab,this.state.estateLiabLE)
 console.log(estateLiab2,estateLiab3,this.props.lifeExp)
}






  render() {

    let dtaAgesAll = [];
    let k;
    let lifeExp = this.props.lifeExp;
    const clients=this.props.input.dataInput.Clients
    let age=clients.length>1?Math.min(clients[QUOTE_SPOUSE].Age,clients[QUOTE_CLIENT].Age):clients[QUOTE_CLIENT].Age
    
    //let age = this.props.input.dataInput.Clients[1].Age;

    if (this.INAEstateOption === DISPLAY_TAXLIAB_CLIENT) {
      lifeExp = this.props.lifeExpClient;
      age = this.props.input.dataInput.Clients[QUOTE_CLIENT].Age;
    } else if (this.INAEstateOption === DISPLAY_TAXLIAB_JLTD) {
      lifeExp = this.props.lifeExpJLTD;
      age=clients.length>1?Math.min(clients[QUOTE_SPOUSE].Age,clients[QUOTE_CLIENT].Age):clients[QUOTE_CLIENT].Age
      
    }

    for (k = 0; k < lifeExp + 3; ++k) {
      dtaAgesAll.push(age + k);
    }

    //if (this.props.INAOption !== DISPLAY_INCOME) {
    var dataFutureINA = this.getDataFutureINA();
    const dataShortfallFV = {
      labels: dtaAgesAll, // this.dataAges,
      datasets: [
        {
          label:
            this.props.language === "en"
              ? "Future insurance needs"
              : "Future insurance needs ^F", //Income Shortfall',
          data: dataFutureINA,

          fill: true, // Don't fill area under the line
          borderColor: "darkred", // Line color
          backgroundColor: "rgba(244, 144, 128, 0.8)"
        }
      ]
    };
    //} else {
    let dataTaxLiabLifeExp = [];
    let dataTaxLiab = []; // this.props.dataEstateLiability;

    for (k = 0; k < lifeExp + 3; ++k) {
      dataTaxLiabLifeExp.push(0);
      dataTaxLiab.push(this.props.dataEstateLiability[k]);
    }
    dataTaxLiabLifeExp[lifeExp] = dataTaxLiab[lifeExp];
    dataTaxLiab[lifeExp] = 0;

    // console.log(this.INAEstateOption, age, dtaAgesAll, lifeExp);
    const dataTaxLiability = {
      labels: dtaAgesAll,
      datasets: [
        {
          label:
            this.props.language === "en"
              ? "Future insurance Needs"
              : "Future insurance Needs ^F", //Income Shortfall',
          //type: "line",
          data: dataTaxLiab,

          fill: true, // Don't fill area under the line
          borderColor: "darkGrey", // Line color
          backgroundColor: "#607d8b"
        },
        {
          label:
            this.props.language === "en"
              ? "Life Expectancy "
              : "Life Expectancy ^F", //Income Shortfall',
          //type: "line",
          data: dataTaxLiabLifeExp,
          fill: true, // Don't fill area under the line
          borderColor: "#6AAd8b",
          backgroundColor: "rgb(106,173,139,.5)"// "rgba(96, 125, 139, .7)"
        }
      ]
    };

    const optionsFV = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
          xAxes: [
            {
              stacked: true,
              ticks: {
                beginAtZero: true
              }
            }
          ],
          yAxes: [
            {
              stacked: false,
              ticks: {
                beginAtZero: true,
                steps: 10,
                stepValue: 5
              }
            }
          ]
        }
      };

  const dataPieAssets = {
  labels: [
    "Cash/TFSA/Insurance", "RRSP/RRIF", "Public/Private shares", "Real Estate", "Other"
  ],
  datasets: [
    {
         data: [
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.CASH.Key)+
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.LIFE_INSURANCE.Key)+
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key)
        , 
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.RRSP_RRIF.Key), 
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.SMALL_BUSINESS_SHARES.Key)+
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.STOCKS_BONDS.Key),
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.REAL_ESTATE.Key)+
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.PERSONAL_RESIDENCE.Key),
        getAssetsCategoryTotal(this.props.input.dataInput,ASSETS.OTHER_ASSETS.Key)
      ],
      backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"]
    }
  ]
}
const dataPieTax = {
  labels: [
    "Non-Taxable", "RRSP/RRIF", "Capital Gains", "Taxed As Income", "Dividend"
  ],
  datasets: [
    {
         data: [
        getAssetsTaxCategoryTotal(this.props.input.dataInput,ASSET_TAX.NON_TAXABLE.Key), 
        getAssetsTaxCategoryTotal(this.props.input.dataInput,ASSET_TAX.REGISTERED.Key), 
        getAssetsTaxCategoryTotal(this.props.input.dataInput,ASSET_TAX.CAPITAL_GAINS_ANNUAL.Key)+
        getAssetsTaxCategoryTotal(this.props.input.dataInput,ASSET_TAX.CAPITAL_GAINS_DEFERRED.Key),
        getAssetsTaxCategoryTotal(this.props.input.dataInput,ASSET_TAX.FULLY_TAXABLE.Key), 
        getAssetsTaxCategoryTotal(this.props.input.dataInput,ASSET_TAX.DIVIDEND.Key)
      ],
      backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"]
    }
  ]
}

const dataPieLiabs = {
  labels: [
    "Loans", "Taxes", "Emergency Fund", "Other"
  ],
  datasets: [
    {
         data: [
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.OUTSTANDING_LOANS.Key)+
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.MORTGAGE_REDEMPTION.Key)+
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.CREDIT_CARDS.Key)+
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.CLIENT_TAX_LIABILITY.Key)
        , 
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.INCOME_TAXES.Key), 
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.EMERGENCY_FUND.Key),
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.OTHER.Key)+
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.CHILD_HOME_CARE.Key)
      ],
      backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1"]
    }
  ]
}
const dataPieLiabsAtDeath = {
  labels: [
    "Last Expenses", "Legal and Executor Fees", "Future Commitments"
  ],
  datasets: [
    {
         data: [
           getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.LAST_EXPENSES.Key),
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.LEGAL_AND_EXECUTOR_FEES.Key), 
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.LEGACY_FOR_CHILDREN.Key)+
        getLiabsCategoryTotal(this.props.input.dataInput,LIABILITIES.CHARITABLE_GIFTS.Key)
      ],
      backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C"]
    }
  ]
}

//options
  var optionsPie = {
    responsive: true,
    title: {
      display: true,
      position: "top",
      text: "Assets Breakdown Today",
      fontSize: 14,//8,
      fontColor: "#111"
    },
    legend: {
      display: true,
      position: "right",
      labels: {
        fontColor: "#333",
        fontSize: 12//16
      }
    }
  };
   
   
   let optionsPieTax = JSON.parse(JSON.stringify(optionsPie));
   optionsPieTax.title.text="Tax Treatment of Assets"

let optionsPieLiabsAtDeath = JSON.parse(JSON.stringify(optionsPie));
   optionsPieLiabsAtDeath.title.text="Liabilities At Death"

let optionsPieLiabs = JSON.parse(JSON.stringify(optionsPie));
   optionsPieLiabs.title.text="Liabilities Breakdown"




const dataPieEstateLiabNow = {
  labels: [
    "Liabilities", "Taxes: RRSP/RRIF", "Taxes: Capital Gains", "Taxes: As Income", "Taxes: Dividend"
  ],
  datasets: [
    {
         data: this.state.estateLiab,
      backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"]
    }
  ]
}
const dataPieEstateLiabLE = {
  labels: [
    "Liabilities", "Taxes: RRSP/RRIF", "Taxes: Capital Gains", "Taxes: As Income", "Taxes: Dividend"
  ],
  datasets: [
    {
         data: this.state.estateLiabLE,
      backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"]
    }
  ]
}
 let optionsPieEstateLiab= JSON.parse(JSON.stringify(optionsPie));
   optionsPieEstateLiab.title.text="Estate Liability Today"

let optionsPieEstateLiabLE= JSON.parse(JSON.stringify(optionsPie));
   optionsPieEstateLiabLE.title.text="Estate Liability at Life Expectancy +3"
    // FV of prems
  
    //let colHeaders=["Year", "Survivor's Age", "Insurance Need", "Propsed Plan Death Benefit", "Future Value of Premiums", "Net Advantage of Insurance" ];
    
    let needToE =
      "Insurance Needs Projections from today to life expectancy plus 3 years (" +
      lifeExp +
      " + 3)";
    let needToF =
      "Insurance Needs to life expectancy (" +
      lifeExp +
      " years) plus 3 years^F";
    let needTo = this.props.language === "en" ? needToE : needToF;
    // needTo += +this.props.projectEnd + ")";

    //console.log(this.state.loadingMCC);
    return (
      <div style={{ color: "darkBlue", marginTop: "15px" }}>
        {this.props.INAOption !== DISPLAY_INCOME && (
          <MultiButtons
            noButtons={2}
            buttonCaption={["Estate of Client", "Estate of Couple"]}
            selectMultiButton={this.selectMultiButtonINAorTax}
          />
        )}
        
        <div style={{ width: "90%" }}>
        <div style={{ width: "100%" }}> 
        
           <h3 className="ppi1">
          <div><br/><br/>Estate Liability breakdown Today and at Life Expectancy plus 3 years: <br/></div>
          
        </h3>

 
          <div style={{ width: "100%" }}>
            <article className="canvas-container" style={{height: "450px" }}>
                <div style={{overflow:'hidden', float: 'left', width: '50%',height: "400px" }}><Pie data={dataPieEstateLiabNow} options={optionsPieEstateLiab} /></div >
                <div style={{float: 'left',width: '50%',height: "400px"}}><Pie data={dataPieEstateLiabLE} options={optionsPieEstateLiabLE} /></div>
              </article>)
          
              <article className="canvas-container" style={{ height: "200px" }}>
                <Bar data={dataTaxLiability} options={optionsFV} />
              </article>
          </div>
          

<br/>
           <h3 className="ppi1">
          {true
            ? <div>Net Worth Today:<br/> Assets:<br/> Liabilities: ^F</div> //this.props.insuranceNeed
            : <br/>
            }
          {/*numFormat(this.props.dataTaxLiability[0], false, 2, ",")}*/}
        </h3>


            <hr />
          </div>
        </div>
      </div>
    );
  }
}
