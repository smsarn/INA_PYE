import React from "react";
import MUIDataTable from "mui-datatables";
import {
  Typography,
  TableRow,
  TableCell,
  Card,
  CardContent
} from "@material-ui/core";
import { createMuiTheme, MuiThemeProvider } from "@material-ui/core/styles";
import {GRID_INTERNAL_CAPTIONS} from '../../definitions/generalDefinitions';
//import DownloadExcel from './DownloadExcel'
import DownloadExcel from "./DownloadExcel";
import ExcelToolbar from "./ExcelToolbar";
//import PrintToolbar from "./printToolbar";
import {
  getInfoIconNotes
} from "../../definitions/infoIconsDefinitions.js";
import { Info } from "../Info";


export default class Datatable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      downloadExcelNow: 0
    };
  }
/* 
formatMoney=(
    amount,
    decimalCount
   ) => {
    try {
      const decimal = this.props.language==="fr"?",":"."
      const thousands = this.props.language==="fr"?" ":","
      amount=cleanFormat(amount,this.props.language==="fr"? true:false)
      decimalCount = Math.abs(decimalCount);
      decimalCount = isNaN(decimalCount) ? 2 : decimalCount;
  
      const negativeSign = amount < 0 ? "-" : "";
      console.log(amount,Number(amount))
      let i = parseFloat(
        (amount = Math.abs(Number(amount) || 0).toFixed(decimalCount))
      ).toString();
      console.log(i)
      let j = i.length > 3 ? i.length % 3 : 0;
      return (
        negativeSign +
        (j ? i.substr(0, j) + thousands : "") +
        i.substr(j).replace(/(\d{3})(?=\d)/g, "$1" + thousands) +
        (decimalCount
          ? decimal +
            Math.abs(amount - i)
              .toFixed(decimalCount)
              .slice(2)
          : "")

          
      );
    } catch (e) {
      //	console.log(e);
    }
  }
  

 */


  getMuiTheme = () =>
    createMuiTheme({
      typography: {
        fontFamily: '"Trebuchet MS"',
        fontSize: 11,
        fontWeight: "100"
      },
      overrides: {
        MUIDataTable: {
          tableRoot: {
            margin: 0
          },
          paper: {
            boxShadow: "none"
          }
        },
        MuiTableCell: {
          head: {
            fontSize: ".8rem"
          },
          
          sizeSmall: {
            padding: "8px 3px 8px 3px"
          }

        },
        MUIDataTableToolbar: {
          root: {
            paddingLeft: "0px"
          },
          titleRoot: {
            fontSize: 24,
            fontWeight: 'bold'
          },
          icon: {
            fontSize: 24
          }
        },
        MUIDataTableBodyCell: {
          root: {
            backgroundColor: "#FF0000"
           }
        },
        MUITypography: {
          root: {
            backgroundColor: "blue"
           },
           
            body2: {
              color: 'blue',
            },
        },
        MUITablePagination: {
          caption: {
              value: 'blue',
            },
        }
      }
    });

  setExcel = () => {
    let downloadNow = this.state.downloadExcelNow === 1 ? 0 : 1;
    this.setState({ downloadExcelNow: downloadNow });
  };

  render() {
    let data = [];
    let dataRow = [];
    let j;
    let i;

    /* const mq = window.matchMedia( "(min-width: 500px)" );
    let unit=(window.innerWidth)/15;//(Math.max(15,1.5*this.props.gridColumnsHeaders.length))
    console.log(window.innerWidth,unit,(unit/window.innerWidth)*100*(2+this.props.gridColumnsHeaders.length))
    //let divStyle={ width: (unit/window.innerWidth)*100*(Math.max(4,1.5*this.props.gridColumnsHeaders.length)) +"%" }  
    let divStyle={ width: (unit/window.innerWidth)*100*(this.props.gridColumnsHeaders.length) +"%" }   
    if(unit<60)
    {
      unit=60 
      divStyle={ width: "100%" } 
    } 
    if(unit<60)
    {
      unit=60 
      divStyle={ width: "100%" } 
    } 
    alert((unit/window.innerWidth)*100*(this.props.gridColumnsHeaders.length))
    if (mq.matches)
      alert(window.innerWidth)
    else
    alert('window.innerWidth')
 */
    let unit=90
    let divStyle={ width: 1.1*unit*(this.props.gridColumnsHeaders.length) }   
    // console.log(window.innerWidth)
    // console.log(1.1*unit*this.props.gridColumnsHeaders.length)
    if(1.1*unit*this.props.gridColumnsHeaders.length>(1/1.1)* window.innerWidth)
    {
      unit=((1/1.1)*window.innerWidth/(1.1*this.props.gridColumnsHeaders.length))
      divStyle={ width: 1.1*unit*(this.props.gridColumnsHeaders.length) }   
    
    }
    if(unit<60)
    {
      unit=60 
      divStyle={ width: "100%" } 
    } 
    
    // console.log(unit)
    // console.log(1.1*unit*this.props.gridColumnsHeaders.length)
  
    

    /* let styleHeader = {
      backgroundColor: "#1f497D",
      color: "#FFFFFF",
      textAlign: "right",
      width: 60
    }; */
    let columns = [];

    if (this.props.gridColumnsDataMain !== undefined) {
    //  console.log(this.props.gridColumnsDataMain);
     // console.log(this.props.gridColumnsDataMain[3][1]);

      for (i = 0; i < this.props.gridColumnsDataMain[0].length; ++i) {
        for (j = 0; j < this.props.gridColumnsHeaders.length; ++j) {
          if(j<1)
          dataRow.push(this.props.gridColumnsDataMain[j][i]);
          else
          dataRow.push(this.props.gridColumnsDataMain[j][i]);
        }
        data.push(dataRow);
        dataRow = [];
      }

      // build and style header and columns
      let widthCustom =unit;// Math.max(80,6 * this.props.gridColumnsHeaders.length); //+'%';
      let styleHeader = {
        backgroundColor: "#334d7c",
        color: "#FFFFFF",
        textAlign: "center",
        width: widthCustom,
        fontWeight: "bold"
      };

      let customHeader = ({ index, ...column }) => {
        return (
          
          <TableCell key={index} style={styleHeader}>
            {this.props.gridIcons !== undefined && 
            this.props.gridIcons[index] !== undefined && <div><Info infoIcon={this.props.gridIcons[index]}/><br/></div>} 
          {/* {index===this.props.headerIndex && <div><Info infoIcon={getInfoIconNotes(this.props.language)}/><br/></div>}  */}
           {column.name}
           </TableCell>
        );
      };

      for (i = 0; i < this.props.gridColumnsHeaders.length; ++i) {
        columns.push({
          name: this.props.gridColumnsHeaders[i],
          options: {
            filter: false,
            customHeadRender: customHeader
          }
        });
      }
    }
    const captions= GRID_INTERNAL_CAPTIONS[this.props.language]
    const title=<span style={{fontSize: '14px'}}  >{captions.excel}</span>
            
              
    const excelToolbarText=captions.excel 
   // const printToolbarText=this.props.language==="en"? "Print" : "Print ^F" 
    const options = {
      filter: false,
      filterType: "dropdown",
      selectableRows: "none",
      responsive: "scrollMaxHeight", //this removes horiz
      resizableColumns: true,
      selectableRowsHeader: false,
      viewColumns: false,
      search: false,
      download: false,
      print:false,
      textLabels:{
        pagination: {
          rowsPerPage: captions.rows,
          displayRows: captions.of
        },
        /* toolbar:{
          print: {title},//this.props.language==="en"? "Print" : "Print ^F" ,
          downloadCsv: {title},
  
        } */
      },
      
      rowsPerPage: 100,
      setTableProps: () => {
        return {
          padding: "default",
          size: "small",
          margin: "0px"
        };
      },
      downloadOptions: {
        filename: "INAtableDownload.csv",
        separator: ","
      },
      onDownload: (buildHead, buildBody, columns, data) => {
        //handleCSVDownload2(data, columns);
        this.setExcel();
        //return "\uFEFF" + "dfof\n " + "go to hell\n" + buildHead(headerNames) + buildBody(data);
        return false;
      },
      customRowRender: (data, dataIndex, rowIndex) => {
        let style = {textAlign: "right"};
        if (data[0] === "wwwwwww") {
          style.backgroundColor = "green";
          style.fontSize = "36px";
        }
        var rows = [];

        let i;
        for (i = 0; i < this.props.gridColumnsHeaders.length; ++i) {
          let dataI = data[i];
          rows.push(
            <TableCell key={i} style={style}>
              <Typography>{
 /* this.formatMoney(
  dataI,
    this.props.gridColumnAligns[i],
    ".",
    ","
  ) } */dataI}</Typography>
            </TableCell>
          );
        }
        // console.log(rows)
        return (
          <TableRow key={rowIndex} style={{ backgroundColor: rowIndex%2?"#f9f9f9":"#e4e5e6"}}>
            {rows}
          </TableRow>
        );
      },
      customToolbar: () => <ExcelToolbar excelToolbarText={excelToolbarText} setExcel={this.setExcel} />
    };

   

    return (
        <div style={divStyle}>
          
        <MuiThemeProvider theme={this.getMuiTheme()}>
          <MUIDataTable
            title={this.props.gridTitle}
            data={data}
            columns={columns}
            options={options}
          />
        </MuiThemeProvider>
        <DownloadExcel
          excelColumnsDataMain={this.props.gridColumnsDataMain}
          width={"90"}
          excelColumnsHeaders={this.props.gridColumnsHeaders}
          title={this.props.gridTitle}
          excelColumnsDataInfoSection={this.props.gridColumnsDataExcelInfoSection}
          downloadNow={this.state.downloadExcelNow}
          hideElement={true}
        />
      </div>
    );
  }
}
