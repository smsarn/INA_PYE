﻿import React from 'react';
import { OUTPUTTITLE, TITLES, MEMBER,
	MAX_ORPHAN_DUR_QC,
	MAX_ORPHAN_DUR_NON_QC,
	ORPHAN_AGE_QC,
	ORPHAN_AGE_NON_QC,
	PROVINCE
} from '../definitions/generalDefinitions';
import { OUTPUTTEXT } from '../definitions/outputDefinitions';
import { getListItemNameFromKey, formatMoney,getListItemKeyFromName,cleanFormat } from '../utils/helper';
import { getOutputValues } from "../data/dataExchange";

import {
	PDF,

	InToPt,
	PxToPt,

	HELVETICA,
	TIMES,

	NORMAL,
	BOLD,
	ITALIC

} from "./PDF";

const DISPLAY_INCOME = 1;
const DISPLAY_TAXLIAB = 2;

const LINE_CHART_DIV_ID = "bar1";
const LINE_CHART_DIV2_ID = "lineChartDiv2";

const LINE_CHART_DIV_STYLE = {
	marginTop: "65px",
	marginLeft: "64px",
	marginBottom: "64px",
	height: "192px",
	width: "384px",
};

const LINE_CHART_DIV2_STYLE = {
	marginTop: "65px",
	marginLeft: "64px",
	marginBottom: "64px",
	height: "192px",
	width: "384px",
};

export function doSavePdfAction(props) {
	let pdf = new PDF();
	pdf.Create();

	// pdf.ShowGrids = false;

	var htmlElement;
	var paragraph;

	// pdf output shared with presentation
	let output = getOutputValues(props)
	const provinceKey=getListItemKeyFromName(PROVINCE, output.province);
    let maxDur=provinceKey ==="QC"?MAX_ORPHAN_DUR_QC:MAX_ORPHAN_DUR_NON_QC
    let orphAge=provinceKey ==="QC"?ORPHAN_AGE_QC :ORPHAN_AGE_NON_QC;
	
	const lang = props.input.lang
	const decimalChar=lang==="en"?".":","
    const thousands=lang==="en"?",":" "
	const formatFr=lang==="fr"? true:false
   
	// are there two need periods eg when children this or that
	const twoNeedPercents = output.percent2 > 0 ? true : false
	// Page 1
	pdf.SetFont(HELVETICA, NORMAL);
	if (lang === "en")
		pdf.SetFontSize(PxToPt(36));
	else
		pdf.SetFontSize(PxToPt(24));
	pdf.SetTextColor(0x45, 0x55, 0x60);
	pdf.Text(props.INAOption === DISPLAY_INCOME ? TITLES[lang].appletINA : TITLES[lang].appletEP, InToPt(1.5), InToPt(3.5));


	pdf.AddImage(
		"INAPage1",
		InToPt(1.51),
		InToPt(4.06),
		InToPt(6.04),
		InToPt(2.76),
	);
	//	console.log(output.clients);
	//	console.log(OUTPUTTEXT[lang].pg1P1);

	pdf.SetFont(HELVETICA, NORMAL);
	pdf.SetFontSize(PxToPt(18));
	pdf.SetTextColor(0x45, 0x55, 0x60);
	pdf.Text(OUTPUTTEXT[lang].pg1P1 + output.designedFor, InToPt(1.52), InToPt(7.13));
	pdf.Text(OUTPUTTEXT[lang].pg1P2 + output.designedBy, InToPt(1.52), InToPt(7.63));
	pdf.Text(OUTPUTTEXT[lang].pg1P3 + output.dateApplet, InToPt(1.52), InToPt(7.92));
	pdf.Text(OUTPUTTEXT[lang].pg1P4 + output.province, InToPt(1.52), InToPt(8.19));

	//console.log('clients3');
	//		console.log(clients);
	//		console.log(OUTPUTTEXT[lang].pg1P1);


	//pdf.Grid();

	{/*---}			// Page 2*/
		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);


		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));
		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTITLE[lang].Values[0], InToPt(1.5), InToPt(1.4));

		pdf.SetFont(TIMES, NORMAL);

		let x = 1.5;
		let y = 1.6;
		let incY = .4;
		let height = 0.35;
		let values = [OUTPUTTEXT[lang].pg2TabT1, OUTPUTTEXT[lang].pg2TabT2, OUTPUTTEXT[lang].pg2TabT3, OUTPUTTEXT[lang].pg2TabT4];
		let fill = [115, 153, 198];
		let textColor = [255, 255, 255];
		let Widths = [1.2, .6, 1.8, 1.4]
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];
		output.clients.forEach(function (element) {
			values = [getListItemNameFromKey(MEMBER, element.memberKey, lang), element.age.toString(), '$'+formatMoney(cleanFormat(element.income,formatFr), 0, decimalChar, thousands), element.ret.toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		});





		/* 	values = ["Client", "$70,000", "65"];
			y += incY;	
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			values = ["Spouse", "$50,000", "65"];
			y +=incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		  */


		//pdf.SetFillColor(255, 255, 255);
		//pdf.SetTextColor(0x45, 0x55, 0x60);
		//pdf.Rectangle(InToPt(1.5), InToPt(2), InToPt(1.8), InToPt(0.4));
		//pdf.Text("Client", InToPt(1.61), InToPt(2.25));
		//pdf.SetFillColor(255, 255, 255);
		//pdf.Rectangle(InToPt(3.32), InToPt(2), InToPt(1.8), InToPt(0.4));
		//pdf.Text("$70,000", InToPt(3.43), InToPt(2.25));
		//pdf.SetFillColor(255, 255, 255);
		//pdf.Rectangle(InToPt(5.14), InToPt(2), InToPt(1.8), InToPt(0.4));
		//pdf.Text("65", InToPt(5.25), InToPt(2.25));

		//pdf.SetFillColor(255, 255, 255);
		//pdf.Rectangle(InToPt(1.5), InToPt(2.5), InToPt(1.8), InToPt(0.4));
		//pdf.Text("Spouse", InToPt(1.61), InToPt(2.75));
		//pdf.SetFillColor(255, 255, 255);
		//pdf.Rectangle(InToPt(3.32), InToPt(2.5), InToPt(1.8), InToPt(0.4));
		//pdf.Text("$50,000", InToPt(3.43), InToPt(2.75));
		//pdf.SetFillColor(255, 255, 255);
		//pdf.Rectangle(InToPt(5.14), InToPt(2.5), InToPt(1.8), InToPt(0.4));
		//pdf.Text("65", InToPt(5.25), InToPt(2.75));

		//	// Page 3
		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);
		{/* PAGE 3 Family Cash Needs at Death*/ }
		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg3T, InToPt(1.50), InToPt(1.4));

		paragraph = OUTPUTTEXT[lang].pg3P1;
		pdf.SetFont(TIMES, NORMAL);
		pdf.SetFontSize(PxToPt(16));
		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.MultilineText(paragraph, InToPt(1.50), InToPt(1.80), InToPt(5));


		x = 1.5;
		y = 2.7;
		incY = .4;
		height = 0.35;
		Widths = [4, 1];


		values = [OUTPUTTEXT[lang].pg3TabT];
		fill = [115, 153, 198];
		textColor = [255, 255, 255];
		pdf.tableRow(fill, textColor, x, y, values, height, [5]);


		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];

		output.liabilities.forEach(function (element) {
			values = [element.name, ("$" + formatMoney(element.value, 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		});
		values = [OUTPUTTEXT[lang].pg3TabRTot, ("$" + formatMoney(output.totalLiab, 0,decimalChar,thousands)).toString()];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);


		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);
		{/* PAGE 4 Family Income Needs at Death*/ }
		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg4T, InToPt(1.50), InToPt(1.4));

		paragraph = OUTPUTTEXT[lang].pg4P1;
		pdf.SetFont(TIMES, NORMAL);
		pdf.SetFontSize(PxToPt(16));
		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.MultilineText(paragraph, InToPt(1.50), InToPt(1.8), InToPt(5));



		x = 1.5;
		y = 2.3;
		incY = .44;
		height = 0.35;
		//const Widths = 5;

		values = [OUTPUTTEXT[lang].pg4TabT];
		fill = [115, 153, 198];
		textColor = [255, 255, 255];
		pdf.tableRow(fill, textColor, x, y, values, height, [5]);



		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];


		values = [OUTPUTTEXT[lang].pg4TabRow1, ("$" + formatMoney(output.Income + output.Income2, 0,decimalChar,thousands)).toString()];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		y += incY;
		pdf.MultilineText(OUTPUTTEXT[lang].pg4TabRow2, InToPt(x + .1), InToPt(y + incY), InToPt(3));



		//values = [OUTPUTTEXT[lang].pg4TabRow2,""];
		y += incY;
		pdf.DrawLine(InToPt(1.50), InToPt(y - .33), InToPt(5))

		//pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		if (twoNeedPercents) {
			values = [OUTPUTTEXT[lang].pg4TabRow3, (output.percent1 + "%").toString()];
			y += 2 * incY;
			pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);

			values = [OUTPUTTEXT[lang].pg4TabRow4, (output.percent2 + "%").toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))
		}
		else {
			values = [OUTPUTTEXT[lang].pg4TabRow4, (output.percent1 + "%").toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))
		}
		values = [OUTPUTTEXT[lang].pg4TabRow5, ""];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))

		if (twoNeedPercents) {
			values = [OUTPUTTEXT[lang].pg4TabRow6, ("$" + formatMoney(output.percentNeed1, 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))

			values = [OUTPUTTEXT[lang].pg4TabRow7, ("$" + formatMoney(output.percentNeed2, 0,decimalChar,thousands)).toString()];
		}
		else
			values = [OUTPUTTEXT[lang].pg4TabRow7, ("$" + formatMoney(output.percentNeed1, 0,decimalChar,thousands)).toString()];

		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))
		//pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		y += incY;
		pdf.DrawLine(InToPt(1.50), InToPt(y), InToPt(5))




		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);
		{/* PAGE 5 Family Cash Sources at Death*/ }

		Widths = [3.15, 1, .9];
		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg5T, InToPt(1.50), InToPt(1.4));

		pdf.SetFont(TIMES, NORMAL);

		pdf.SetFontSize(PxToPt(16));

		x = 1.5;
		y = 1.7;
		incY = .44;
		height = 0.35;
		//const Widths = 5;
		values = [OUTPUTTEXT[lang].pg5TabT];
		fill = [115, 153, 198];
		textColor = [255, 255, 255];
		pdf.tableRow(fill, textColor, x, y, values, height, [5]);


		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];
		pdf.SetTextColor(0x45, 0x55, 0x60);


		if (lang === "fr") {
			y += incY;
			y += .3;
			pdf.MultilineText(OUTPUTTEXT[lang].pg5TabRow1, InToPt(x + .1), InToPt(y), InToPt(3));
			pdf.Text("$" + formatMoney(output.govDB, 0,decimalChar,thousands).toString(), InToPt(x + 3.5), InToPt(y));
		} else {
			values = [OUTPUTTEXT[lang].pg5TabRow1, ("$" + formatMoney(output.govDB, 0,decimalChar,thousands)).toString(), ""];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		}
		output.assets.forEach(function (element) {
			values = [element.name, ("$" + formatMoney(element.value, 0,decimalChar,thousands)).toString(), ""];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		});


		values = [OUTPUTTEXT[lang].pg5TabRow3, ("$" + formatMoney(output.totalAsset, 0,decimalChar,thousands)).toString(), ("$" + formatMoney(output.totalAsset, 0,decimalChar,thousands)).toString()];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		if(lang==="fr")
		{
			y += .73*incY;
			pdf.MultilineText(OUTPUTTEXT[lang].pg5TabRow4, InToPt(x + .1), InToPt(y + .4), InToPt(3));
			pdf.Text("$" + formatMoney(output.totalLiab, 0,decimalChar,thousands).toString(), InToPt(x + 4.35), InToPt(y + .41));
			y +=.73* incY;
		}
		else
		{
			values = [OUTPUTTEXT[lang].pg5TabRow4, "", ("$" + formatMoney(output.totalLiab, 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		}

		y += incY;
		pdf.MultilineText(OUTPUTTEXT[lang].pg5TabRow5, InToPt(x + .1), InToPt(y + .4), InToPt(3));
		pdf.Text("$" + formatMoney(output.totalAsset - output.totalLiab, 0,decimalChar,thousands).toString(), InToPt(x + 4.35), InToPt(y + .41));

		y += incY;
		pdf.DrawLine(InToPt(1.50), InToPt(y - .33), InToPt(5))



		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);

		{/* PAGE 6 Family Income Sources at Death*/ }
		Widths = [4, 1];
		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg6T, InToPt(1.50), InToPt(1.4));

		pdf.SetFont(TIMES, NORMAL);

		pdf.SetFontSize(PxToPt(16));

		x = 1.5;
		y = 1.7;
		incY = .44;
		height = 0.35;
		//const Widths = 5;
		values = [OUTPUTTEXT[lang].pg6TabT];
		fill = [115, 153, 198];
		textColor = [255, 255, 255];
		pdf.tableRow(fill, textColor, x, y, values, height, [5]);

		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];

		output.sources.forEach(function (element) {
			values = [element.name, ("$" + formatMoney(element.value, 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		});
		y += incY;
		pdf.MultilineText(OUTPUTTEXT[lang].pg6TabRow1, InToPt(x + .1), InToPt(y + .35), InToPt(3));
		y += incY + .3;
		pdf.DrawLine(InToPt(1.50), InToPt(y - .04), InToPt(5))
		//y += incY+.1;	


		if (twoNeedPercents) {
			values = [OUTPUTTEXT[lang].pg6TabRow2, ("$" + formatMoney(output.totalSource, 0,decimalChar,thousands)).toString()];
			y += incY - .27;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);

			values = [OUTPUTTEXT[lang].pg6TabRow3, ("$" + formatMoney(output.totalSource2, 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		}
		else {
			values = [OUTPUTTEXT[lang].pg6TabRow3, ("$" + formatMoney(output.totalSource1, 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		}
		y += incY + .2;
		pdf.MultilineText(OUTPUTTEXT[lang].pg6TabRow4, InToPt(x + .1), InToPt(y), InToPt(3));
		y += incY - .13;
		pdf.DrawLine(InToPt(1.50), InToPt(y + .26), InToPt(5))

		//values = [OUTPUTTEXT[lang].pg6TabRow5, ("$"+ formatMoney(output.percentNeed1-output.totalSource, 0,decimalChar,thousands)).toString()];
		//y += incY;	
		//pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		//	values = [OUTPUTTEXT[lang].pg6TabRow6, ("$"+ formatMoney(output.percentNeed2-output.totalSource2, 0,decimalChar,thousands)).toString()];
		//	y += incY;	
		//pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		//#7399C6
		//pdf.Text(OUTPUTTEXT[lang].pg6TabRow6,  x, y);
		//pdf.tableRow(fill, textColor, x, y, OUTPUTTEXT[lang].pg6TabRow6, [1]);

		values = [OUTPUTTEXT[lang].pg6TabRow5];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);
		fill = [196, 223, 224];

		if (twoNeedPercents) {
			pdf.tableRow(fill, textColor, x + 4, y, [("$" + formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0,decimalChar,thousands)).toString()], height, [1]);

			fill = [255, 255, 255];
			values = [OUTPUTTEXT[lang].pg6TabRow6];
			y += incY;
			pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			fill = [196, 223, 224];
			pdf.tableRow(fill, textColor, x + 4, y, [("$" + formatMoney(Math.max(0, output.percentNeed2 - output.totalSource2), 0,decimalChar,thousands)).toString()], height, [1]);
		}
		else
			pdf.tableRow(fill, textColor, x + 4, y, [("$" + formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0,decimalChar,thousands)).toString()], height, [1]);

		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);

		{/* PAGE 7 Life info anal*/ }

		Widths = [4, 1];
		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg7T, InToPt(1.50), InToPt(1.4));

		pdf.SetFont(TIMES, NORMAL);

		pdf.SetFontSize(PxToPt(16));

		x = 1.5;
		y = 1.7;
		incY = .42;
		height = 0.35;
		//const Widths = 5;
		values = [OUTPUTTEXT[lang].pg7TabT];
		fill = [115, 153, 198];
		textColor = [255, 255, 255];
		pdf.tableRow(fill, textColor, x, y, values, height, [5]);

		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];
		pdf.SetTextColor(0x45, 0x55, 0x60);

		y += incY + .2;
		pdf.MultilineText(OUTPUTTEXT[lang].pg7TabRow1, InToPt(x + .1), InToPt(y), InToPt(3));
		y += incY / 2;

		//if (output.hasChild) {
		//	if (output.ygChild < 18) {
		if (twoNeedPercents) {

			values = [OUTPUTTEXT[lang].pg7TabRow2, ("$" + formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0,decimalChar,thousands)).toString()];
			y += incY;
			pdf.tableRow(fill, textColor, x + .1, y, values, height, Widths);

			values = [OUTPUTTEXT[lang].pg7TabRow3, ("$" + formatMoney(Math.max(0, output.percentNeed2 - output.totalSource2), 0,decimalChar,thousands)).toString()];

		}
		else
			values = [OUTPUTTEXT[lang].pg7TabRow3, ("$" + formatMoney(Math.max(0, output.percentNeed1 - output.totalSource), 0,decimalChar,thousands)).toString()];


		y += incY;
		pdf.tableRow(fill, textColor, x + .1, y, values, height, Widths);

		values = [OUTPUTTEXT[lang].pg7TabRow4, (output.infRate + "%").toString()];
		y += incY;
		pdf.tableRow(fill, textColor, x + .1, y, values, height, Widths);

		y += incY + .22;
		pdf.MultilineText(OUTPUTTEXT[lang].pg7TabRow5, InToPt(x + .2), InToPt(y), InToPt(3));
		pdf.Text((output.invRate + "%").toString(), InToPt(x + 4.25), InToPt(y + .21));


		y += incY + .3;
		pdf.DrawLine(InToPt(1.50), InToPt(y - .23), InToPt(5))
		y += incY - .2;
		pdf.MultilineText(OUTPUTTEXT[lang].pg7TabRow6, InToPt(x + .2), InToPt(y), InToPt(3));
		y += incY - .2;
		values = [OUTPUTTEXT[lang].pg7TabRow7 + props.LE + ")", ("$" + formatMoney(Math.max(0, output.insNeedLE + output.totalAsset - output.totalLiab), 0,decimalChar,thousands)).toString()];
		y += incY + .1;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		values = [OUTPUTTEXT[lang].pg7TabRow8, ("$" + formatMoney(Math.max(0, output.insNeedRet + output.totalAsset - output.totalLiab), 0,decimalChar,thousands)).toString()];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		if (output.hasChild) {
			if (output.ygChild < maxDur) {
				values = [OUTPUTTEXT[lang].pg7TabRow9, ("$" + formatMoney(Math.max(0, output.insNeedYgChild25 + output.totalAsset - output.totalLiab), 0,decimalChar,thousands)).toString()];
				y += incY;
				pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			}

			if (output.ygChild < orphAge) {
				values = [OUTPUTTEXT[lang].pg7TabRow10, ("$" + formatMoney(Math.max(0, output.insNeedYgChild18 + output.totalAsset - output.totalLiab), 0,decimalChar,thousands)).toString()];
				y += incY;
				pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			}
		}
		pdf.AddChart("bar1", InToPt(1.5), InToPt(y + .7), InToPt(4), InToPt(2));


		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);

		{/* PAGE 8 Life info anal 2 */ }

		Widths = [4, 1];
		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg8T, InToPt(1.50), InToPt(1.4));

		pdf.SetFont(TIMES, NORMAL);

		pdf.SetFontSize(PxToPt(16));

		x = 1.5;
		y = 1.7;
		incY = .42;
		height = 0.35;
		//const Widths = 5;
		values = [OUTPUTTEXT[lang].pg8TabT];
		fill = [115, 153, 198];
		textColor = [255, 255, 255];
		pdf.tableRow(fill, textColor, x, y, values, height, [5]);

		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];
		pdf.SetTextColor(0x45, 0x55, 0x60);


		/* values = [OUTPUTTEXT[lang].pg8TabRow1, ("$"+ formatMoney(totalAsset-output.totalLiab, 0,decimalChar,thousands)).toString()];
	  y += incY;	
	  pdf.tableRow(fill, textColor, x, y, values, height, Widths); */

		y += incY + .2;
		pdf.MultilineText(OUTPUTTEXT[lang].pg8TabRow1, InToPt(x), InToPt(y), InToPt(3));
		pdf.Text(("$" + formatMoney(output.totalAsset - output.totalLiab, 0,decimalChar,thousands)).toString(), InToPt(x + 4.25), InToPt(y + .21));


		y += incY + .3;
		pdf.MultilineText(OUTPUTTEXT[lang].pg8TabRow2, InToPt(x), InToPt(y), InToPt(3));
		y += incY - .1;


		values = [OUTPUTTEXT[lang].pg8TabRow3 + props.LE + ")", ("$" + formatMoney(output.insNeedLE, 0,decimalChar,thousands)).toString()];
		y += incY + .1;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		values = [OUTPUTTEXT[lang].pg8TabRow4, ("$" + formatMoney(output.insNeedRet, 0,decimalChar,thousands)).toString()];
		y += incY;
		pdf.tableRow(fill, textColor, x, y, values, height, Widths);

		if (output.hasChild) {
			if (output.ygChild < maxDur) {
				values = [OUTPUTTEXT[lang].pg8TabRow5, ("$" + formatMoney(output.insNeedYgChild25, 0,decimalChar,thousands)).toString()];
				y += incY;
				pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			}

			if (output.ygChild < orphAge) {
				values = [OUTPUTTEXT[lang].pg8TabRow6, ("$" + formatMoney(output.insNeedYgChild18, 0,decimalChar,thousands)).toString()];
				y += incY;
				pdf.tableRow(fill, textColor, x, y, values, height, Widths);
			}
		}
		pdf.AddChart("bar2", InToPt(1.5), InToPt(y + .7), InToPt(4), InToPt(2));



		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);


		{/* Nptes*/ }

		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg9T, InToPt(1.50), InToPt(1.4));

		paragraph = OUTPUTTEXT[lang].pg9P1;
		pdf.SetFont(TIMES, NORMAL);
		pdf.SetFontSize(PxToPt(16));
		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.MultilineText(paragraph, InToPt(1.50), InToPt(1.80), InToPt(5));

		pdf.Footer(OUTPUTTEXT[lang].pgFooter);
		pdf.AddPage();
		pdf.Header(OUTPUTTEXT[lang].pg1T);


		{/* Acknow*/ }

		pdf.SetFont(HELVETICA, NORMAL);
		if (lang === "en")
			pdf.SetFontSize(PxToPt(25));
		else
			pdf.SetFontSize(PxToPt(20));

		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.Text(OUTPUTTEXT[lang].pg10T, InToPt(1.50), InToPt(1.4));

		paragraph = OUTPUTTEXT[lang].pg10P1;
		pdf.SetFont(TIMES, NORMAL);
		pdf.SetFontSize(PxToPt(16));
		pdf.SetTextColor(0x45, 0x55, 0x60);
		pdf.MultilineText(paragraph, InToPt(1.50), InToPt(1.80), InToPt(5));

		pdf.SetFont(TIMES, NORMAL);

		pdf.SetFontSize(PxToPt(16));

		x = 1.5;
		y = 3.7;
		incY = .42;
		height = 0.35;
		//const Widths = 5;
		fill = [255, 255, 255];
		textColor = [0x45, 0x55, 0x60];
		pdf.SetTextColor(0x45, 0x55, 0x60);

		let yOffset = props.lang === "fr" ? 3 : 4;
		y += incY + .2;
		pdf.MultilineText(OUTPUTTEXT[lang].pg10TabRow1, InToPt(x), InToPt(y), InToPt(4));
		pdf.Text(OUTPUTTEXT[lang].pg10TabRow11, InToPt(x + yOffset), InToPt(y));


		y += incY;
		pdf.MultilineText(OUTPUTTEXT[lang].pg10TabRow2, InToPt(x), InToPt(y), InToPt(4));
		pdf.Text(OUTPUTTEXT[lang].pg10TabRow11, InToPt(x + yOffset), InToPt(y));

		y += incY;
		pdf.MultilineText(OUTPUTTEXT[lang].pg10TabRow3, InToPt(x), InToPt(y), InToPt(4));
		pdf.Text(OUTPUTTEXT[lang].pg10TabRow11, InToPt(x + yOffset), InToPt(y));






		pdf.Footer(OUTPUTTEXT[lang].pgFooter);

		// Done
		pdf.Save("testPDF.pdf");

	}
}