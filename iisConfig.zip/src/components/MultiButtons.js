import React, { Component } from 'react';

export class MultiButtons extends React.Component {
	constructor(props) {
		super(props);
		// console.log(this.props)
		const selected=this.props.selected===undefined?0:this.props.selected-1
		//let buttonsDefault=[{id: selected,name:this.props.buttonCaption[selected], style:'multiButtons multiButtonsAct'}]
		let buttonsDefault=[]
		let i;
        for (i = 0; i < this.props.noButtons; ++i) {
			if(i===selected) 
				buttonsDefault.push({id: selected,name:this.props.buttonCaption[selected], style:'multiButtons multiButtonsAct'})
			else
				buttonsDefault.push({id: i,name:this.props.buttonCaption[i], style:'multiButtons'})
			
        }
        
		this.state = {
			buttons: buttonsDefault,
		};

        // console.log(this.state.buttons)
	}

	selectButton = (index) => {
      	let buttonsDefault=this.state.buttons;
		let i;
        for (i = 0; i < this.props.noButtons; ++i) {
            buttonsDefault[i].style=buttonsDefault[i].id===index?'multiButtons multiButtonsAct':'multiButtons'
        }
        this.setState({ buttons: buttonsDefault });
		this.props.selectMultiButton(index+1);
	}

	render() {
		
        
        return (
        <span>
        {this.state.buttons.map((item,i) => 
            <button key={item.id} className={item.style}  onClick={()=>this.selectButton(item.id)}>{item.name}</button>)}
         </span>

      )}
        
	
}