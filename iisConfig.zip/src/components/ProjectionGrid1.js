import React, { useState,useEffect } from "react";
import DataTable from "./GridExcelComponent/DataTable";
/* import {
    formatMoney,
    cleanFormat
} from "../utils/helper";
import {
    COLUMN_TITLES,
    TITLES,
    INCOMESOURCES
} from "../utils/generalDefinitions";
import {
    getInfoExcelcapFund,
    getInfoExcelAllAfterTax
} from "../definitions/infoIconsDefinitions";
import { Info } from "./Info";
import { getAssetGridValues } from "../data/assetProjections";
import { getOutputValues, setUIDataToAPI } from "../data/dataExchange";
//import DataTable from "./GridExcelComponent/DataTable";
import Loader from 'react-loader-spinner'
import _ from 'lodash';
 */




  /*       fullGridData = async (input,assetCurr) => {
    
           
            //const dataNA = setUIDataToAPI(this.props.input);
            const data = await getAssetGridValues(input, assetCurr, "en", false)
            
            return data;
        }
    
    
    
    
        // EP spreadsheet
        getGridData = async (input,assetCurr) => {
            let gridColumnAligns;
            let dataTitle;
            let dataColHeaders;
            let dataColumns;
            let gridIcons;
    
            // spreadsheet
            dataTitle = "TITLES[this.props.input.lang].appletEP";
       
            let data = await fullGridData(input,assetCurr);
            gridColumnAligns = new Array(data.dataColTitles.length).fill(2);
            gridIcons = new Array(data.dataColTitles.length)
    
            
    
            return {
                gridTitle: dataTitle,
                gridColumnsHeaders: data.dataColTitles,
                gridColumnsDataMain: data.dataProjection,
                gridIcons: gridIcons
            }
    
        }
        




*/


export default function ProjectionGrid1({assetProjection}) {
    const [projectionGrid, setProjectionGrid] = useState(assetProjection);

    console.log(assetProjection);

    useEffect(() => {
        /* getGridData(input, assetCurr)
            .then(response => response.json())
            .then(data => setProjectionGrid(data)); */

           setProjectionGrid(assetProjection)
    }, [assetProjection])


    if(projectionGrid!==null && projectionGrid!==undefined){
    console.log(projectionGrid)
    console.log(projectionGrid.dataColTitles)}
    return (
        <div>
         
            {
            <DataTable
                gridTitle={projectionGrid.gridTitle}
                gridColumnsHeaders={projectionGrid.dataColTitles}
                gridColumnsDataMain={projectionGrid.dataProjection}
                //  gridColumnsDataExcelInfoSection={this.state.projectionGrid.gridColumnsDataExcelInfoSection}
                // gridColumnAligns={this.state.projectionGrid.gridColumnAligns}
                // gridIcons={this.state.projectionGrid.gridIcons}
                language={"en"}
            />}
        </div>);
}

