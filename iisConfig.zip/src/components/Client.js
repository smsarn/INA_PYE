﻿import React, { Component } from "react";

import { DropDown } from "./DropDown";
//import { InputField4 } from './inputField4';
import { InputField } from "./inputField";
import { AddRemove } from "./AddRemove";
import { cleanFormat } from "../utils/helper";
import {
  getInfoIconClientsMember,
  getInfoIconClientsElig,
  getInfoIconSpouseElig,
  getInfoIconClientsTax,
  getInfoIncome
} from "../definitions/infoIconsDefinitions";
import { appletMode } from "../../package.json";

import { MESSAGES, SEX, SMOKING, MEMBER, CONTROLTITLE } from "../definitions/generalDefinitions";
import {getListItemNameFromKey, versionDetails,isVersion2019, getListItemKeyFromName } from "../utils/helper";
import { createDefaultClient } from "../data/createDefaults";
export class Client extends Component {
  displayName = Client.name;

  constructor(props) {
    super(props);
    this.state = {};
    var sexValues = [
      {
        label: SEX.MALE.value[this.props.language],
        value: 1
      },
      { label: SEX.FEMALE.value[this.props.language], value: 2 }
    ];

    var smokingValues = [
      {
        label: SMOKING.NON_SMOKER.value[this.props.language],
        value: 1
      },
      { label: SMOKING.SMOKER.value[this.props.language], value: 2 }
    ];

    var memberValues = [
      {
        label: MEMBER.CLIENT.value[this.props.language], value: 1 },
      { label: MEMBER.SPOUSE.value[this.props.language], value: 2 },
      { label: MEMBER.CHILD.value[this.props.language], value: 3 },
      //{ label: MEMBER.DEPENDENT_ADULT.value[this.props.language], value: 4 }
    ];


    this.dataValues = {
      DD: [
        {
          id: 1,
          Title: CONTROLTITLE[this.props.language].sex,
          defValue: getListItemNameFromKey(SEX,this.props.clientCurr.sexKey,this.props.language),
          Values: sexValues
        },
        {
          id: 2,
          Title: CONTROLTITLE[this.props.language].smoking,
          defValue: getListItemNameFromKey(SMOKING,this.props.clientCurr.smokerKey,this.props.language),
          Values: smokingValues
        },
        {
          id: 3,
          Title: CONTROLTITLE[this.props.language].member,
          defValue: getListItemNameFromKey(MEMBER,this.props.clientCurr.memberKey,this.props.language),
          Values: memberValues
        }
      ]
    };
  }

  componentWillReceiveProps(nextProps) {
    // console.log(getListItemNameFromKey(SEX,nextProps.clientCurr.sexKey,this.props.language),nextProps.clientCurr.memberKey,this.props.language)
    if (nextProps.clientCurr !== this.props.clientCurr || nextProps.id !== this.props.id
      || nextProps.hasSurivor !== this.props.hasSurivor
      || nextProps.clientsNo !== this.props.clientsNo
      ) {
  
      // console.log(nextProps, this.props,this.dataValues)
      this.dataValues.DD[0].defValue = getListItemNameFromKey(SEX,nextProps.clientCurr.sexKey,this.props.language);
      this.dataValues.DD[1].defValue = getListItemNameFromKey(SMOKING,nextProps.clientCurr.smokerKey,this.props.language);
      this.dataValues.DD[2].defValue =getListItemNameFromKey(MEMBER,nextProps.clientCurr.memberKey,this.props.language);
      // console.log(nextProps, this.props,this.dataValues)
      
    }
  }

  handleDoRemove = id => {
    this.props.handleRemoveClient(id);
  };

  handleDoAdd = () => {
    let newCliet;
    if(this.props.clientsNo===1)
      newCliet=createDefaultClient(2)
    else
    {  
      newCliet=createDefaultClient(this.props.clientsNo+1)  //add spouse
      newCliet.Age=
        18 -
        2 *
        (this.props.clientsNo > 6
          ? 4
          : this.props.clientsNo+1)
      newCliet.sexKey=
      this.props.clientsNo % 2
          ? SEX.MALE.Key
          : SEX.FEMALE.Key
      newCliet.retirementAge=25    
    }
    this.props.handleAddClient(newCliet);
  };

  doSwitch = () => {
    this.props.switchClients();
  };
  handleUpdateInput = (id, value) => {
    let client = {
      id: this.props.id,
      Age: this.props.clientCurr.Age,
      sexKey: this.props.clientCurr.sexKey,
      smokerKey: this.props.clientCurr.smokerKey,
      Income: this.props.clientCurr.Income,
      avgTaxRate: this.props.clientCurr.avgTaxRate,
      memberKey: this.props.clientCurr.memberKey,
      retirementAge: this.props.clientCurr.retirementAge,
      Eligibility: this.props.clientCurr.Eligibility
    };

    let changed = false;
    if (id === 0) {
      changed = client.Age !== parseInt(value) ? true : false;
      client.Age = parseInt(value);
    } else if (id === 1) {
      changed = client.Income !== parseInt(cleanFormat(value)) ? true : false;
      client.Income = parseInt(cleanFormat(value));
    } else if (id === 2) {
      changed =
        client.avgTaxRate !==
        parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
      client.avgTaxRate =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    } else if (id === 3) {
      changed = client.retirementAge !== parseInt(value) ? true : false;
      client.retirementAge = parseInt(value);
    } else if (id === 4) {
      changed =
        client.Eligibility !==
        parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
      client.Eligibility =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    }

    if (changed) this.props.handleUpdate(client);
  };

  updateDDown = (id, selection) => {
    let client = {
      id: this.props.id,
      Age: this.props.clientCurr.Age,
      sexKey: this.props.clientCurr.sexKey,
      smokerKey: this.props.clientCurr.smokerKey,
      Income: this.props.clientCurr.Income,
      avgTaxRate: this.props.clientCurr.avgTaxRate,
      memberKey: this.props.clientCurr.memberKey,
      retirementAge: this.props.clientCurr.retirementAge,
      Eligibility: this.props.clientCurr.Eligibility
    };
    if (id === 1) client.sexKey = getListItemKeyFromName(SEX, selection);
    else if (id === 2) client.smokerKey = getListItemKeyFromName(SMOKING, selection);
    else if (id === 3) client.memberKey = getListItemKeyFromName(MEMBER, selection);

    this.props.handleUpdate(client);
  };

  render() {
    const child = this.props.clientCurr.memberKey === MEMBER.CHILD.Key;
    const childIsTheSurvivor = this.props.clientCurr.memberKey === MEMBER.CHILD.Key && this.props.isTheSurvivor;
  
  
  
  
  
  
  
  
  
    let clientMember =
      (this.props.clientCurr.memberKey === MEMBER.CLIENT.Key &&
      this.props.id === 1);
   let disableMember =
      clientMember || (this.props.clientCurr.memberKey === MEMBER.SPOUSE.Key &&
        this.props.id === 2);
   // console.log(CONTROLTITLE[this.props.language].member, this.props.language,this.dataValues.DD[2])
   
    return (
      <div
         className="inputRow"
      >
        <InputField
          id={0}
          inputName={CONTROLTITLE[this.props.language].age}
          format={1}
          Count={this.props.clientsNo}
          language={this.props.language}
          inputValue={this.props.clientCurr.Age}
          handleUpdateInput={this.handleUpdateInput}
        />
        {this.dataValues.DD.map(dd => {
          return (child &&
            dd.Title === CONTROLTITLE[this.props.language].smoking) ||
            dd.Title === CONTROLTITLE[this.props.language].age ? (
            ""
          ) : (
            <DropDown
              key={dd.id}
              id={dd.id}
              Count={this.props.clientsNo}
              Title={dd.Title}
              defValue={dd.defValue}
              disable={
                dd.Title === CONTROLTITLE[this.props.language].member
                  ? disableMember
                  : false
              }
              infoIcon={dd.Title === CONTROLTITLE[this.props.language].member  && dd.defValue===getListItemNameFromKey(MEMBER,MEMBER.CLIENT.Key,this.props.language) ? getInfoIconClientsMember(this.props.language):undefined}
              hasSurivor={this.props.hasSurivor}
              Values={dd.Values}
              language={this.props.language}
              updateDDown={this.updateDDown}
            />
          );
        })}

        {child ? (
          ""
        ) : (
          <InputField
            id={1}
            inputName={CONTROLTITLE[this.props.language].income}
            format={2}
            Count={this.props.clientsNo}
            infoIcon= {this.props.id===1 ? getInfoIncome(this.props.language):undefined}
            language={this.props.language}
            inputValue={this.props.clientCurr.Income}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {child ? (
          ""
        ) : (
          <InputField
            id={2}
            inputName={CONTROLTITLE[this.props.language].avgTax}
            format={3}
            Count={this.props.clientsNo}
            //info={MESSAGES[this.props.language].infoAvgTax}
            infoIcon= {this.props.id===1 ? getInfoIconClientsTax(this.props.language):undefined}
            showInfo= {!disableMember}//infoOnlyForRowID={2}
            language={this.props.language}
            inputValue={this.props.clientCurr.avgTaxRate}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {child && !childIsTheSurvivor ? (
          ""
        ) : (
          <InputField
            id={3}
            inputName={childIsTheSurvivor? CONTROLTITLE[this.props.language].protectToAge: CONTROLTITLE[this.props.language].retAge}
            format={1}
            Count={this.props.clientsNo}
            language={this.props.language}
            inputValue={this.props.clientCurr.retirementAge}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {child ? (
          ""
        ) : (
          <InputField
            id={4}
            inputName={CONTROLTITLE[this.props.language].cppElig}
            format={3}
            Count={this.props.clientsNo}
            //info={MESSAGES[this.props.language].infoElig}
            infoIcon={this.props.id===1 ?getInfoIconClientsElig(this.props.language):getInfoIconSpouseElig(this.props.language)}
            showInfo= {disableMember}
            language={this.props.language}
            inputValue={this.props.clientCurr.Eligibility}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {/* {isVersion2019() === false && disableMember ? ( */}
        {clientMember ===true && this.props.clientsNo>1 && (
          <button className="addRemove" onClick={this.doSwitch}>
            <font size="-4">&#8645;</font>
          </button>
        ) }
        <AddRemove
          currentID={this.props.id}
          numberComps={this.props.clientsNo}
          fixedFirstRow={true}
          minComps={1}//{appletMode==="INA"?2:1}
          handleDoAdd={this.handleDoAdd}
          handleDoRemove={this.handleDoRemove}
        />
        {/* {isMobileDevice() && this.props.id < this.props.clientsNo ? (
          <hr className="ppi2" />
        ) : (
          ""
        )} */}
      </div>
    );
  }
}
