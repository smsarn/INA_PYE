import React, { Component } from "react";
import "./Output.css";
import { Table } from "react-bootstrap";
import {
  ASSETS,
  ASSET_TAX,
  CONTROLTITLE,
  TOTALS,QUOTE_SPOUSE,QUOTE_CLIENT
} from "../definitions/generalDefinitions";
import { OUTPUTTEXT } from "../definitions/outputDefinitionsEP";
import { Bar } from "react-chartjs-2";
import { doSavePdfAction } from "./OutputPDF";
//import jsPDF from 'jspdf';
//import * as jsPDF from 'jspdf';
import { cleanFormat, formatMoney, getListItemNameFromKey, getProjectedLiabilities } from "../utils/helper";
import { getOutputValues, setUIDataToAPI } from "../data/dataExchange";
import { OutputGraphStacked } from "./OutputGraphStacked"
import {
  fetchAssetProjectionAPI, fetchAssetProjection, fetchAssetFMVandTaxLiab
} from "../utils/FetchAPIs";

import { getAssetGridValues } from "../data/assetGridProjections";
import DataTable from "./GridExcelComponent/DataTable";
import { isEqual } from "lodash";
import Loader from 'react-loader-spinner'

const ASSET_TAX_TYPE_PRINCIPAL_RES = 0;
const ASSET_TAX_TYPE_REAL_ESTATE = 1;
const ASSET_TAX_TYPE_STOCKS = 2;
const ASSET_TAX_TYPE_SMALL_BUS = 3;
const ASSET_TAX_TYPE_RRSP = 4;
const ASSET_TAX_TYPE_INTEREST = 5;

const ASSET_TAX_TYPE_COUNT = 6;


export class OutputPresentationEP extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      grids: []
    }
    this.dateApplet = "";
    this.dataAges = []
    this.dataAssetnEstateLiabProj = []
    this.dataEstateLiabProj = [];//[ASSET_TAX_TYPE_COUNT];
    this.dataEstateLiabProjLE3 = [];//[ASSET_TAX_TYPE_COUNT]
    this.output=getOutputValues(this.props);
  }

  doPDF = () => {
    doSavePdfAction(this.props, this.dateApplet);
  };

  componentDidMount() {
    this.setState({ loading: true });
    setTimeout(() => {
      this.upDateGrids();
   }, 800);
    

  }

  componentWillReceiveProps(nextProps) {
    this.output = getOutputValues(this.props)
    
    // long output, close and open Results and only use componentDidMount(){
    /* console.log(nextProps.input, this.props.input)
    if (nextProps.input.loading!==this.props.loading && nextProps.input.loading===false)
    {
      alert("inWill")
      
      this.upDateGrids()
    } */
  }

  upDateGrids = () => {
    // add liab and tax liab

    const lang = this.props.input.lang
    const clients=this.props.input.dataInput.Clients
    const startAge=clients.length>1?Math.min(clients[QUOTE_SPOUSE].Age,clients[QUOTE_CLIENT].Age):clients[QUOTE_CLIENT].Age
    
    const LE3 = parseInt(this.props.LE - startAge) + 3
    this.dataEstateLiabProj = Array(ASSET_TAX_TYPE_COUNT).fill(0)
    this.dataEstateLiabProjLE3 = Array(ASSET_TAX_TYPE_COUNT).fill(0)
    let proj = [];
    let dataEstateLiability = Array(100 - startAge + 1).fill(0)

    const dataNA = setUIDataToAPI(this.props.input);

    let tmpGrids = [];
    let AssetProjectionsGrid = []

    // add all assets
    this.props.input.dataInput.Assets.forEach(element => {
      this.getData(dataNA, element.id).then(data => {

        if (data !== undefined) {
          proj.values = Array(100).fill(0)
          // console.log(data)
          if (element.assetTypeKey === ASSETS.PERSONAL_RESIDENCE.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_PRINCIPAL_RES] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_PRINCIPAL_RES] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.PERSONAL_RESIDENCE.value[lang], ASSETS.PERSONAL_RESIDENCE.colour)
          }
          else if (element.assetTypeKey === ASSETS.REAL_ESTATE.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_REAL_ESTATE] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_REAL_ESTATE] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.REAL_ESTATE.value[lang], ASSETS.REAL_ESTATE.colour)
          }
          else if (element.assetTypeKey === ASSETS.STOCKS_BONDS.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_STOCKS] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_STOCKS] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.STOCKS_BONDS.value[lang], ASSETS.STOCKS_BONDS.colour)
          }
          else if (element.assetTypeKey === ASSETS.SMALL_BUSINESS_SHARES.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_SMALL_BUS] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_SMALL_BUS] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.SMALL_BUSINESS_SHARES.value[lang], ASSETS.SMALL_BUSINESS_SHARES.colour)
          }
          else if (element.assetTypeKey === ASSETS.RRSP_RRIF.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_RRSP] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_RRSP] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.RRSP_RRIF.value[lang], ASSETS.RRSP_RRIF.colour)
          }
          else if (element.assetTypeKey === ASSETS.INTEREST_BEARING.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_INTEREST] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_INTEREST] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.INTEREST_BEARING.value[lang], ASSETS.INTEREST_BEARING.colour)
          }
          // take other to be int bearing
          else if (element.assetTypeKey === ASSETS.OTHER_ASSETS.Key) {
            this.dataEstateLiabProj[ASSET_TAX_TYPE_INTEREST] += data.TaxLiab[0]
            this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_INTEREST] += data.TaxLiab[LE3]
            this.addAssetToProjections(proj, data.FMV, ASSETS.INTEREST_BEARING.value[lang], ASSETS.INTEREST_BEARING.colour)
          }

          // bundle non-taxable together
          else if (element.assetTypeKey === ASSETS.CASH.Key) {
            this.addAssetToProjections(proj, data.FMV, ASSET_TAX.NON_TAXABLE.value[lang], ASSETS.CASH.colour)
          }
          else if (element.assetTypeKey === ASSETS.LIFE_INSURANCE.Key) {
            this.addAssetToProjections(proj, data.FMV, ASSET_TAX.NON_TAXABLE.value[lang], ASSETS.LIFE_INSURANCE.colour)
          }
          else if (element.assetTypeKey === ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key) {
            this.addAssetToProjections(proj, data.FMV, ASSET_TAX.NON_TAXABLE.value[lang], ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.colour)
          }

          // sum all for total tax liab
          for (let i = 0; i < 100 - startAge; i++) {
            if (data.TaxLiab[i] !== undefined)
              dataEstateLiability[i] += data.TaxLiab[i]
          }
          dataEstateLiability[100 - startAge]=dataEstateLiability[100 - startAge-1]
        }
      }
      

      ).then(() => {
        getAssetGridValues(dataNA, element, lang).then(data => {
          console.log(data)

          tmpGrids.push(data)
          console.log(tmpGrids[0].dataColTitles,dataEstateLiability)
          console.log(tmpGrids[0].dataProjection)
          this.setState({ grids: tmpGrids, loading: false })
        })
      }

      )


    });


    proj.push({ name: TOTALS.ESTATE_LIAB.value[lang], colour: TOTALS.ESTATE_LIAB.colour, values: dataEstateLiability })

    this.dataAssetnEstateLiabProj = proj

    console.log(this.dataAssetnEstateLiabProj, this.dataEstateLiabProj, this.dataEstateLiabProjLE3)
  }

  addAssetToProjections = (proj, data, assetName, colour) => {
    let vals = Array(100).fill(0)
    let alreadyThere = false
    for (let i = 0; i < proj.length; i++) {
      if (proj[i].colour === colour) {
        alreadyThere = true;
        // console.log(alreadyThere)
        for (let j = 0; j < 100; j++)
          proj[i].values[j] += data[j]
      }
    }
    if (alreadyThere === false)
      proj.push({ name: assetName, colour: colour, values: data })

    return proj
  }


  getData = async (dataNA, id) => {
    //const dataNA = setUIDataToAPI(this.props.input);
    //let data = await fetchAssetProjectionAPI(dataNA,id)
    let data = await fetchAssetFMVandTaxLiab(dataNA, id)
    console.log(data)
    return data
  }

/*   getAllAssetProjectionGrids = (assetID) => {
    const dataNA = setUIDataToAPI(this.props.input);
    //let data = await fetchAssetProjectionAPI(dataNA,id)
    let data = fetchAssetProjection(dataNA, assetID)
    console.log(data)
    return data
  }
 */


  render() {

    // presentation output shared with pdf
    const lang = this.props.input.lang
    let loaded = this.dataAssetnEstateLiabProj.length > 0 ? true : false


    //  console.log(this.grids)
    /* this.getData(1).then(data => {
      if (data !== undefined) {
        this.dataPR=data.dataValues[ASSET_PROJ]
      }
      else
        loaded=false;
    })
    this.getData(2).then(data => {
      if (data !== undefined) {
        this.dataRE=data.dataValues[ASSET_PROJ]
      }
      else
        loaded=false;
    })
 */
    // console.log(this.dataAssetnEstateLiabProj )





    this.dataAges = []
    const clients=this.props.input.dataInput.Clients
    const startAge=clients.length>1?Math.min(clients[QUOTE_SPOUSE].Age,clients[QUOTE_CLIENT].Age):clients[QUOTE_CLIENT].Age
    for (let i = startAge; i < 100; i++)
      this.dataAges[i - startAge] = i


    // graph details
    const options = {
      legend: {
        display: false
      },
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        xAxes: [{ stacked: true }],
        yAxes: [
          {
            stacked: true,
            ticks: {
              beginAtZero: true,
              steps: 10,
              stepValue: 5
            }
          }
        ]
      }
    };


    let p2 = 1;
    let p5 = 1;
    let p6 = 1;

    //alert(this.dataPR.dataValues[ASSET_PROJ].length)

    const { grids, loading } = this.state;

    if (grids[0]===undefined) {
      return <Loader type="TailSpin" color="black" height={30} width={30} />;
    }

    let j=0;
    return (
      <div>
        <input
          className="twoButtons twoButtonsAct"
          style={{
            width: "130px",
            marginTop: "0px",
            paddingRight: "8px",
            float: "right"
          }}
          onClick={this.doPDF}
          type="button"
          value={CONTROLTITLE[lang].pdf}
        />
        {/* <h3 className="ppi1">
          {needTo}: {this.props.insuranceNeed}
        </h3>
 */}


        <div className="contentPres">


          {/* PAGE 1 */}

          <br />
          <br />
          <img
            className="ppi1 pict"
            id="INAPage1"
            src={require("../images/INA.png")}
          />
          <h1 className="ppi1">{OUTPUTTEXT[lang].pg1T}</h1>
          <h5 className="ppi2">
            {OUTPUTTEXT[lang].pg1P1} {this.output.designedFor}
            <br />
            {OUTPUTTEXT[lang].pg1P2} {this.output.designedBy}
            <br />
            {OUTPUTTEXT[lang].pg1P3} {this.output.dateApplet}
            <br />
            {OUTPUTTEXT[lang].pg1P4} {this.output.province}
            <br />
          </h5>
          <hr className="ppi1" />



          {/* PAGE 2 Intro*/}

          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg2T}</h2>

            {OUTPUTTEXT[lang].pg2Paragraphs.map(item =>
              (<p className="ppi1" key={p2++}>{p2 >= 4 && p2 !== 6 && p2 !== 9 && p2 <= 11 && <span style={{ paddingLeft: '15px', color: '#759AC7' }}>{p2 < 6 ? p2 - 3 : (p2 < 9 ? p2 - 4 : p2 - 5)}.  </span>} {item}<br /></p>)

            )}

          </div>

          {/* PAGE 3 fin situation*/}

          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg3T}</h2>
            <p className="ppi1">
              {OUTPUTTEXT[lang].pg3P1}</p>

            <div style={{ fontSize: '14px' }}>
              <div style={{ paddingLeft: '20px', width: "35%", float: 'left' }}>
                <div><table className="tableEP" style={{ paddingLeft: '10px', width: "100%" }}>
                  <tbody>
                    <tr>
                      <th className="tableTitleEP" colSpan="2">
                        {OUTPUTTEXT[lang].pg3TabT}
                      </th>
                    </tr>
                    {/* add assets*/}
                    {this.output.assets.map(item => (
                      <tr key={item.name} >
                        <td style={{ height: "1px", width: "65%" }}>{item.name}</td>
                        <td
                          className="textalignright"
                          style={{ height: "1px" }}
                        >
                          ${formatMoney(item.value, 0, ",", ",")}
                        </td>
                      </tr>
                    ))}

                  </tbody>
                </table></div>
              </div>
              <div style={{ paddingLeft: '20px', width: "35%", float: 'left' }}>
                <div><table className="tableEP" style={{ paddingLeft: '10px', width: "100%" }}>
                  <tbody>
                    <tr>
                      <th className="tableTitleEP" colSpan="2">
                        {OUTPUTTEXT[lang].pg3Tab2T}</th>
                    </tr>
                    {/* liabs*/}
                    {this.output.liabilities.map(item => (
                      <tr key={item.name}>
                        <td style={{ width: "55%" }}>{item.name}</td>
                        <td className="textalignright">
                          ${formatMoney(item.value, 0, ",", ",")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table></div></div>
            </div>

          </div>
          <h2 className="ppi1">{OUTPUTTEXT[lang].pg3T2}</h2>
          <p className="ppi1">
            {OUTPUTTEXT[lang].pg3P2}</p>
          <p className="ppi1">
            {OUTPUTTEXT[lang].pg3P3}</p>

          <div style={{ fontFamily: "Georgia, 'Times New Roman', imes, serif", fontSize: '14px' }}>
            <div style={{ paddingLeft: '20px', width: "70%", float: 'left' }}>
              <div><table className="tableEP" style={{ paddingLeft: '10px', width: "100%" }}>
                <tbody>
                  <tr>
                    <th className="tableTitleEP" style={{ width: "30%" }}>{OUTPUTTEXT[lang].pg3Tab3R1C1}</th>
                    <th className="tableTitleEP" style={{ width: "20%" }}>{OUTPUTTEXT[lang].pg3Tab3R1C2}</th>
                    <th className="tableTitleEP" style={{ width: "20%" }}>{OUTPUTTEXT[lang].pg3Tab3R1C3}</th>
                    <th className="tableTitleEP" style={{ width: "20%" }}>{OUTPUTTEXT[lang].pg3Tab3R1C4}</th>
                  </tr>
                  <tr>
                    <td >{OUTPUTTEXT[lang].pg3Tab3R2C1}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProj[ASSET_TAX_TYPE_REAL_ESTATE], 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_REAL_ESTATE], 0, ",", ",")}</td>
                  </tr>
                  <tr>

                    <td >{OUTPUTTEXT[lang].pg3Tab3R3C1}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProj[ASSET_TAX_TYPE_STOCKS], 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_STOCKS], 0, ",", ",")}</td>
                  </tr>
                  <tr >
                    <td >{OUTPUTTEXT[lang].pg3Tab3R4C1}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProj[ASSET_TAX_TYPE_SMALL_BUS], 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_SMALL_BUS], 0, ",", ",")}</td>
                  </tr>
                  <tr >
                    <td >{OUTPUTTEXT[lang].pg3Tab3R5C1}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProj[ASSET_TAX_TYPE_RRSP], 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_RRSP], 0, ",", ",")}</td>
                  </tr>
                  <tr >
                    <td >{OUTPUTTEXT[lang].pg3Tab3R6C1}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProj[ASSET_TAX_TYPE_INTEREST], 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(this.dataEstateLiabProjLE3[ASSET_TAX_TYPE_INTEREST], 0, ",", ",")}</td>
                  </tr>
                  <tr >
                    <td colSpan="2">{OUTPUTTEXT[lang].pg3Tab3R7C1}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                    <td className="textalignright">${formatMoney(1000, 0, ",", ",")}</td>
                  </tr>

                </tbody>
              </table>
              </div>
            </div>
            <p className="ppi1" style={{ color: 'darkgrey', marginTop: '3px', fontSize: '12px', float: 'left' }}>
              {OUTPUTTEXT[lang].pg3P4}</p>

          </div>


          {/* PAGE 4 fin situation*/}
          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg4T}</h2>
            <p className="ppi1">
              {OUTPUTTEXT[lang].pg4P1}</p>
       
          </div>

          {loaded = true && <OutputGraphStacked language={lang} dataAges={this.dataAges} dataAssetnEstateLiabProj={this.dataAssetnEstateLiabProj} LE={this.props.LE - startAge} />}
          <p className="ppi1" style={{ color: 'darkgrey', marginTop: '-30px', fontSize: '12px', float: 'left' }}>
              {OUTPUTTEXT[lang].pg4P2}</p>

          {/* PAGE 5 Estate Protection Alternatives*/}

          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg5T}</h2>

            {OUTPUTTEXT[lang].pg5Paragraphs.map(item =>
              (<p className="ppi1" key={p5++}>{p5 >= 4 && p5 !== 8 && p5 <= 12 && <span style={{ paddingLeft: '15px', color: '#759AC7' }}>{p5 < 8 ? p5 - 3 : (p5 - 8)}.  </span>} {item}<br /></p>)
            )}

            <p className="ppi1" style={{ backgroundColor: 'lightgrey', width: "84%", marginTop: '30px', paddingTop: '10px', paddingBottom: '12px', marginLeft: '30px' }}>
              {OUTPUTTEXT[lang].pg5Plast}</p>

          </div>

          {/* PAGE 6 Using Life Insurance to Preserve Your Estate*/}

          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg6T}</h2>

            {OUTPUTTEXT[lang].pg6Paragraphs1.map(item =>
              (<p className="ppi1" key={p6++}>{p6 >= 4 && p6 <= 6 && <span style={{ paddingLeft: '15px', color: '#759AC7' }}>{p6 < 8 ? p6 - 3 : (p6 - 8)}.  </span>} {item}<br /></p>)
            )}

            {OUTPUTTEXT[lang].pg6Paragraphs2.map(item =>
              (<p className="ppi1" key={p6++}>{p6 > 12 && <span style={{ paddingLeft: '15px', color: '#759AC7' }}>&#8226;  </span>} {item}<br /></p>)
            )}

          </div>

          {/* PAGE 7 Summary*/}

          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg7T}</h2>
            <p className="ppi1">
              {OUTPUTTEXT[lang].pg7P1}</p>

          </div>

          {/* PAGE 8 appendix ledgers*/}

          <div
            style={{ overflowX: "auto", overflowY: "hidden", width: "100%" }}
          >
            <br />
            <h2 className="ppi1">{OUTPUTTEXT[lang].pg8T}</h2>


            <p className="ppi1">
              {OUTPUTTEXT[lang].pg7P1}</p>


            <div id="assetGrid" style={{ clear: "both", float: "left",marginLeft:"25px" }} /*    onClick={this.clone2}  */   >

              {this.state.grids.map(grid =>
                 <DataTable
                  key={j++}
                  gridColumnsHeaders={grid.dataColTitles}
                  gridColumnsDataMain={grid.dataProjection}
                  gridTitle={grid.gridTitle}
                  gridIcons={[]}
                  language={lang}
       
                />)}

            </div>

          </div>
































        </div>
      </div>



    );
  }
}
