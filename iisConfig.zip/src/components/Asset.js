﻿import React, { Component } from "react";
import { DropDown } from "./DropDown";
//import { InputField4 } from './inputField4';
import { InputField } from "./inputField";
import { AddRemove } from "./AddRemove";
import { cleanFormat } from "../utils/helper";
import {
  getInfoIconAssetsIncomeRate,
  getInfoIconAssetsYr0,
  getInfoIconAssetsOwner,
  getInfoIconSourcesRRIF,
  getInfoTaxLiability,
  getInfoIconTaxExempt
} from "../definitions/infoIconsDefinitions";

import { createDefaultAsset, copyFromAnotherAsset } from "../data/createDefaults";
import {
  MESSAGES,
  ASSETS,
  ASSET_TAX,
  CONTROLTITLE,
  OWNERSHIP,
  ASSET_OWNERSHIP_ACTION,
  //  ASSET_OWNERSHIP_ACTION2,
  COLUMN_TITLES

} from "../definitions/generalDefinitions";
import { getListItemNameFromKey, getListItemKeyFromName, isMobileDevice, getListToShowByOrder, arrayFormatMoney } from "../utils/helper";

import { ProjectionGrid}  from "./ProjectionGrid.js";
import  ProjectionGrid1  from "./ProjectionGrid1.js";
import DataTable from "./GridExcelComponent/DataTable";
import {
  fetchAssetProjection2,
  fetchAssetProjectionAPI
} from "../utils/FetchAPIs";
import {
  DEFAULT_RRIF_AGE,
  DROPDOWN_WIDE,
} from "../definitions/generalDefinitions";
import _ from 'lodash';

import {
  ASSET_API_OUTPUT_Year,
  ASSET_API_OUTPUT_Age,
  ASSET_API_OUTPUT_FMV,
  ASSET_API_OUTPUT_EOYBalance,
  ASSET_API_OUTPUT_ACB,
  ASSET_API_OUTPUT_UCC,
  ASSET_API_OUTPUT_CCA,
  ASSET_API_OUTPUT_CapitalGain,
  ASSET_API_OUTPUT_TaxabaleGain,
  ASSET_API_OUTPUT_Recapture,
  ASSET_API_OUTPUT_TaxPayable,
  ASSET_API_OUTPUT_CapGainsExemption,
  ASSET_API_OUTPUT_Deposits,
  ASSET_API_OUTPUT_Withdrawals,
  ASSET_API_OUTPUT_RRIF,
  ASSET_API_OUTPUT_TaxPayableonIncome,
  ASSET_API_OUTPUT_DispositionAmount
} from "../definitions/generalDefinitions";
import { appletMode } from "../../package.json";
import { GridButton } from "./GridButton";
import { getAssetGridValues } from "../data/assetGridProjections";

export class Asset extends Component {
  displayName = Asset.name;
  constructor(props) {
    super(props);

    var i;
    var typeValues = [];
    const listAssetsToShow = getListToShowByOrder(ASSETS);
    for (i = 0; i < listAssetsToShow.length; ++i) {
      typeValues.push({
        label: listAssetsToShow[i].value[this.props.language],
        value: i + 1
      });
    }

    /* for (i = 0; i < ASSETS[this.props.language].Values.length; ++i) {
      typeValues.push({
        label: ASSETS[this.props.language].Values[i],
        value: i + 1
      });
    } */

    /* var ownerValues = [
      {
        label: OWNERSHIP[this.props.language].Values[0],
        value: 1
      },
      { label: OWNERSHIP[this.props.language].Values[1], value: 2 },
      { label: OWNERSHIP[this.props.language].Values[2], value: 3 },
      { label: OWNERSHIP[this.props.language].Values[3], value: 4 }
    ];
 */
    var ownerActionValues = [
      {
        label:
          ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.value[this.props.language],
        value: 1
      },
      {
        label:
          ASSET_OWNERSHIP_ACTION.CLIENT_ROLLOVER.value[this.props.language],
        value: 2
      },
      {
        label:
          ASSET_OWNERSHIP_ACTION.SPOUSE.value[this.props.language],
        value: 3
      },
      {
        label:
          ASSET_OWNERSHIP_ACTION.JOINT.value[this.props.language],
        value: 4
      }
    ];

    /* var ownerActionValues2 = [
          {
            label:
              ASSET_OWNERSHIP_ACTION2.properties[this.props.language].Values[
                OWNER_ACTION_CLIENTLIQUIDATE
              ],
            value: 1
          },
          {
            label:
              ASSET_OWNERSHIP_ACTION[this.props.language].Values[
                OWNER_ACTION_CLIENTROLLOVER
              ],
            value: 2
          },
          {
            label:
              ASSET_OWNERSHIP_ACTION[this.props.language].Values[
                OWNER_ACTION_Spouse
              ],
            value: 3
          },
          {
            label:
              ASSET_OWNERSHIP_ACTION[this.props.language].Values[
                OWNER_ACTION_Joint
              ],
            value: 4
          }
        ];
    
     */
    this.taxValues = [];
    const listAssetTaxesToShow = getListToShowByOrder(ASSET_TAX);
    // console.log(listAssetTaxesToShow)
    for (i = 0; i < listAssetTaxesToShow.length; ++i) {
      this.taxValues.push({
        label: listAssetTaxesToShow[i].value[this.props.language],
        value: i + 1
      });
    }
    // console.log(this.props.assetCurr) 
    /*     for (i = 0; i < ASSET_TAX[this.props.language].Values.length; ++i) {
          this.taxValues.push({
            label: ASSET_TAX[this.props.language].Values[i],
            value: i + 1
          });
        }
     */
    this.state = {
      displaySreadsheet: false,
      loading:true,
      
    };
    // console.log(this.props.assetCurr.ownerKey)
    this.dataValues = {
      DD: [
        {
          id: 1,
          Title: CONTROLTITLE[this.props.language].type,
          defValue: getListItemNameFromKey(ASSETS, this.props.assetCurr.assetTypeKey, this.props.language),
          Values: typeValues
        },
        {
          id: 2,
          Title: CONTROLTITLE[this.props.language].owner,
          /* defValue: this.props.assetCurr.ownerKey,
          Values: ownerValues 
          Title: ASSET_OWNERSHIP.Title.value[this.props.language],//CONTROLTITLE[this.props.language].ownershipAction,           */
          defValue: getListItemNameFromKey(ASSET_OWNERSHIP_ACTION, this.props.assetCurr.ownerKey, this.props.language),
          Values: ownerActionValues
        },
        {
          id: 3,
          Title: CONTROLTITLE[this.props.language].tax,
          defValue: getListItemNameFromKey(ASSET_TAX, this.props.assetCurr.assetTaxTypeKey, this.props.language),// this.props.assetCurr.Tax,
          Values: this.taxValues
        },

      ]
    };
    
    this.dataColTitles = [];
    this.taxLiabOfClient = [];
    
  }

  componentWillReceiveProps(nextProps) {
    console.log(nextProps.assetCurr, this.props.assetCurr);
    if (!_.isEqual(nextProps.assetCurr, this.props.assetCurr)
      || nextProps.id !== this.props.id
      || nextProps.assetsNo !== this.props.assetsNo  ||
      !_.isEqual(nextProps.projection,this.props.projection) 
    ) {
      if (this.props.assetCurr.assetTypeKey === ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key || nextProps.assetCurr.assetTypeKey === ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key) {
        // console.log(this.dataValues.DD[0].Values);
        console.log(nextProps.projection, this.props.projection);
   
        this.dataValues.DD[0].Values.push({
          label: ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.value[this.props.language],
          value: this.dataValues.DD[0].Values.length + 1
        })
        // console.log(this.dataValues.DD[0].Values);

      }

      this.dataValues.DD[0].defValue = getListItemNameFromKey(ASSETS, nextProps.assetCurr.assetTypeKey, this.props.language);
      this.dataValues.DD[1].defValue = getListItemNameFromKey(ASSET_OWNERSHIP_ACTION, nextProps.assetCurr.ownerKey, this.props.language);
      this.dataValues.DD[2].defValue = getListItemNameFromKey(ASSET_TAX, nextProps.assetCurr.assetTaxTypeKey, this.props.language);//nextProps.assetCurr.Tax;

      
   

      //this.dataValues.DD[3].defValue = nextProps.assetCurr.ownerKey;

      /* 
let i;
      this.typeValues = [];
       if(this.props.Type===ASSETS[this.props.language].Values[4])	//		'Registered')  
      {
        this.dataValues.DD[2].defValue =ASSET_TAX[this.props.language].Values[TAX_RRSP] 

      this.typeValues.push({
        label: ASSETS[this.props.language].Values[2],
       });
     }
      else{
      for (i = 0; i <= ASSETS[this.props.language].Values.length; ++i) {
        this.typeValues.push({
        label: ASSETS[this.props.language].Values[i],
        value: i + 1
      });
      }} */
    }
  }

  componentDidUpdate = async (prevProps, prevState) => {
    if (prevProps !== this.props) {
      /*  console.log(
         `this.state.clickCounts(♻️ componentDidUpdate)`,
         this.props.assetCurr.currValue
       );
       */
    }
  };

  handleDoRemove = id => {
    this.props.handleRemoveAsset(id);
  };

  handleDoAdd = () => {
    var assNo =
      this.props.assetsNo > this.dataValues.DD[0].Values.length - 1
        ? this.dataValues.DD[0].Values.length - 2
        : this.props.assetsNo;
    var assNext = this.dataValues.DD[0].Values[assNo].label;
    if (assNo === 4 || assNo === 5) assNo = 0;
    else
      assNo =
        this.props.assetsNo > this.dataValues.DD[2].Values.length - 1
          ? this.dataValues.DD[2].Values.length - 1
          : this.props.assetsNo;
    var assTax = this.dataValues.DD[2].Values[assNo].label;
    const assTaxTypeKey = getListItemKeyFromName(ASSET_TAX, this.dataValues.DD[2].Values[assNo].label);
    // console.log(assTaxTypeKey,assTax )
    let asset = createDefaultAsset(this.props.assetsNo + 1);
    asset.assetTypeKey = getListItemKeyFromName(ASSETS, assNext);
    asset.ownerKey = ASSET_OWNERSHIP_ACTION.CLIENT_ROLLOVER.Key;
    asset.assetTaxTypeKey = assTaxTypeKey;

    asset = this.setAssetValuesToDefault(asset);

    this.dataValues.DD[2].Values = this.taxValues;

    this.props.handleAddAsset(asset);
  };

  updateDDown = (id, selection) => {
    const { id: propId, assetCurr } = this.props;

    let asset = copyFromAnotherAsset(assetCurr);
    asset.id = propId;
    if (id === 1) {
      asset = createDefaultAsset(propId)
      asset.assetTypeKey = getListItemKeyFromName(ASSETS, selection);
      asset = this.setAssetValuesToDefault(asset);
    } else if (id === 2) {
      asset.ownerKey = getListItemKeyFromName(ASSET_OWNERSHIP_ACTION, selection);
      asset = this.setAssetValuesToDefault(asset);
    }
    else if (id === 3)
      //asset.Tax = selection;
      asset.assetTaxTypeKey = getListItemKeyFromName(ASSET_TAX, selection);



    /* asset = this.setAssetValuesToDefault(asset);  */

    
    this.props.handleUpdate(asset);
    //if (this.state.displaySreadsheet === true)
      //this.handleUpdateGrid();
    
  };

  handleUpdateInput = (id, value) => {
    let asset = copyFromAnotherAsset(this.props.assetCurr);
    asset.id = this.props.id;

    /* let asset = {
      id: this.props.id,
      //Type: this.props.assetCurr.Type,
      assetTypeKey: this.props.assetCurr.assetTypeKey,
      ownerKey: this.props.assetCurr.ownerKey,
      //OwnerID: this.props.assetCurr.OwnerID,
      currValue: this.props.assetCurr.currValue,
      //Tax: this.props.assetCurr.Tax,
      assetTaxTypeKey: this.props.assetCurr.assetTaxTypeKey,
      //TaxID: this.props.assetCurr.TaxID,
      growth: this.props.assetCurr.growth,
      DisposeYr: this.props.assetCurr.DisposeYr,
      DisposeDur: this.props.assetCurr.DisposeDur,
      ACB: this.props.assetCurr.ACB,
      smallBusinessCapGainExemption: this.props.assetCurr
        .smallBusinessCapGainExemption,
      contributionAmt: this.props.assetCurr.contributionAmt,
      contributionStartYr: this.props.assetCurr.contributionStartYr,
      contributionDur: this.props.assetCurr.contributionDur,
      incomeRate: this.props.assetCurr.incomeRate,
      RRIFStartAge: this.props.assetCurr.RRIFStartAge
    };
 */
    let changed = false;

    if (id === 2) {
      changed = asset.DisposeYr !== parseInt(value) ? true : false;
      asset.DisposeYr = parseInt(value);
    } else if (id === 3) {
      changed = asset.DisposeDur !== parseInt(value) ? true : false;
      asset.DisposeDur = parseInt(value);
    } else if (id === 4) {
      changed = asset.ACB !== parseInt(cleanFormat(value)) ? true : false;
      asset.ACB = parseInt(cleanFormat(value));
    } else if (id === 10) {
      changed =
        asset.smallBusinessCapGainExemption !== parseInt(cleanFormat(value))
          ? true
          : false;
      asset.smallBusinessCapGainExemption = parseInt(cleanFormat(value));
    } else if (id === 1) {
      changed = asset.currValue !== parseInt(cleanFormat(value)) ? true : false;
      asset.currValue = parseInt(cleanFormat(value));
    } else if (id === 5) {
      changed =
        asset.growth !==
          parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
      asset.growth =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    } else if (id === 6) {
      changed =
        asset.contributionAmt !== parseInt(cleanFormat(value)) ? true : false;
      asset.contributionAmt = parseInt(cleanFormat(value));
    } else if (id === 7) {
      changed = asset.contributionStartYr !== parseInt(value) ? true : false;
      asset.contributionStartYr = parseInt(value);
    } else if (id === 8) {
      changed = asset.contributionDur !== parseInt(value) ? true : false;
      asset.contributionDur = parseInt(value);
    } else if (id === 9) {
      changed =
        asset.incomeRate !==
          parseInt(100 * cleanFormat(value, this.props.language)) / 100
          ? true
          : false;
      asset.incomeRate =
        parseInt(100 * cleanFormat(value, this.props.language)) / 100;
    }
    else if (id === 11) {
      changed =
        changed = asset.RRIFStartAge !== parseInt(value) ? true : false;
      asset.RRIFStartAge = parseInt(value);

    }

    
    
    if (changed) {
      this.props.handleUpdate(asset);
      //if (this.state.displaySreadsheet === true)
       // this.handleUpdateGrid();
    }
  };

  updateClientTaxLiability = async () => {
    let dataNA = this.props.getAssetProjection();
    //let appSiteAPI = "http://localhost:8082";
    let data = await fetchAssetProjection2(dataNA, this.props.id);
    //alert("change this to fetchAssetProjectionAPI to get rid of fetchAssetProjection2")
    // console.log(data);
    if (data !== undefined) {
      // console.log(data[ASSET_API_OUTPUT_TaxPayable].numericValues[0]);

      return data[ASSET_API_OUTPUT_TaxPayable].numericValues;
    }
  };

  getData = async (dataNA, id) => {
    let data = await fetchAssetProjectionAPI(dataNA, id)

    return data
  }


  /* handleUpdateGrid = async () => {
       //let appSiteAPI = "http://localhost:8082";
         const lang = this.props.language
         const title = COLUMN_TITLES[lang]
         let dataNA = this.props.getAssetProjection();
         
      let got= await getAssetGridValues(dataNA, this.props.assetCurr, lang, false)
      
        console.log(got)
      this.dataProjection = got.dataProjection
      this.dataColTitles = got.dataColTitles
      this.setState(
        {dataProjection:got.dataProjection,  loading:false}); 
      }    
 */

  handleClickGridButton = () => {
    const display=this.state.displaySreadsheet
    this.props.adjustVisibleOutputSection(display===false?1:-1)
    this.setState({ displaySreadsheet: !display,  loading:false });
    
    
    
    /* if (this.state.displaySreadsheet === true) {
      this.setState(prevState => {
        let display = prevState.displaySreadsheet;
        return { displaySreadsheet: !display,  loading:false };
      });
    }
    else {
      //await this.handleUpdateGrid()
      this.setState(prevState => {
        let display = prevState.displaySreadsheet;
        return { displaySreadsheet: !display,  loading:false };
      });
      } */

  };

  setAssetValuesToDefault = asset => {
    this.dataValues.DD[2].Values = this.taxValues;

    if (asset.assetTypeKey === ASSETS.RRSP_RRIF.Key) {//value[this.props.language]) {
      //asset.Tax = ASSET_TAX.REGISTERED.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.REGISTERED.Key;
    } else if (
      asset.assetTypeKey === ASSETS.PERSONAL_RESIDENCE.Key//value[this.props.language]
    ) {
      //asset.Tax = ASSET_TAX.NON_TAXABLE.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.NON_TAXABLE.Key;
      asset.ACB = 0;
      asset.DisposeYr = 99;
      asset.DisposeDur = 1;
    } else if (asset.assetTypeKey === ASSETS.CASH.Key) {//value[this.props.language]) {
      //asset.Tax = ASSET_TAX.NON_TAXABLE.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.NON_TAXABLE.Key;

      asset.ACB = 0;
    } else if (
      asset.assetTypeKey === ASSETS.LIFE_INSURANCE.Key//value[this.props.language]
    ) {
      //asset.Tax = ASSET_TAX.NON_TAXABLE.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.NON_TAXABLE.Key;

      asset.DisposeYr = 0;
      asset.DisposeDur = 1;
      asset.ACB = 0;
      asset.ownerKey = ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key;
    } else if (
      asset.assetTypeKey === ASSETS.STOCKS_BONDS.Key ||//value[this.props.language] ||
      asset.assetTypeKey === ASSETS.REAL_ESTATE.Key//value[this.props.language]
    ) {
      //asset.Tax = ASSET_TAX.CAPITAL_GAINS_DEFERRED.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.CAPITAL_GAINS_DEFERRED.Key;

      this.dataValues.DD[2].Values = [];
      this.dataValues.DD[2].Values.push({
        label: ASSET_TAX.CAPITAL_GAINS_DEFERRED.value[this.props.language],
        value: 1
      });
      this.dataValues.DD[2].Values.push({
        label: ASSET_TAX.CAPITAL_GAINS_ANNUAL.value[this.props.language],
        value: 2
      });
    } else if (asset.assetTypeKey === ASSETS.SMALL_BUSINESS_SHARES.Key)//value[this.props.language])
      //asset.Tax = ASSET_TAX.CAPITAL_GAINS_DEFERRED.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.QUALIFYING_SMALL_BUSINESS.Key;//.CAPITAL_GAINS_DEFERRED.Key;
    else if (
      asset.assetTypeKey === ASSETS.INTEREST_BEARING.Key
    )
      asset.assetTaxTypeKey = ASSET_TAX.INTEREST.Key;//.FULLY_TAXABLE.Key;
    //asset.assetTaxTypeKey= ASSET_TAX.INTEREST.Key;

    else if (
      asset.assetTypeKey === ASSETS.OTHER_ASSETS.Key//value[this.props.language] ||
    )
      //asset.Tax = ASSET_TAX.FULLY_TAXABLE.value[this.props.language];
      asset.assetTaxTypeKey = ASSET_TAX.FULLY_TAXABLE.Key;


    if (
      asset.ownerKey ===//ASSET_OWNERSHIP.CLIENTLIQUIDATE.value[this.props.language]
      ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key
    ) {
      asset.DisposeYr = 0;
      asset.DisposeDur = 1;
    }
    // console.log(asset)

    return asset;
  };

  clone2 = () => {
    let id = "assetGrid"
    if (this.state.displaySreadsheet === true) {
      // console.log(this.state.displaySreadsheet)

      var itm = document.getElementById(id);
      // console.log(itm)

      var cln = itm.cloneNode(true);
      cln.id = "ll"
      //cln.style.position="relative"
      let cln2 = document.createElement('div');
      cln2.appendChild(cln)
      cln2.id = "lll"
      document.addEventListener('click', function (e) {
        if (e.target && e.target.id === 'lll') {
          //    alert('l')
        }
      });

      document.getElementById("copyDiv").appendChild(cln2);
    }
  }


  render() {
    const {
      id,
      assetCurr,
      /* Type,
      Owner,
      index,
      currValue,
      Tax,
      growth,
      Dispos
      eYr,
      DisposeDur,
      ACB,
      smallBusinessCapGainExemption,
      contributionAmt,
      contributionStartYr,
      contributionDur,
      incomeRate, */
      language,
      themeColor,
      assetsNo
    } = this.props;
    const assetID = assetCurr.assetTypeKey//ASSETS.INTEREST_BEARING.value[this.props.language]
    //Object.values(ASSETS).filter(obj => obj.value[language]=== assetCurr.Type)[0].Key
    let disableTaxMethods =
      assetCurr.assetTypeKey === ASSETS.LIFE_INSURANCE.Key ||//value[language] ||
        assetCurr.assetTypeKey === ASSETS.CASH.Key ||//value[language] ||
        assetCurr.assetTypeKey === ASSETS.PERSONAL_RESIDENCE.Key ||//value[language] ||
        assetCurr.assetTypeKey === ASSETS.RRSP_RRIF.Key ||//value[language] ||
        assetCurr.assetTypeKey === ASSETS.INTEREST_BEARING.Key ||
        assetCurr.assetTypeKey === ASSETS.SMALL_BUSINESS_SHARES.Key
        ? true
        : false;
    let disableOwner =
      assetCurr.assetTypeKey === ASSETS.LIFE_INSURANCE.Key
        ? true
        : false;
    const taxT = CONTROLTITLE[language].tax;
    const ownerT = CONTROLTITLE[language].owner;

    let assetTax = MESSAGES[language].assetTax;

    //const taxCredit=assetCurr.Type === UNLISTED[this.props.language].Assets.Values[ASSET_TaxCredit]
    const taxCredit = assetCurr.Type === ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.value[this.props.language]

    const rrsp = assetCurr.assetTaxTypeKey === ASSET_TAX.REGISTERED.Key;//value[language];
    const showACB = !(
      //assetCurr.Tax === ASSET_TAX.NON_TAXABLE.value[language] ||
      assetCurr.assetTaxTypeKey === ASSET_TAX.NON_TAXABLE.Key ||//value[language] ||
      rrsp ||
      assetCurr.assetTypeKey === ASSETS.INTEREST_BEARING.Key ||//value[language] ||
      //assetCurr.Tax === ASSET_TAX.CAPITAL_GAINS_ANNUAL.value[language]
      assetCurr.assetTaxTypeKey === ASSET_TAX.CAPITAL_GAINS_ANNUAL.Key
    );
    const showIncome =
      //assetCurr.Tax === ASSET_TAX.CAPITAL_GAINS_DEFERRED.value[language] ||
      (appletMode === "EP" && (
        assetCurr.assetTaxTypeKey === ASSET_TAX.CAPITAL_GAINS_DEFERRED.Key ||
        assetCurr.assetTypeKey === ASSETS.OTHER_ASSETS.Key ||//value[language] ||
        rrsp)) || (appletMode === "INA" && rrsp && assetCurr.ownerKey !== //ASSET_OWNERSHIP.CLIENTLIQUIDATE.value[this.props.language]
          ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key
      );
    const showDur = !(
      rrsp ||
      assetCurr.assetTypeKey === ASSETS.PERSONAL_RESIDENCE.Key ||//value[language] ||
      assetCurr.assetTypeKey === ASSETS.REAL_ESTATE.Key ||//value[language] ||
      taxCredit || ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key
    );
    const showGrowth = !(
      assetCurr.assetTypeKey === ASSETS.LIFE_INSURANCE.Key || assetCurr.assetTypeKey === ASSETS.CASH.Key ||//value[language] ||
      taxCredit || assetCurr.ownerKey === //ASSET_OWNERSHIP.CLIENTLIQUIDATE.value[this.props.language]
      ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key

    );
    const showDispose = !(
      rrsp ||
      assetCurr.assetTypeKey === ASSETS.LIFE_INSURANCE.Key ||//value[language] ||
      assetCurr.ownerKey === //ASSET_OWNERSHIP.CLIENTLIQUIDATE.value[this.props.language]
      ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key
      ||
      taxCredit
    );

    const showCotribution =
      assetCurr.ownerKey !== //ASSET_OWNERSHIP.CLIENTLIQUIDATE.value[this.props.language]
      ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key && (rrsp ||
        assetCurr.assetTypeKey === ASSETS.INTEREST_BEARING.Key ||//value[language] ||
        assetCurr.assetTypeKey === ASSETS.STOCKS_BONDS.Key)//value[language];
    const showCGE = assetCurr.assetTypeKey === ASSETS.SMALL_BUSINESS_SHARES.Key//value[language]
    // console.log(this.dataValues);

    let gridIcons = new Array(this.dataColTitles.length)
    this.dataColTitles.forEach(item => {
      if (item === COLUMN_TITLES[this.props.language].TaxLiability)
        gridIcons[this.dataColTitles.length - 1] = getInfoTaxLiability(language)
    })

    //const disableDD=(dd.Title === CONTROLTITLE[language].owner && disableOwner)  || (dd.Title === taxT && disableTaxMethods) || (taxCredit && (dd.Title === taxT || dd.Title ===CONTROLTITLE[this.props.language].ownerAction))
    let disableAll = false;
    if (this.props.assetCurr.assetTypeKey === ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.Key) {
      disableAll = true
      this.dataValues.DD[0].Values.push({
        label: ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.value[this.props.language],
        value: this.dataValues.DD[0].Values.length + 1
      })
    }

    const p=this.props.projection[this.props.assetCurr.id-1].grid
    console.log(this.props.assetCurr.projection,this.props.projection[0].grid)

     return (
      <div className="inputRow">
        {this.dataValues.DD.map(
          dd =>
            (
              <DropDown
                key={dd.id}
                id={dd.id}
                Count={assetsNo}
                Title={dd.Title}
                disable={disableAll === true || (dd.Title === CONTROLTITLE[language].owner && disableOwner) || (dd.Title === taxT && disableTaxMethods) || (taxCredit && (dd.Title === taxT || dd.Title === CONTROLTITLE[this.props.language].ownerAction))}
                defValue={dd.defValue}
                unlistedValue={taxCredit ? ASSETS.CHARITABLE_GIFTS_TAX_CREDIT.value[this.props.language] : ""} // TODO ideally find in list of values
                Values={dd.Values}
                //info={dd.Title === "Type" && id === 1 ? assetTax : ""}
                infoIcon={dd.Title === ownerT && assetCurr.id === 1 ? getInfoIconAssetsOwner(this.props.language) : undefined}
                language={language}
                width={DROPDOWN_WIDE}
                updateDDown={this.updateDDown}
              />
            )
        )}
        <InputField
          inputName={CONTROLTITLE[language].amount}
          id={1}
          format={2}
          Count={assetsNo}
          language={language}
          inputValue={assetCurr.currValue}
          handleUpdateInput={this.handleUpdateInput}
        />

        {showCotribution && (
          <div>
            <InputField
              inputName={CONTROLTITLE[language].contributionAmt}
              id={6}
              format={2}
              Count={assetsNo}
              language={language}
              inputValue={assetCurr.contributionAmt}
              handleUpdateInput={this.handleUpdateInput}
            />
            {/* <InputField
              inputName={CONTROLTITLE[language].contributionStartYr}
              id={7}
              format={1}
              //info={MESSAGES[language].infoYr0}
              Count={assetsNo}
              language={language}
              inputValue={assetCurr.contributionStartYr}
              handleUpdateInput={this.handleUpdateInput}
            />  */}
            <InputField
              inputName={CONTROLTITLE[language].contributionDur}
              id={8}
              format={1}
              Count={assetsNo}
              language={language}
              inputValue={assetCurr.contributionDur}
              handleUpdateInput={this.handleUpdateInput}
            />
          </div>
        )}
        {showGrowth && (
          <InputField
            inputName={CONTROLTITLE[language].growth}
            format={3}
            id={5}
            Count={assetsNo}
            language={language}
            inputValue={assetCurr.growth}
            inputTitle={id}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}

        {showIncome && (
          <InputField
            inputName={
              rrsp
                ? CONTROLTITLE[language].RRIFRate
                : CONTROLTITLE[language].incomeRate
            }
            format={3}
            id={9}
            Count={assetsNo}
            infoIcon={rrsp === false && assetCurr.id === 1 ? getInfoIconAssetsIncomeRate(this.props.language) : undefined}
            language={language}
            inputValue={assetCurr.incomeRate}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}


        {rrsp && assetCurr.ownerKey !== //ASSET_OWNERSHIP.CLIENTLIQUIDATE.value[this.props.language]
          ASSET_OWNERSHIP_ACTION.CLIENT_LIQUIDATE.Key
          && (
            <InputField
              inputName={CONTROLTITLE[language].RRIFAge}
              format={1}
              id={11}
              Count={assetsNo}
              infoIcon={getInfoIconSourcesRRIF(this.props.language)}
              language={language}
              inputValue={assetCurr.RRIFStartAge}
              handleUpdateInput={this.handleUpdateInput}
            />
          )}

        {showDispose && (
          <InputField
            inputName={CONTROLTITLE[language].disposeYr}
            id={2}
            //info={MESSAGES[language].infoYr0}
            infoIcon={getInfoIconAssetsYr0(this.props.language)}
            format={1}
            Count={assetsNo}
            language={language}
            inputValue={assetCurr.DisposeYr}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {showDur && (
          <InputField
            inputName={CONTROLTITLE[language].disposeDur}
            id={3}
            format={1}
            Count={assetsNo}
            language={language}
            inputValue={assetCurr.DisposeDur}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {showACB && (
          <InputField
            inputName={CONTROLTITLE[language].ACB}
            format={2}
            id={4}
            Count={assetsNo}
            language={language}
            inputValue={assetCurr.ACB}
            readOnly={disableTaxMethods}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {showCGE && (
          <InputField
            inputName={CONTROLTITLE[language].smallBusinessCapGainExemption}
            format={2}
            id={10}
            Count={assetsNo}
            language={language}
            infoIcon={getInfoIconTaxExempt(this.props.language)}
            inputValue={assetCurr.smallBusinessCapGainExemption}
            handleUpdateInput={this.handleUpdateInput}
          />
        )}
        {/*  <svg
          className="iconMore"
          onClick={this.handleClickGridButton}
          style={{ top: "140px" }}
          xmlns="http://www.w3.org/2000/svg"
          width="24"s
          height="24"
          viewBox="0 0 24 24"
        >
          <path d="M19 3h-4.18C14.4 1.84 13.3 1 12 1c-1.3 0-2.4.84-2.82 2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-7 0c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm2 14H7v-2h7v2zm3-4H7v-2h10v2zm0-4H7V7h10v2z" />
        </svg> */}
        {(!taxCredit && !disableAll) &&
          <GridButton
            className="iconMore"
            handleClickGridButton={this.handleClickGridButton}
            id="gridOn"
            alt="ll"
            src={
              this.state.displaySreadsheet === true
                ? require("../images/gridOff.png")
                : require("../images/gridOn.png")
            }
          />}

        <AddRemove
          currentID={id}
          minComps={0}
          //currentIndex={index}
          id={assetID}
          numberComps={assetsNo}
          handleDoAdd={this.handleDoAdd}
          handleDoRemove={this.handleDoRemove}
        />
        {/* {isMobileDevice() && id < assetsNo ? <hr className="ppi2" /> : ""} */}
           
        {this.state.displaySreadsheet === true && (
          <div id="assetGrid" style={{ clear: "both", float: "left" }} /*    onClick={this.clone2}  */   >
        <ProjectionGrid1  assetProjection={p} />  {/* input={this.props.getAssetProjection()} assetCurr={this.state.updatedAsset}/> */}
            {/*  <ProjectionGrid  assetProjection={this.state.dataProjection} lang={this.props.language}/> */}  {/* input={this.props.getAssetProjection()} assetCurr={this.state.updatedAsset}/> */}
              {/*  <DataTable
              gridColumnsHeaders={this.dataColTitles}
              gridColumnsDataMain={this.state.dataProjection}
              gridTitle={getListItemNameFromKey(ASSETS, this.props.assetCurr.assetTypeKey, this.props.language) + " (" + getListItemNameFromKey(ASSET_OWNERSHIP_ACTION, this.props.assetCurr.ownerKey, this.props.language) + ") Projection"}
              gridIcons={gridIcons}
              language={this.props.language}

            /> */}

          </div>
        )}
      </div>
    );
  }
}
