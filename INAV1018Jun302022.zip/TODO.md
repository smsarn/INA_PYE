change owner to Client: RollOver, Client, Spouse Joint
with Asset select reduce tax method items or disable
change all the setState calls similar to NA.js updateAsset
translation: the new asset items contribution etc
change 0 to at death
if RRSP is not rollover and owned by Client, change 0 to at death and disable
email transfer needs to check for new asset items contribution etc
file open based on new encrytions only decripts client, do others
change ACB to Initial Cost
Remove items in asset list that are not needed based on asset
Add valuation date
bring presentation bar to top re rates and grid?
add Existing RRIF account in asset list
move apisite to defines
EquiBuild int rate has changed
solve for manulife as well
check grid output number being crazy file es4
excel number format and non numbers!