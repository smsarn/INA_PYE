import React from "react";
import IconButton from "@material-ui/core/IconButton";
import Tooltip from "@material-ui/core/Tooltip";
import AddIcon from "@material-ui/icons/Add";
import { withStyles } from "@material-ui/core/styles";
//import { ReactComponent as Icon} from './icon.svg';
import "./ExcelToolbar.css";

const defaultToolbarStyles = {
    iconButton: {
    },
};

export default class ExcelToolbar extends React.Component {

    handleClick = () => {
        this.props.setExcel();
    };

    render() {
        const { classes } = this.props;
        // console.log("classes", classes)
        const title=<span  style={{fontSize: '12px', marginBottom: '0px', margin: '0px', padding: '0px' }}  >{this.props.excelToolbarText}</span>
        return (
            <React.Fragment>
                <Tooltip placement='left-end' style={{fontSize: '12px', margin: '0px', padding: '0px' }}   title={title}>
                    <IconButton  onClick={this.handleClick}>
                        <svg className="icon" xmlns="http://www.w3.org/2000/svg"   padding= '0px' width="30" height="30"  viewBox="0 0 24 24"><path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96zM17 13l-5 5-5-5h3V9h4v4h3z"/></svg>
                    </IconButton>
                </Tooltip>
            </React.Fragment>
        );
    }

}
